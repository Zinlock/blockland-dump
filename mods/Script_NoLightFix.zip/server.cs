forceRequiredAddon("GameMode_Slayer");

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Light";
	title = "Disable lights";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.NoLights";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

new ScriptObject(Slayer_TeamPrefSO : Slayer_DefaultTeamPrefSO)
{
	category = "Lights";
	title = "Disable lights";
	defaultValue = true;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "NoLights";
	type = "bool";
	guiTag = "advanced";
};

package NoLightFixPkg
{
	function serverCmdLight(%cl)
	{
		if(isObject(%pl = %cl.player))
		{
			if(%cl.slyrTeam.NoLights || %cl.minigame.NoLights)
				%pl.lastLightTime = getSimTime();
		}

		Parent::serverCmdLight(%cl);
	}
};
activatePackage(NoLightFixPkg);
registerOutputEvent(Player, setLoadoutItem, "int 1 10 1" TAB "datablock ItemData");
registerOutputEvent(Player, applyLoadout, "bool");
registerOutputEvent(Player, clearLoadout, "");
registerOutputEvent(Player, saveLoadout, "string 200 200");
registerOutputEvent(Player, loadLoadout, "string 200 200");

registerOutputEvent(fxDtsBrick, loadoutCheck, "int 1 10 1" TAB "intList 50", true);

$OutputDescription_["Player", "setLoadoutItem"] = "[slot] [item]" NL
																									"Adds an item to this player's active loadout." NL
																									"slot: Item slot" NL
																									"item: Item to give";

$OutputDescription_["Player", "applyLoadout"] = "[clear]" NL
																								"Equips this player's active loadout." NL
																								"clear: Clears their inventory before equipping";

$OutputDescription_["Player", "clearLoadout"] = "Resets this player's active loadout.";

$OutputDescription_["Player", "saveLoadout"] = "[name]" NL
																							 "Saves this player's active loadout to the server." NL
																							 "name: Loadout save name";

$OutputDescription_["Player", "loadLoadout"] = "[name]" NL
																							 "Loads this player's last active loadout from the server." NL
																							 "name: Loadout save name";

$OutputDescription_["fxDtsBrick", "loadoutCheck"] = "[slot] [lines]" NL
																							 			"Checks if this player has an incomplete loadout." NL
																										"Triggers the 'onLoadoutCheckFail' and 'onLoadoutCheckSuccess' input events." NL
																							 			"slot: Item slot to check" NL
																										"lines: Event lines to trigger";

$InputDescription_["onLoadoutCheckFail"] = "Triggered by the 'loadoutCheck' output event.";
$InputDescription_["onLoadoutCheckSuccess"] = "Triggered by the 'loadoutCheck' output event.";

function registerLoadoutEvents()
{
	%list = "list";

	%items = 0;

	%cts = DatablockGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%db = DatablockGroup.getObject(%i);

		if(%db.IsA("ItemData") && %db.image.weaponReserveMax > 0)
		{
			%name = getSafeVariableName(%db.uiName);
			%name = strReplace(%name, "APOS", "");
			%name = strReplace(%name, "DASH", "");
			%list = %list SPC %name SPC %items;
			%items++;
		}
	}

	registerOutputEvent(Player, setLoadoutGrenade, "int 1 10 1" TAB %list TAB "int 1 100 1");
	
	$OutputDescription_["Player", "setLoadoutGrenade"] = "[slot] [grenade] [count]" NL
																											"Adds a grenade to this player's active loadout." NL
																											"slot: Item slot" NL
																											"grenade: Grenade type" NL
																											"count: Reserve ammo to give";
}

if($AddOn__Weapon_Grenades && isFile("Add-Ons/Weapon_Grenades/server.cs"))
{
	if(!$AddOnLoaded__Weapon_Grenades)
		forceRequiredAddon("Weapon_Grenades");
	
	schedule(0, 0, registerLoadoutEvents);
}

registerInputEvent(fxDtsBrick, onLoadoutCheckFail, "Self fxDtsBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");
registerInputEvent(fxDtsBrick, onLoadoutCheckSuccess, "Self fxDtsBrick" TAB "Player Player" TAB "Client GameConnection" TAB "Minigame Minigame");

function elFindGrenadeId(%db)
{
	if(!isObject(%db))
		return -1;

	for(%i = 0; isObject($ChargeItem[%i]); %i++)
	{
		%itm = $ChargeItem[%i];

		if(%itm.getName() $= %db.getName())
			return %i;
	}

	return -1;
}

function SimObject::IsA(%obj, %type) { return %obj.getClassName() $= %type; }

function GameConnection::checkLoadoutSlot(%cl, %slot)
{
	if(!isObject(%cl.LoadoutWeapon[%slot]) && %cl.LoadoutGrenades[%slot] <= 0 ||
	   !isObject($ChargeItem[%cl.LoadoutWeapon[%slot]]) && %cl.LoadoutGrenades[%slot] > 0)
		return 0;

	return 1;
}

function Player::setLoadoutItem(%pl, %slot, %itm)
{
	%cl = %pl.client;

	%cl.LoadoutWeapon[%slot-1] = %itm;
	%cl.LoadoutGrenades[%slot-1] = "";
}

function Player::setLoadoutGrenade(%pl, %slot, %itm, %cts)
{
	%cl = %pl.client;

	%cl.LoadoutWeapon[%slot-1] = %itm;
	%cl.LoadoutGrenades[%slot-1] = %cts;
}

function Player::applyLoadout(%pl, %clear)
{
	%cl = %pl.client;
	%db = %pl.getDatablock();

	if(%clear)
		%pl.clearTools();
	
	for(%i = 0; %i < %db.maxTools; %i++)
	{
		if(%cl.checkLoadoutSlot(%i))
		{
			%itm = %cl.LoadoutWeapon[%i];
			%cts = %cl.LoadoutGrenades[%i];

			if(%cts <= 0)
			{
				if(%pl.tool[%i] == 0)
					%pl.weaponCount++;

				%pl.tool[%i] = %itm;
				messageClient(%cl, 'MsgItemPickup', '', %i, %itm);
			}
			else
			{
				%idb = $ChargeItem[%itm];

				if(!$Pref::XNades::eventsBypassAmmo && %cts > %idb.image.weaponReserveMax)
					%val = %idb.image.weaponReserveMax;
				
				%pl.setItem(%idb, %i);
				%pl.weaponCharges[%i] = %cts;
			}
		}
	}
}

function Player::clearLoadout(%pl)
{
	%cl = %pl.client;

	for(%i = 0; %i < 10; %i++)
	{
		%cl.LoadoutWeapon[%i] = -1;
		%cl.LoadoutGrenades[%i] = "";
	}
}

function Player::saveLoadout(%pl, %name)
{
	%cl = %pl.client;

	if(!isObject(%cl) || %cl.IsA("AIPlayer"))
		return;

	%file = new FileObject();

	%path = "config/server/loadouts/" @ %cl.getBLID() @ "_" @ getSafeVariableName(%name) @ ".txt";
	if(!%file.openForWrite(%path))
		error("Player::saveLoadout() - couldn't write to file '" @ %path @ "'");
	else
	{
		%file.writeLine("#");
		for(%i = 0; %i < 10; %i++)
		{
			if(!%cl.checkLoadoutSlot(%i))
				continue;

			if(%cl.LoadoutGrenades[%i] <= 0)
				%file.writeLine(%i SPC %cl.LoadoutWeapon[%i].getName() SPC 0);
			else
			{
				%idb = $ChargeItem[%cl.LoadoutWeapon[%i]];

				%file.writeLine(%i SPC %idb.getName() SPC %cl.LoadoutGrenades[%i]);
			}
		}
	}

	%file.close();
	%file.delete();
}

function Player::loadLoadout(%pl, %name)
{
	%cl = %pl.client;

	if(!isObject(%cl) || %cl.IsA("AIPlayer"))
		return;

	%file = new FileObject();

	%path = "config/server/loadouts/" @ %cl.getBLID() @ "_" @ getSafeVariableName(%name) @ ".txt";
	if(!%file.openForRead(%path))
		error("Player::loadLoadout() - couldn't read file '" @ %path @ "'");
	else
	{
		while(!%file.isEOF())
		{
			%str = trim(%file.readLine());

			if(%str $= "" || %str $= "#")
				continue;
			
			%slot = getWord(%str, 0);
			%data = getWord(%str, 1);
			%cts  = getWord(%str, 2);

			%id = elFindGrenadeId(%data);

			if(%cts > 0 && %id == -1)
			{
				error("Player::loadLoadout() - couldn't find grenade '" @ %data @ "'");
				continue;
			}
			else if(%cts <= 0)
			{
				if(!isObject(%data))
				{
					error("Player::loadLoadout() - couldn't find item '" @ %data @ "'");
					continue;
				}

				%cl.LoadoutWeapon[%slot] = %data.getId();
				%cl.LoadoutGrenades[%slot] = "";
			}
			else
			{
				%cl.LoadoutWeapon[%slot] = %id;
				%cl.LoadoutGrenades[%slot] = %cts;
			}
		}
	}
	
	%file.close();
	%file.delete();
}

function fxDtsBrick::loadoutCheck(%brk, %slot, %lines, %cl)
{
	%pl = %cl.Player;

	for(%i = 0; %i < getWordCount(%lines); %i++)
		%enable[getWord(%lines, %i)] = true;

	for(%i = 0; %i < %brk.numEvents; %i++)
	{
		%active[%i] = %brk.eventEnabled[%i];
		%brk.eventEnabled[%i] = (%active[%i] && %enable[%i]);
	}

	$inputTarget_Client   = %cl;
	$inputTarget_Player   = %pl;
	$inputTarget_Minigame = %cl.minigame;

	if(%cl.checkLoadoutSlot(%slot-1))
		%brk.processInputEvent(onLoadoutCheckSuccess, %cl);
	else
		%brk.processInputEvent(onLoadoutCheckFail, %cl);
	
	for(%i = 0; %i < %brk.numEvents; %i++)
		%brk.eventEnabled[%i] = %active[%i];
}

package HatMod_Package {
	function Armor::onAdd(%db, %pl) {
		parent::onAdd(%db, %pl);

		%pl.setHats();
	}

	function Armor::onDisabled(%this, %obj, %state)
	{
		Parent::onDisabled(%this, %obj, %state);

		if(isObject(%obj) && %obj.getClassName() $= "Player")
			%obj.schedule(33, setHats);
	}
};
activatePackage(HatMod_Package);

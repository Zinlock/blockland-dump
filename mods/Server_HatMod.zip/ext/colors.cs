function HatMod_CheckColorHats()
{
	%obj = -1;
	%cts = HatMod_HatSet.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%hat = HatMod_HatSet.getObject(%i);

		%path = %hat.shapeFile;
		%file = strReplace(%path, ".dts", "_Colors.txt");

		if(isFile(%file))
		{
			if(!isObject(%obj))
				%obj = new FileObject();
			else
				%obj.close();
			
			%hat.colorNodes = "";

			%obj.openForRead(%file);

			while(!%obj.isEOF())
			{
				%line = %obj.readLine();

				%node = getField(%line, 0);

				%default = getField(%line, 1);
				%transparent = getField(%line, 2);
				%recolorable = getField(%line, 3);

				if(%recolorable $= "")
					%recolorable = 1;
				
				%hat.colorNode[%node] = %default TAB %transparent TAB %recolorable;
				%hat.colorNodes = trim(%hat.colorNodes TAB %node);
			}
		}
	}

	if(isObject(%obj))
	{
		%obj.close();
		%obj.delete();
	}
}

HatMod_CheckColorHats();
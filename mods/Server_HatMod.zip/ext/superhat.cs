if(isFile("config/server/lasthats.cs"))
	exec("config/server/lasthats.cs");

package superHat
{
	function GameConnection::startLoad(%cl, %a,%b,%c,%d)
	{
		for(%i = 0; %i < $HatMod::MaxHats; %i++) {
			%img = $HatMod::LastHat[%cl.bl_id, %i];

			if(isHat(%img))
				%cl.superHat[%i] = %img;
			
			%db = ("Hat" @ strReplace(%img, " ", "_") @ "Data");
			
			for(%f = 0; %f < getFieldCount(%db.colorNodes); %f++)
			{
				%node = getField(%db.colorNodes, %f);
				%cl.superhatColor[%i, %node] = $HatMod::LastHatColor[%cl.bl_id, %i, %node];
			}
		}
		Parent::startLoad(%cl, %a,%b,%c,%d);
	}
	function GameConnection::spawnPlayer(%client)
	{
		parent::spawnPlayer(%client);

		%client.player.schedule(33, setHats);
	}
	function Armor::onAdd(%db, %pl)
	{
		Parent::onAdd(%db, %pl);

		if(%pl.isCorpse)
		{
			if(isObject(%cl = %pl.client))
			{
				%pl.unHideNode("headskin");
				%pl.unHideNode($hat[%cl.hat]);
				%pl.unHideNode($accent[%cl.accent]);
			}

			%pl.setHats();
		}
	}
	function Armor::onDisabled(%db, %pl, %state)
	{
		Parent::onDisabled(%db, %pl, %state);

		if(isObject(%cl = %pl.client))
			%pl.setHats();
	}
	function Armor::onNewDatablock(%db, %pl)
	{
		Parent::onNewDatablock(%db, %pl);
		
		if(isObject(%cl = %pl.client))
			%pl.setHats();
	}

	function quit(%a,%b)
	{
		export("$HatMod::LastHat*", "config/server/lasthats.cs");
		return Parent::quit(%a,%b);
	}
};
activatepackage(superHat);

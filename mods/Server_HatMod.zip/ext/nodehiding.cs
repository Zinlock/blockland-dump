package HatMod_NodeHiding_Package {
	function GameConnection::applyBodyParts(%client) {
		Parent::applyBodyParts(%client);

		if(isObject(%player = %client.player))// && isObject(%image = %player.getMountedImage(2)) && %image.hatName !$= "")
		{
			if(isObject(%bot = %player.hatBot))
			{
				for(%i = 0; %i < 4; %i++)
				{
					if(isObject(%image = %bot.getMountedImage(%i)))
					{
						if ($HatMod::Nodes::showHat[%image.hatName] == false)
						{
							for(%u=0; $hat[%u] !$= ""; %u++)
								%player.hideNode($hat[%u]);
							
							for(%u=0; $accent[%u] !$= ""; %u++)
								%player.hideNode($accent[%u]);
						}
						
						if ((%list = $HatMod::Nodes::hiddenNodes[%image.hatName]) !$= "")
						{
							for (%u=0; getWord(%list,%u) !$= ""; %u++)
							{
								%player.hideNode(getWord(%list,%u));
							}
						}
					}
				}
			}
		}
	}

	function Player::mountHat(%player, %hat, %slot) {
		parent::mountHat(%player, %hat, %slot);

		if (isHat(%hat) && (%list = $HatMod::Nodes::hiddenNodes[%hat]) !$= "")
		{
			for (%i=0; getWord(%list,%i) !$= ""; %i++)
			{
				%player.hideNode(getWord(%list,%i));
			}
		}
		if (isHat(%hat) && (%list = $HatMod::Nodes::shownNodes[%hat]) !$= "")
		{
			for (%i=0; getWord(%list,%i) !$= ""; %i++)
			{
				%player.hideNode(getWord(%list,%i));
			}
		}
		if (isHat(%hat) && (%list = $HatMod::Nodes::defaultNodes[%hat]) !$= "")
		{
			for (%i=0; getWord(%list,%i) !$= ""; %i++)
			{
				%player.hideNode(getWord(%list,%i));
			}
		}
	}
};
activatePackage(HatMod_NodeHiding_Package);

function HatMod_NodeHiding_CheckHiddenNodes() { //Maybe we can NOT loop through every single hat file again...
	echo("Searching for node settings for Hats...");

	%loc = "Add-ons/HatMod_*/*/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		%pos1 = strLastPos(%dir, "/")-1;
		%pos2 = strLastPos(getSubStr(%dir, 0, %pos1), "/");
		%name = getSubStr(%dir, 1+%pos2, %pos1-%pos2);
		//echo("NAME:" SPC %name);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);
		//echo(getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt");
		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt";
		if(isFile(%configDir)) {
			echo("   Reading node setting file for Hat " @ %name);

			%config = HatMod_GetNodeProperties(%configDir);
		} else
			%config = HatMod_GetNodeProperties("Default");

		%forceHide = getField(%config, 0);
		%showHat = getField(%config, 1);

		if (%config !$= "Default")
		{
			//We should not try to modify the datablock
			//since this add-on may load before HatMod.
			$HatMod::Nodes::hiddenNodes[%name] = %forceHide;
			$HatMod::Nodes::showHat[%name] = %showHat;
			%count++;
			//%evalString = ("Hat" @ %name @ "Data").hiddenNodes = %hiddenNodes;
			//eval(%evalString); //We need to be sure that we add the data after HatMod loads up
			//the hats. This prevents things from messing up if this code loads before HatMod.
		}
	}

	%loc = "Add-ons/HatMod_*/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		if(strPosCount(%dir, "/") != 2) //This filters out any that are Add-ons/HatMod_Whatever/Folder/File.dts
			continue;

		%name = getSubStr(%dir, 1+(%pos = strLastPos(%dir, "/")), strLen(%dir)-%pos-5);
		//echo("NAME:" SPC %name);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);
		//echo(getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt");
		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt";
		if(isFile(%configDir)) {
			echo("   Reading node setting file for Hat " @ %name);

			%config = HatMod_GetNodeProperties(%configDir);
		} else
			%config = HatMod_GetNodeProperties("Default");

		%forceHide = getField(%config, 0);
		%showHat = getField(%config, 1);

		if (%config !$= "Default")
		{
			//We should not try to modify the datablock
			//since this add-on may load before HatMod.
			$HatMod::Nodes::hiddenNodes[%name] = %forceHide;
			$HatMod::Nodes::showHat[%name] = %showHat;
			%count++;
			//%evalString = ("Hat" @ %name @ "Data").hiddenNodes = %hiddenNodes;
			//eval(%evalString); //We need to be sure that we add the data after HatMod loads up
			//the hats. This prevents things from messing up if this code loads before HatMod.
		}
	}

	%loc = "Add-ons/SimpleWell_*/ITEMS/SHAPES/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		%name = getSubStr(%dir, 1+(%pos = strLastPos(%dir, "/")), strLen(%dir)-%pos-5);
		//echo("NAME:" SPC %name);

		//echo("   Found SW hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);
		//echo(getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt");
		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ "_Nodes.txt";
		if(isFile(%configDir)) {
			echo("   Reading node setting file for Hat " @ %name);

			%config = HatMod_GetNodeProperties(%configDir);
		} else
			%config = HatMod_GetNodeProperties("Default");

		%forceHide = getField(%config, 0);
		%showHat = getField(%config, 1);

		if (%config !$= "Default")
		{
			//We should not try to modify the datablock
			//since this add-on may load before HatMod.
			$HatMod::Nodes::hiddenNodes[%name] = %forceHide;
			$HatMod::Nodes::showHat[%name] = %showHat;
			%count++;
			//%evalString = ("Hat" @ %name @ "Data").hiddenNodes = %hiddenNodes;
			//eval(%evalString); //We need to be sure that we add the data after HatMod loads up
			//the hats. This prevents things from messing up if this code loads before HatMod.
		}
	}

	echo("Hat search done. Set node setting for " SPC %count+0 SPC " hat(s).");
}

function HatMod_GetNodeProperties(%configDir) {

	if(%configDir !$= "Default") {
		%file = new fileObject();
		%file.openForRead(%configDir);

		while(!%file.isEOF()) {
			%line = trim(%file.readLine());

			if(%line $= "")
				continue;

			%firstWord = getWord(%line, 0);
			%wordCount = getWordCount(%line);

			switch$(%firstWord) {
				case "keepPlayerHat":
					%show = true;

				case "forceHide":
					%hide = getWords(%line, 1, %wordCount-1);
			}
		}

		%file.close();
		%file.delete();

		return %hide TAB %show;
	}
	else return "Default";
}

function strLastPos(%str, %key)
{
	%strFlip = flipStr(%str);
	%keyFlip = flipStr(%key);

	if (strPos(%strFlip,%keyFlip) == -1) return -1;
	else return (strLen(%strFlip) - strPos(%strFlip,%keyFlip)) - 1;
}

function flipStr(%str)
{
	for (%i = 0; %i < strLen(%str); %i++)
	{
		%strFlip = getSubStr(%str,%i,1) @ %strFlip;
	}
	return %strFlip;
}

HatMod_NodeHiding_CheckHiddenNodes();

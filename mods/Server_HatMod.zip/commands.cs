function serverCmdListHats(%client) {
	%client.chatMessage("\c6     Registered Hats");

	%hatList = "\c6   None  \c7|\c6 ";
	%count = 1;
	for(%i=0; %i < HatMod_HatSet.getCount(); %i++) {
		%hat = HatMod_HatSet.getObject(%i).hatName;

		%hatList = trim(%hatList SPC %hat);
		%hatList = %hatList SPC " \c7|\c6 ";

		%count++;
		if(%count == 4) {
			%client.chatMessage(trim(getWords(%hatList, 0, getWordCount(%hatList)-2)));
			%hatList = "\c6  ";
			%count = 0;
		}
	}
	if(%hatList !$= "\c6  ") {
		%client.chatMessage(trim(getWords(%hatList, 0, getWordCount(%hatList)-2)));
	}
}

$hmdis = false;

function serverCmdHat(%client, %op, %id, %hat)
{
	if($hmdis)
	{
		%client.chatMessage("\c1Hatmod is disabled.");
		return;
	}

	if(mClamp(%id, 1, $HatMod::MaxHats) != %id && %id !$= "")
	{
		%client.chatMessage("\c6Hat slot out of range");
		%op = "";
	}
	
	switch$(%op)
	{
		case "list":
			serverCmdListHats(%client);
		case "set":
			if(!isHat(%hat))
			{
				%client.chatMessage("\c6Invalid hat name");
				return;
			}
			else
			{
				%db = ("Hat" @ %client.superHat[%id-1] @ "Data");
				for(%f = 0; %f < getFieldCount(%db.colorNodes); %f++)
				{
					%node = getField(%db.colorNodes, %f);
					%client.superhatColor[%id-1, %node] = "";
				}

				%client.superhat[%id-1] = %hat;
				%client.chatMessage("\c6Set hat "@ %id @ " to " @ %hat);
			}
		case "remove":
			if(isHat(%client.superHat[%id-1]))
			{
				%client.superhat[%id-1] = "";
				%client.chatMessage("\c6Removed hat "@ %id);
			}
			else
				%client.chatMessage("\c6No hat to be removed in slot "@ %id);
		default:
			%client.chatMessage("\c6Usage: /hat [set/remove] [slot 1-" @ $HatMod::MaxHats @ "] <hat>");
			%client.chatMessage("\c6See also: /colorHat [slot 1-" @ $HatMod::MaxHats @ "] [node] [r] [g] [b] <a>");
			return;
	}

	if(isObject(%client.player))
		%client.player.setHats();
	
	export("$HatMod::LastHat*", "config/server/lasthats.cs");
}

function serverCmdColorHat(%client, %id, %node, %r, %g, %b, %a)
{
	if(mClamp(%id, 1, $HatMod::MaxHats) != %id)
	{
		%client.chatMessage("\c6Hat slot out of range");
		%client.chatMessage("\c6Usage: /colorHat [slot 1-" @ $HatMod::MaxHats @ "] [node] [r] [g] [b] <a>");
		return;
	}

	if(isHat(%client.superHat[%id-1]))
	{
		%hat = ("Hat" @ %client.superHat[%id-1] @ "Data");

		if(%hat.colorNodes $= "")
			%client.chatMessage("\c5Can't color this hat");
		else if(%node !$= "" && (%hat.colorNode[%node] $= "" || !getField(%hat.colorNode[%node], 2)))
			%client.chatMessage("\c5Can't color this node");
		else
		{
			if(%node $= "")
			{
				%client.chatMessage("\c6Colorable nodes for " @ %client.superHat[%id-1] @ ":");
				
				for(%f = 0; %f < getFieldCount(%hat.colorNodes); %f++)
				{
					%node = getField(%hat.colorNodes, %f);
					
					%default = getField(%hat.colorNode[%node], 0);
					%transparent = getField(%hat.colorNode[%node], 1);
					%recolorable = getField(%hat.colorNode[%node], 2);

					if(%recolorable)
						%client.chatMessage("\c6" @ trim(strLwr(%node)) @ ": default " @ (%transparent ? trim(%default) : getWords(trim(%default), 0, 2) @ " (opaque)"));
				}
			}
			else if(%r $= "")
			{
				%client.superhatColor[%id-1, %node] = "";
				%client.chatMessage("\c6Reset hat "@ %id SPC %node @" color");
			}
			else
			{
				if(%a $= "" || !getField(%hat.colorNode[%node], 2))
					%a = 1;
				
				%client.superhatColor[%id-1, %node] = %r*1 SPC %g*1 SPC %b*1 SPC %a*1;
				%client.chatMessage("\c6Colored hat "@ %id SPC %node);
			}
		}
	}
	else
		%client.chatMessage("\c6No hat to be colored in slot "@ %id);
	
	if(isObject(%client.player))
		%client.player.setHats();

	export("$HatMod::LastHat*", "config/server/lasthats.cs");
}
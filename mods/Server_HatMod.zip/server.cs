////////////////////////////////////////////
/////////////////Modularity/////////////////
////////////////////////////////////////////

$HatMod::MaxHats = 4;

function isHat(%hat) {
	return isObject("hat" @ %hat @ "data");
}

function GameConnection::hasHat(%client, %hat) {
	// %hat = strReplace(%hat, " ", "_");
	// if(isHat(%hat) && ($HatMod::save::hats[%client.bl_id, %hat] >= 1 || $Pref::HatMod::HatAccess))
	 	return 1;
	// return 0;
}

function HatMod_getRandomHat() {
	return HatMod_HatSet.getObject(getRandom(0, HatMod_HatSet.getCount()-1)).hatName;
}

function GameConnection::getRandomHat(%client) {
	for(%hatsDone=0; %hatsDone < HatMod_HatSet.getCount(); %hatsDone++) {
		%hat = HatMod_getRandomHat();

		if(%hasTried[strReplace(%hat, " ", "_")]) {
			%hatsDone--;
			continue;
		}

		if(%client.hasHat(%hat)) {
			%hatFound = 1;
			break;
		}

		%hasTried[strReplace(%hat, " ", "_")] = 1;

		if(%breaker++ > 150)
			return 0;
	}
	if(!%hatFound)
		return 0;
	return %hat;
}


function Player::mountHat(%player, %hat, %slot) {
	if(!isHat(%hat)) {
		error("Error: Player::mountHat: Hat does not exist!" SPC %player SPC %hat);
		return;
	}

	if(%slot < 0 || %slot > $HatMod::MaxHats - 1 || %slot $= "")
		%slot = 0;

	%h = ("Hat" @ strReplace(%hat, " ", "_") @ "Data");
	if(isObject(%b = %player.hatBot[%slot]))
		%b.delete();

	%player.mountHatBot(%h, %slot);
	
	%player.hatVisLoop();

	//Hide all hat and accent nodes
	for(%i=0; $hat[%i] !$= ""; %i++)
		%player.hideNode($hat[%i]);

	for(%i=0; $accent[%i] !$= ""; %i++)
		%player.hideNode($accent[%i]);
}

function Player::hatVisLoop(%player)
{
	cancel(%player.hvisloop);

	if(!isObject(%player) || !isObject(%player.client) || %player.isBody || %player.isCorpse)
		return;
	
	%found = 0;

	for(%i = 0; %i < $HatMod::MaxHats; %i++)
	{
		if(isObject(%player.hatBot[%i]))
		{
			%found = 1;
			if(%player.isFirstPerson())
			{
				if(!%player.hatBot[%i].isHidden)
				{
					%player.hatBot[%i].isHidden = true;

					if($HatMod::Debug)
						talk("stopping hat ghosting for" SPC %player.client);
					// player is in first person, hide the hat
					%player.hatBot[%i].clearScopeAlways();
					%player.hatBot[%i].setNetFlag(6, true);
					for(%j = 0; %j < ClientGroup.getCount(); %j++)
					{
						if((%cl = ClientGroup.getObject(%j)) != %player.client)
						{
							if($HatMod::Debug)
								talk(%cl);
							%player.hatBot[%i].scopeToClient(%cl);
						}
					}
				}
			}
			else
			{
				if(%player.hatBot[%i].isHidden)
				{
					%player.hatBot[%i].isHidden = false;

					if($HatMod::Debug)
						talk("resuming hat ghosting for" SPC %player.client);
					// player is in third person, show the hat
					%player.hatBot[%i].setScopeAlways();
					%player.hatBot[%i].setNetFlag(6, false);
				}
			}
		}
	}

	if(%found)
		%player.hvisloop = %player.schedule(32, hatVisLoop);
}

function Player::setHats(%pl)
{
	if(isObject(%cl = %pl.client) && isObject(%pl))
	{
		if(!%pl.isCorpse && %cl.getClassName() !$= "AIPlayer")
			%cl.unMountAllHats();

		for(%i = 0; %i < $HatMod::MaxHats; %i++) {
			%img = %cl.superhat[%i];

			if(isHat(%img))
				%pl.mountHat(%img,%i);

			$HatMod::LastHat[%cl.bl_id, %i] = %img;

			%hat = %pl.hatBot[%i];
			if(isObject(%hat))
			{
				%db = ("Hat" @ strReplace(%img, " ", "_") @ "Data");

				%fade = 0;

				for(%f = 0; %f < getFieldCount(%db.colorNodes); %f++)
				{
					%node = getField(%db.colorNodes, %f);
					
					%default = getField(%db.colorNode[%node], 0);
					%transparent = getField(%db.colorNode[%node], 1);
					%recolorable = getField(%db.colorNode[%node], 2);

					if(!%recolorable || %cl.superhatColor[%i, %node] $= "")
					{
						if(!%transparent)
							%default = setWord(%default, 3, "1");
						
						%hat.setNodeColor(%node, %default);
						$HatMod::LastHatColor[%cl.bl_id, %i, %node] = "";
					}
					else
					{
						if(!%transparent)
							%cl.superhatColor[%i, %node] = setWord(%cl.superhatColor[%i, %node], 3, "1");

						%hat.setNodeColor(%node, %cl.superhatColor[%i, %node]);
						
						$HatMod::LastHatColor[%cl.bl_id, %i, %node] = %cl.superhatColor[%i, %node];
					}

					if(%transparent)
						%fade = 1;
				}

				if(%fade)
					%hat.startFade(1,0,1);
				else
					%hat.startFade(1,0,0);
			}
		}

		if(!%pl.isCorpse)
		{
			%cl.applyBodyParts();
			%cl.applyBodyColors();
		}
		else if(!isObject(%cl.player))
		{
			%cl.player = %pl;
			%cl.applyBodyParts();
			%cl.applyBodyColors();
			%cl.player = -1;
		}
	}
}

function GameConnection::dismountHat(%cl, %node) {
	if(isObject(%pl = %cl.player) && isObject(%pl.hatBot[%node])) {
		%pl.hatBot[%node].delete();
	}
}

function GameConnection::unmountAllHats(%cl) {
	for(%i = 0; %i < $HatMod::MaxHats; %i++)
		%cl.dismountHat(%i);

	if(isObject(%pl = %cl.player))
	{
		%pl.unHideNode("headskin");
		%pl.unHideNode($hat[%cl.hat]);
		%pl.unHideNode($accent[%cl.accent]);

		%cl.applyBodyColors();
		%cl.applyBodyParts();

		cancel(%pl.hvisloop);
	}
}

////////////////////////////////////////////
/////////////Hat registeration//////////////
////////////////////////////////////////////

function HatMod_registerHat(%name, %dir, %offset, %eyeOffset) {
	if(isHat(%name)) {
		echo("Error: Hat already exists! (" @ strReplace(%name, "_", " ") @ ")");
		HatMod_HatSet.add("Hat" @ %name @ "Data");
		return 0;
	}

	// %evalString =	"datablock ShapeBaseImageData(Hat" @ %name @ "Data) {" SPC
	// 							"shapeFile = %dir;" SPC
	// 							"mountPoint = $HeadSlot;" SPC
	// 							"offset = %offset;" SPC
	// 							"eyeOffset = %eyeOffset;" SPC
	// 							"rotation = eulerToMatrix(\"0 0 0\");" SPC
	// 							"scale = \"0.1 0.1 0.1\";" SPC
	// 							"doColorShift = false;" SPC
	// 							"hatName = %name;" SPC
	//							"};";

	%evalString = "datablock PlayerData(Hat" @ %name @ "Data : EmptyAI) {" SPC
								"shapeFile = %dir;" SPC
								"hatName = %name;" SPC
								"};";

	eval(%evalString);
	HatMod_HatSet.add("Hat" @ %name @ "Data");

	return 1;
}

function HatMod_registerAllHats() {
	echo("looking for hats");

	if(isObject(HatMod_HatSet))
		HatMod_HatSet.clear();

	%loc = "Add-ons/HatMod_*/*/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		%pos1 = strLastPos(%dir, "/")-1;
		%pos2 = strLastPos(getSubStr(%dir, 0, %pos1), "/");
		%name = getSubStr(%dir, 1+%pos2, %pos1-%pos2);
		//echo("NAME:" SPC %name);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);

		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ ".txt";
		if(isFile(%configDir)) {
			echo("   Reading file for calibration.");

			%config = HatMod_GetProperties(%configDir);
		} else
			%config = HatMod_GetProperties("Default");

		%offset = getField(%config, 0);
		%minVer = getField(%config, 1);
		%eyeOffset = getField(%config, 2);

		if(HatMod_registerHat(%name, %dir, %offset, %eyeOffset)) {
			//echo("   Hat" SPC strReplace(%name, "_", " ") SPC "registered successfully.");
			%count++;
		}
	}

	%loc = "Add-ons/HatMod_*/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		if(strPosCount(%dir, "/") != 2) //This filters out any that are Add-ons/HatMod_Whatever/Folder/File.dts
			continue;

		%name = getSubStr(%dir, 1+(%pos = strLastPos(%dir, "/")), strLen(%dir)-%pos-5);
		//echo("NAME:" SPC %name);

		//echo("   Found hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);

		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")+1) @ %name @ ".txt";
		if(isFile(%configDir)) {
			echo("   Reading file for calibration.");

			%config = HatMod_GetProperties(%configDir);
		} else
			%config = HatMod_GetProperties("Default");

		%offset = getField(%config, 0);
		%minVer = getField(%config, 1);
		%eyeOffset = getField(%config, 2);

		if(HatMod_registerHat(%name, %dir, %offset, %eyeOffset)) {
			//echo("   Hat" SPC strReplace(%name, "_", " ") SPC "registered successfully.");
			%count++;
		}
	}

	%loc = "Add-ons/SimpleWell_*/ITEMS/SHAPES/*.dts";
	for(%dir = findFirstFile(%loc); %dir !$= ""; %dir = findNextFile(%loc)) {
		//echo("DIR:" SPC %dir);
		%name = getSubStr(%dir, 1+(%pos = strLastPos(%dir, "/")), strLen(%dir)-%pos-5);
		//echo("NAME:" SPC %name);

		//echo("   Found SW hat:" SPC strReplace(%name, "_", " ") SPC "at dir" SPC %dir);

		%configDir = getSubStr(%dir, 0, strLastPos(%dir, "/")-6) @ %name @ ".cs";

		if(isFile(%configDir)) {
			echo("   Reading file for calibration.");

			%config = HatMod_GetProperties(%configDir);
		} else
			%config = HatMod_GetProperties("Default");

		%offset = getField(%config, 0);
		%minVer = getField(%config, 1);
		%eyeOffset = getField(%config, 2);

		if(HatMod_registerHat(%name, %dir, %offset, %eyeOffset)) {
			//echo("   Hat" SPC strReplace(%name, "_", " ") SPC "registered successfully.");
			%count++;
		}
	}

	echo("registered" SPC %count SPC "hats");
}

function HatMod_GetProperties(%configDir) {
	%offset = "0 0 0";
	%minVer = "0";
	%eyeOffset = "0 0 -1000";

	if(%configDir !$= "Default") {
		%file = new fileObject();
		%file.openForRead(%configDir);

		while(!%file.isEOF()) {
			%line = trim(%file.readLine());

			if(%line $= "")
				continue;

			%firstWord = getWord(%line, 0);
			%wordCount = getWordCount(%line);

			switch$(%firstWord) {
			case "offset":
				%offset = getWords(%line, %wordCount-3, %wordCount-1);
				%offset = strReplace(%offset, "\"", "");
				%offset = strReplace(%offset, ";", "");
				%offset = vectorAdd(%offset, "0 0 0"); //Forces it to be a 3d vector

			case "minVer":
				%minVer = getWord(%line, getWordCount(%line)-1);

			case "eyeOffset":
				%eyeOffset = getWords(%line, %wordCount-3, %wordCount-1);
				%eyeOffset = strReplace(%eyeOffset, "\"", "");
				%eyeOffset = strReplace(%eyeOffset, ";", "");
				%eyeOffset = vectorAdd(%eyeOffset, "0 0 0"); //Forces it to be a 3d vector
			}
		}

		%file.close();
		%file.delete();
	}

	return %offset TAB %minVer TAB %eyeOffset;
}

////////////////////////////////////////////
/////////////////Resources//////////////////
////////////////////////////////////////////

function strLastPos(%str, %search, %offset) {
	if(%offset > 0)
		%pos = %offset;
	else {
		%str = getSubStr(%str, 0, strLen(%str) + %offset);
		%pos = 0;
	}
	%lastPos = -1;
	while((%pos = strPos(%str, %search, %pos+1)) > 0) {
		%lastPos = %pos;
		if(%break++ >= 500) //Pretty sure strings have a max length shorter than this, should be fine
			return -2;
	}
	return %lastPos;
}

function strPosCount(%str, %search, %offset) {
	if(getSubStr(%str, %offset, strLen(%search)) $= %search) //Manual search for the first one
		%count = 1;

	if(%offset $= "")
		%offset = 0;

	%pos = %offset;

	while((%pos = strPos(%str, %search, %pos+1)) > 0)
		%count++;
	return %count;
}

exec("./support_bots.cs");

$Pref::HatMod::HatAccess = true;

if(isFile("Config/Server/" @ $Pref::HatMod::SaveLoc @ ".cs"))
	exec("Config/Server/" @ $Pref::HatMod::SaveLoc @ ".cs");

exec("./package.cs");
exec("./commands.cs");
exec("./events.cs");

if(!isObject(HatMod_HatSet)) {
	new SimSet(HatMod_HatSet);
	missionCleanup.add(HatMod_HatSet);
}

if(!$HatMod::Debug) //Just something so i can reload the addon without re-registering all the hats.
	HatMod_registerAllHats();

exec("./ext/superhat.cs");
exec("./ext/nodehiding.cs");
exec("./ext/colors.cs");
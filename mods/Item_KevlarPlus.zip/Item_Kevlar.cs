$kevlarLHealth = 120;
$kevlarLMult = 0.5;
$kevlarLPierce = 50;
$kevlarLPierceMult = 0.9;

$kevlarMHealth = 210;
$kevlarMMult = 0.3;
$kevlarMPierce = 65;
$kevlarMPierceMult = 0.75;

$kevlarHHealth = 300;
$kevlarHMult = 0.1;
$kevlarHPierce = 80;
$kevlarHPierceMult = 0.6;

datablock ItemData( armorKevlarItem : hammerItem )
{
	category = "Item";
	shapeFile = "./vest_light.dts";

	uiName = "Armor Light";
	iconName = "./light_kevlar";

	isArmor = true;
	health = $kevlarLHealth;
	multiplier = $kevlarLMult;
	pierce = $kevlarLPierce;
	pierceMult = $kevlarLPierceMult;
	equip = armorKevlarEquippedImage;

	equipSound = kevlarEquipSound;
	equipSounds = 2;
	breakSound = kevlarBreakSound;
	breakSounds = 1;
	hitSound = kevlarHitSound;
	hitSounds = 3;

	doColorShift = true;
	colorShiftColor = "0.25 0.25 0.4 1.0";

	image = armorKevlarImage;
	canDrop = true;
};

datablock shapeBaseImageData( armorKevlarImage )
{
	shapeFile = "./vest_light.dts";

	mountPoint = 0;
	offset = "0 0 -0.5";

	doColorShift = true;
	colorShiftColor = armorKevlarItem.colorShiftColor;

	item = armorKevlarItem;

	className = "WeaponImage";
	armReady = true;

	stateName[0]					= "Activate";
	stateTimeoutValue[0]			= 0.1;
	stateTransitionOnTimeout[0]		= "Ready";

	stateName[1] 					= "Ready";
	stateScript[1]					= "onUse";
	stateTransitionOnTriggerDown[1]	= "Fire";
	stateAllowImageChange[1]		= true;

	stateName[2]					= "Fire";
	stateTransitionOnTriggerUp[2]	= "Ready";
	stateScript[2]					= "onFire";
};

datablock shapeBaseImageData( armorKevlarEquippedImage )
{
	shapeFile = "./vest_light.dts";

	mountPoint = 7;//2;
	offset = "0 -0.005 0.015";//"0 0.05 -0.25";

	eyeOffset = "-9999 -9999 -9999";

	doColorShift = true;
	colorShiftColor = armorKevlarItem.colorShiftColor;

	className = "WeaponImage";
	armReady = false;
};

function armorKevlarImage::onFire( %this, %obj, %slot )
{
	%data = %this.item;

	%obj.mountArmor(%data);

	messageClient( %obj.client, 'MsgItemPickup', '', %obj.currTool, 0 );
	%obj.tool[ %obj.currTool ] = 0;
	serverCmdUnUseTool( %obj.client );
}

function armorKevlarEquippedImage::onUnMount( %this, %obj )
{
	%obj.armor = 0;
	%obj.armorMult = 1;
	%obj.armored = false;
}

// medium armor

datablock ItemData( armorKevlarMediumItem : armorKevlarItem )
{
	shapeFile = "./vest_medium.dts";

	uiName = "Armor Medium";
	iconName = "./medium_kevlar";

	health = $kevlarMHealth;
	multiplier = $kevlarMMult;
	pierce = $kevlarMPierce;
	pierceMult = $kevlarMPierceMult;
	equip = armorKevlarMediumEquippedImage;

	colorShiftColor = "0.4 0.45 0.2 1.0";

	image = armorKevlarMediumImage;
};

datablock shapeBaseImageData( armorKevlarMediumImage : armorKevlarImage )
{
	shapeFile = "./vest_medium.dts";
	colorShiftColor = armorKevlarMediumItem.colorShiftColor;
	item = armorKevlarMediumItem;
};

datablock shapeBaseImageData( armorKevlarMediumEquippedImage : armorKevlarEquippedImage )
{
	shapeFile = "./vest_medium.dts";
	colorShiftColor = armorKevlarMediumItem.colorShiftColor;
};

function armorKevlarMediumImage::onFire( %this, %obj, %slot ) { armorKevlarImage::onFire( %this, %obj, %slot ); }
function armorKevlarMediumEquippedImage::onUnMount( %this, %obj, %slot ) { armorKevlarEquippedImage::onUnMount( %this, %obj, %slot ); }

// heavy armor

datablock ItemData( armorKevlarHeavyItem : armorKevlarItem )
{
	shapeFile = "./vest_heavy.dts";

	uiName = "Armor Heavy";
	iconName = "./heavy_kevlar";

	health = $kevlarHHealth;
	multiplier = $kevlarHMult;
	pierce = $kevlarHPierce;
	pierceMult = $kevlarHPierceMult;
	equip = armorKevlarHeavyEquippedImage;

	colorShiftColor = "0.25 0.25 0.2 1.0";

	image = armorKevlarHeavyImage;
};

datablock shapeBaseImageData( armorKevlarHeavyImage : armorKevlarImage )
{
	shapeFile = "./vest_heavy.dts";
	colorShiftColor = armorKevlarHeavyItem.colorShiftColor;
	item = armorKevlarHeavyItem;
};

datablock shapeBaseImageData( armorKevlarHeavyEquippedImage : armorKevlarEquippedImage )
{
	shapeFile = "./vest_Heavy.dts";
	colorShiftColor = armorKevlarHeavyItem.colorShiftColor;
};

function armorKevlarHeavyImage::onFire( %this, %obj, %slot ) { armorKevlarImage::onFire( %this, %obj, %slot ); }
function armorKevlarHeavyEquippedImage::onUnMount( %this, %obj, %slot ) { armorKevlarEquippedImage::onUnMount( %this, %obj, %slot ); }

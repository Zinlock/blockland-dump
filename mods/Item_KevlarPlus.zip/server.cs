// Item_KevlarPlus: edit of Item_Kevlar with new models and more vest types by Oxy

datablock audioProfile( kevlarHitSound0 )
{
	fileName = "./impact1.wav";
	description = audioClosest3D;
	preload = true;
};

datablock audioProfile( kevlarHitSound1 )
{
	fileName = "./impact2.wav";
	description = audioClosest3D;
	preload = true;
};

datablock audioProfile( kevlarHitSound2 )
{
	fileName = "./impact3.wav";
	description = audioClosest3D;
	preload = true;
};

datablock audioProfile( kevlarBreakSound )
{
	fileName = "./break.wav";
	description = audioClosest3D;
	preload = true;
};

datablock audioProfile( kevlarEquipSound0 )
{
	fileName = "./equip1.wav";
	description = audioClosest3D;
	preload = true;
};

datablock audioProfile( kevlarEquipSound1 )
{
	fileName = "./equip2.wav";
	description = audioClosest3D;
	preload = true;
};

exec("./Item_Kevlar.cs");

function registerArmorEvents()
{
	%str = "list None 0";
	%cts = 0;

	for(%i = 0; %i < dataBlockGroup.getCount(); %i++)
	{
		%db = dataBlockGroup.getObject(%i);
		if(%db.isArmor)
		{
			%str = %str SPC getSafeVariableName(%db.uiName) SPC %cts+1;
			$kevlarArmor[%cts] = %db;
			%cts++;
			$kevlarArmorCount = %cts;
		}
	}

	registerOutputEvent("Player", "setArmor", %str);
	registerOutputEvent("Bot", "setArmor", %str);
}

function Player::mountArmor(%obj, %data)
{
	if(!%data.isArmor)
		return;

	%obj.unmountimage( 2 );
	%obj.mountimage( %data.equip, 2 );
	
	%sfx = %data.equipSound;
	
	if(%data.equipSounds > 1)
		%sfx = %sfx @ getRandom(0, %data.equipSounds-1);
	
	serverPlay3d( %sfx, %obj.getHackPosition() );

	%obj.armor = %data.health;
	%obj.armorPierce = %data.pierce;
	%obj.armorPierceMult = %data.pierceMult;
	%obj.armorMult = %data.multiplier;
	%obj.armorBreakSound = %data.breakSound;
	%obj.armorBreakSounds = %data.breakSounds;
	%obj.armorSound = %data.hitSound;
	%obj.armorSounds = %data.hitSounds;
	%obj.armored = true;
}

function Player::setArmor(%obj, %idx)
{
	if(%idx == 0)
		%obj.unmountImage(2);
	else
	{
		if(isObject(%data = $kevlarArmor[%idx-1]) && %data.isArmor)
			%obj.mountArmor(%data);
	}
}

function AIPlayer::setArmor(%obj, %idx)
{
	if(%idx == 0)
		%obj.unmountImage(2);
	else
	{
		if(isObject(%data = $kevlarArmor[%idx-1]) && %data.isArmor)
			%obj.mountArmor(%data);
	}
}

schedule(0, 0, registerArmorEvents);

package armor_functions
{
	function Player::Damage( %this, %obj, %pos, %damage, %damageType )
	{
		if( %this.armored && %damage > 0 )
		{
			%armor = %this.armor;
			%this.armor -= %damage;

			%dmg = %damage;

			if(%damage < %this.armorPierce)
				%dmg = mClampF(%damage, 0, %armor) * %this.armorMult;
			else
				%dmg = mClampF(%damage, 0, %armor) * %this.armorPierceMult;

			if(%damage > %armor)
				%dmg += %damage - %armor;
			
			%damage = %dmg;

			if( %this.armor <= 0 )
			{
				%sfx = %this.armorBreakSound;

				if(%this.armorBreakSounds > 1)
					%sfx = %sfx @ getRandom(0, %this.armorBreakSounds-1);

				serverPlay3d( %sfx, %this.getHackPosition() );
				%this.unmountImage( 2 );
			}
			else
			{
				%sfx = %this.armorSound;

				if(%this.armorSounds > 1)
					%sfx = %sfx @ getRandom(0, %this.armorSounds-1);

				serverPlay3d( %sfx, %this.getHackPosition() );
			}

			commandToClient( %this.client, 'bottomprint', "<just:right><font:impact:21><color:dbd21f>Armor <font:impact:28>\c6" SPC MCeil( %this.armor ), 3, true );
		}

		parent::Damage( %this, %obj, %pos, %damage, %damageType );
	}
};
activatePackage(armor_functions);
// By Oxy (260031)
// The amount of stupid, hacky workarounds of this kind I had to make for the Tribal War project is ridiculous

// This script fixes vehicles not being linked to a minigame when the owner leaves
// Assumes you only ever have one, default minigame running; disable this otherwise

// This pref is exposed as a command because the RTB pref manager on v20 is absolutely horrendous

if($Pref::Server::doVmgFix $= "") $Pref::Server::doVmgFix = true;

function serverCmdVMG(%cl)
{
	if(%cl.isSuperAdmin)
	{
		if($Pref::Server::doVmgFix)
		{
			messageClient(%cl, '', "\c5VMG Fix is now \c3disabled");
			$Pref::Server::doVmgFix = false;
		}
		else
		{
			messageClient(%cl, '', "\c5VMG Fix is now \c3enabled");
			$Pref::Server::doVmgFix = true;
		}
	}
}

function vmgGetDefaultMinigame()
{
	if(isObject($DefaultMiniGame)) // not used before v21 (?)
		return $DefaultMiniGame;

	if(isObject(Slayer.Minigames))
	{
		for(%i = 0; %i < Slayer.Minigames.getCount(); %i++)
		{
			%mg = Slayer.Minigames.getObject(%i);

			if(%mg.isDefaultMinigame)
				return %mg;
		}
	}

	return -1;
}

package VehicleMGFix
{
	function getMiniGameFromObject(%obj)
	{
		if(isObject(%obj))
		{
			if($Pref::Server::doVmgFix)
			{
				if((%obj.getType() & $TypeMasks::VehicleObjectType) || %obj.getClassName() $= "AIPlayer")
				{
					if(isObject(%obj.spawnBrick))
					{
						if(isObject(%mg = vmgGetDefaultMinigame()))
							return %mg;
					}
				}
			}
		}

		return Parent::getMiniGameFromObject(%obj);
	}
};
activatePackage(VehicleMGFix);
function du()
{
	exec("./server.cs");
}

trace2(1);

function respawnEnvironment()
{
	while(isObject(sky)) sky.delete();
	while(isObject(sun)) sun.delete();
	while(isObject(sunLight)) sunLight.delete();
	while(isObject(dayCycle)) dayCycle.delete();
	while(isObject(groundPlane)) groundPlane.delete();

	new Sky(sky);
	new Sun(sun);
	new FxSunLight(sunLight);
	new FxDayCycle(dayCycle);
	new FxPlane(groundPlane) { position = "0 0 -0.5"; };

	setupDefaultEnvironment();

	for(%i = 0; %i < ClientGroup.getCount(); %i++)
		ClientGroup.getObject(%i).setEnvironment($DefaultEnvironment);
}

function hotloadAddon(%name)
{
	%path = "Add-Ons/" @ %name @ "/server.cs";
	if(!isFile(%path))
	{
		error("hotloadAddon() - add-on " @ %name @ " does not exist");
		return;
	}

	if(!$AddOn__[%name] || $AddOn__[%name] == -1)
	{
		$AddOn__[%name] = true;

		exec(%path);
		$AddOnLoaded__[%name] = true;
	}

	export("$AddOn__*", "config/server/ADD_ON_LIST.cs");
}

// makeWeaponWall(%pl.getHackPosition(), %cl.brickGroup, BrickRandomItemSpawnData);
function makeWeaponWall(%pos, %group, %brickDb)
{
	%weps = 0;
	%cts = DataBlockGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%db = DataBlockGroup.getObject(%i);

		if(%db.getClassName() $= "ItemData" && %db.uiName !$= "" && %db.category $= "Weapon")
		{
			%brk = new FxDtsBrick()
			{
				datablock = %brickDb;
				position = vectorAdd(%pos, (%brickDb.brickSizeX * (%weps % 32)) SPC (%brickDb.brickSizeY * (mFloor(%weps / 32) % 32)) @ " 0");
				isPlanted = true;
				colorId = 0;
			};

			%brk.plant();

			%group.add(%brk);

			%brk.schedule(0, setItem, %db);

			%weps++;
		}
	}
}

// setLogMode(0);setLogMode(6);trace(1);schedule(100,0,trace,0);schedule(100,0,setLogMode,0);
// setLogMode(0);setLogMode(6);locateUsedBricks(1);setLogMode(0);

function AIPlayer::swol_addKill() {}

function cleanupStatics()
{
	%cts = MissionCleanup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionCleanup.getObject(%i);

		%class = %obj.getClassName();
		if(%class $= "StaticShape")
		{
			%obj.delete();
			%count++;
			%i--;
			%cts--;
		}
	}
}

// dumps the list of brick mods in use by the current build
function locateUsedBricks(%silent)
{
	%defaults = 0;
	%customs = 0;
	%unknowns = 0;

	%cts = mainBrickGroup.getCount();
	for(%m = 0; %m < %cts; %m++)
	{
		%group = mainBrickGroup.getObject(%m);

		%ct2 = %group.getCount();
		for(%i = 0; %i < %ct2; %i++)
		{
			%brk = %group.getObject(%i);
			%db = %brk.getDataBlock();
			%shape = trim(%db.brickFile);

			if(stripos(%shape, "base/data/") == 0)
				%defaults++;
			else if(stripos(%shape, "add-ons/") == 0)
			{
				%addonName = getSubStr(%shape, 8, 256);
				%addonName = getSubStr(%addonName, 0, stripos(%addonName, "/"));

				if(%customIdx[%addonName] $= "")
				{
					%customIdx[%addonName] = %customs;
					%custom[%customs] = %addonName;
					%customCount[%customs] = 1;
					%customs++;
				}
				else
					%customCount[%customIdx[%addonName]]++;
			}
			else
			{
				if(%unknownIdx[%shape] $= "")
				{
					%unknownIdx[%shape] = %unknowns;
					%unknown[%unknowns] = %shape;
					%unknownCount[%unknowns] = 1;
					%unknowns++;
				}
				else
					%unknownCount[%unknownIdx[%unknowns]] = 1;
			}
		}
	}

	if(!%silent)
		talk("Bricks in use:");
	echo("Bricks in use:");

	if(!%silent)
		talk("default: \c2" @ %defaults @ "x");
	echo("default: " @ %defaults @ "x");

	for(%i = 0; %i < %customs; %i++)
	{
		if(!%silent)
			talk(%custom[%i] @ ": \c2" @ %customCount[%i] @ "x");
		echo(%custom[%i] @ ": " @ %customCount[%i] @ "x");
	}

	for(%i = 0; %i < %unknowns; %i++)
	{
		if(!%silent)
			talk("(?) " @ %unknown[%i] @ ": \c2" @ %unknownCount[%i] @ "x");
		echo("(?) " @ %unknown[%i] @ ": " @ %unknownCount[%i] @ "x");
	}
}

function addExtraResource(%fileName)
{
	// Don't add the same file multiple times
	if (!ServerGroup.addedExtraResource[%fileName])
	{
		// Maintain a list of "extra" files so we can work nicely with the existing
		// resources, and call PopulateEnvResourceList without getting overwritten.
		if (ServerGroup.extraResourceCount $= "")
			ServerGroup.extraResourceCount = 0;

		ServerGroup.extraResource[ServerGroup.extraResourceCount] = %fileName;
		ServerGroup.extraResourceCount++;

		ServerGroup.addedExtraResource[%fileName] = true;
	}
}

package ExtraResources
{
	function EnvGuiServer::PopulateEnvResourceList()
	{
		Parent::PopulateEnvResourceList();

		for (%i = 0; %i < ServerGroup.extraResourceCount; %i++)
		{
			$EnvGuiServer::Resource[$EnvGuiServer::ResourceCount] = ServerGroup.extraResource[%i];
			$EnvGuiServer::ResourceCount++;
		}
	}
}; activatePackage(ExtraResources);

if(!isObject(ActiveDownloadSet))
	new SimSet(ActiveDownloadSet);

function ReloadAssets(%nextSequence, %quickReload)
{
	if(ActiveDownloadSet.getCount() > 0)
	{
		messageAll('', "\c6" @ ActiveDownloadSet.getCount() SPC "users are still downloading new assets.");
		return;
	}

	echo(" -- Reloading Assets");
	messageAll('', "\c6Loading new files...");

	if(%nextSequence)
		$MissionSequence++;

	setManifestDirty();
	%hash = snapshotGameAssets();

	if($Version == 21)
		EnvGuiServer::PopulateEnvResourceList();

	if(%quickReload)
	{
		if(!isObject(ActiveDownloadSet))
			new SimSet(ActiveDownloadSet);

		for(%i = 0; %i < ClientGroup.getCount(); %i++)
		{
			%cl = ClientGroup.getObject(%i);
			if(!%cl.hasSpawnedOnce)
			{
				commandToClient(%cl, 'GameModeChange');
				%cl.delete("New assets have been loaded in. Rejoin to download them.");
			}
			else
			{
				%cl.sendManifest(%hash);
				ActiveDownloadSet.add(%cl);
			}
		}
	}
	else
	{
		for(%i = 0; %i < ClientGroup.getCount(); %i++)
		{
			%cl = ClientGroup.getObject(%i);

			if($Version == 21)
			{
				if(!%nextSequence && !%cl.hasSpawnedOnce)
				{
					commandToClient(%cl, 'GameModeChange');
					%cl.delete("New assets have been loaded in. Rejoin to download them.");
				}

				%msg = "<font:impact:32>Assets are being reloaded!<br><font:impact:18>Your screen will look messed up while loading, please wait";
				commandToClient(%cl, 'MessageBoxOK', "Reloading Assets", %msg);
				schedule(1000, %cl, commandToClient, %cl, 'MessageBoxOK', "Reloading Assets", %msg);
				schedule(2000, %cl, commandToClient, %cl, 'MessageBoxOK', "Reloading Assets", %msg);
				schedule(3000, %cl, commandToClient, %cl, 'MessageBoxOK', "Reloading Assets", %msg);
			}
			
			%cl.resetGhosting();

			if($Version != 21)
				sendLoadInfoToClient(%cl);

			%cl.hasSpawnedOnce = false;
			%cl.respawnSequence = $MissionSequence;
			%cl.endMission();

			%cl.schedule(3000, loadMission);
		}
	}

	createUINameTable();
}

$NeverRespawnVehicles = true;

package ReDownload
{
	function GameConnection::spawnPlayer(%client)
	{
		if(%client.respawnSequence == $missionSequence)
		{
			if(isObject($DefaultEnvironment))
				$DefaultEnvironment.scopeToClient(%client);

			messageAll('', "\c6Client " @ %client.name @ " finished loading.");
			echo(" -- Client " @ %client @ " (" @ %client.name @ ") finished loading");

			%client.respawnSequence = "";
			%client.hasSpawnedOnce = true;
			return;
		}
		
		Parent::spawnPlayer(%client);
	}

	function GameConnection::onClientEnterGame(%client)
	{
		%client.isJoining = true;

		Parent::onClientEnterGame(%client);
	}

	function GameConnection::resetVehicles(%client)
	{
		if($NeverRespawnVehicles && (%client.isJoining || %client.isLeaving))
		{
			%client.isJoining = false;
			%client.isLeaving = false;
			return;
		}
		
		Parent::resetVehicles(%client);
	}

	function serverCmdBlobDownloadFinished(%client)
	{
		parent::serverCmdBlobDownloadFinished(%client);

		if(ActiveDownloadSet.isMember(%client))
		{
			ActiveDownloadSet.remove(%client);
			%client.transmitDatablocks($MissionSequence);
			commandToClient(%client, 'missionStartPhase3');
			
			messageAll('', "\c6Client " @ %client.name @ " finished loading.");
			echo(" -- Client " @ %client @ " (" @ %client.name @ ") finished loading");

			if(ActiveDownloadSet.getCount() == 0)
			{
				schedule(1000, 0, messageAll, '', "\c6All assets loaded.");
				schedule(1000, 0, echo, " -- Reload complete");
			}
		}
	}

	function GameConnection::onClientLeaveGame(%client)
	{
		if(ActiveDownloadSet.isMember(%client))
		{
			ActiveDownloadSet.remove(%client);

			if(ActiveDownloadSet.getCount() == 0)
				schedule(1000, 0, messageAll, '', "\c6All assets loaded.");
		}
		
		%client.isLeaving = true;

		parent::onClientLeaveGame(%client);
	}
};
activatePackage(ReDownload);

function HardDelete(%objs) // shitty, hacky function for deleting datablocks
{	
	%g = new ScriptGroup();
	for(%i = 0; %i < getWordCount(%objs); %i++)
	{
		if(isObject(%obj = getWord(%objs, %i)))
			%g.add(%obj);
	}
	%g.delete();
}

function locateDuplicates(%pat)
{
	deleteVariables("$fileDuplicate*");

	$fileDuplicateCount = 0;

	%file = findFirstFile(%pat);
	while(isFile(%file))
	{
		%crc = getFileCRC(%file);

		if($fileDuplicate[%crc] !$= "")
		{
			$fileDuplicates[$fileDuplicate[%crc], $fileDuplicatesCount[$fileDuplicate[%crc]]] = %file; // not confusing at all!
			$fileDuplicatesCount[$fileDuplicate[%crc]]++;
		}
		else
		{
			$fileDuplicate[%crc] = $fileDuplicateCount;
			$fileDuplicateSource[$fileDuplicateCount] = %file;
			$fileDuplicatesCount[$fileDuplicateCount] = 0;
			$fileDuplicateCount++;
		}

		%file = findNextFile(%pat);
	}

	for(%i = 0; %i < $fileDuplicateCount; %i++)
	{
		if($fileDuplicatesCount[%i] > 0)
		{
			echo("\n" @ $fileDuplicateSource[%i] @ ": " @ $fileDuplicatesCount[%i] @ " duplicate" @ ($fileDuplicatesCount[%i] == 1 ? "" : "s"));

			for(%o = 0; %o < $fileDuplicatesCount[%i]; %o++)
				echo(" - " @ $fileDuplicates[%i, %o]);
		}
	}
}

function cleanupMission()
{
	if(!isObject(MissionGroup))
		return;

	%cts = MissionGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionGroup.getObject(%i);
		%name = %obj.getClassName();
		if((%name $= "SimSet" || %name $= "ScriptObject" || %name $= "ConsoleLogger") && %obj.getName() !$= "MissionInfo")
			%obj.schedule(0, delete);
	}
}

function resaveMission()
{
	EWorldEditor.isDirty = true;
	ETerrainEditor.isDirty = true;

	EditorSaveMission();
}

// resets an object's transform in case you moved it with the inspector
// fixes any potential collision issues from moving stuff around
function applyTransform(%obj)
{
	%obj.setTransform(%obj.position SPC getWords(%obj.rotation, 0, 2) SPC mDegToRad(getWord(%obj.rotation, 3)));
	%obj.setScale(%obj.scale);
}

function applyTransforms()
{
	if(!isObject(MissionGroup))
		return;

	%cts = MissionGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionGroup.getObject(%i);
		%name = %obj.getClassName();
		if(%name $= "TSStatic" || %name $= "InteriorInstance")
			applyTransform(%obj);
	}
}

function roundTransform(%obj)
{
	%pos = %obj.position;
	%obj.position = mFloatLength(getWord(%pos, 0), 0) SPC mFloatLength(getWord(%pos, 1), 0) SPC mFloatLength(getWord(%pos, 2), 0);
	applyTransform(%obj);
}

function roundTransforms(%statics)
{
	if(!isObject(MissionGroup))
		return;

	%cts = MissionGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionGroup.getObject(%i);
		%name = %obj.getClassName();
		if((%statics && %name $= "TSStatic") || %name $= "InteriorInstance")
		{
			if(%obj.locked !$= "true")
				roundTransform(%obj);
		}
	}
}

// used for porting maps from tribes 2 to blockland
// copies all TSStatic and InteriorInstance objects to the clipboard
function copyStatics()
{
	if(!isObject(MissionGroup))
		return;

	$copyLines = "";

	sCopyGroup(MissionGroup);

	setClipboard($copyLines);
}

function sCopyStatic(%obj)
{
	if(!isObject(%obj))
		return;
	
	%line = "0" TAB fileBase(%obj.shapeName) @ fileExt(%obj.shapeName) TAB %obj.position TAB %obj.rotation TAB %obj.scale;

	$copyLines = trim($copyLines NL %line);
}

function sCopyInterior(%obj)
{
	if(!isObject(%obj))
		return;

	%line = "1" TAB fileBase(%obj.interiorFile) @ fileExt(%obj.interiorFile) TAB %obj.position TAB %obj.rotation TAB %obj.scale TAB %obj.showTerrainInside;
	
	$copyLines = trim($copyLines NL %line);
}

function sCopyGroup(%grp)
{
	if(!isObject(%grp))
		return;

	%cts = %grp.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = %grp.getObject(%i);
		%name = %obj.getClassName();
		if(%name $= "SimGroup")
			sCopyGroup(%obj);
		else if(%name $= "TSStatic")
			sCopyStatic(%obj);
		else if(%name $= "InteriorInstance")
			sCopyInterior(%obj);
	}
}

// pastes previously copied statics/interiors
// finds dif/dts files inside %dir as tribes 2 assets don't include the path
// offset of 1 0 shifts the static shapes one whole terrain loop forwards towards Y
function pasteStatics(%dir, %offset)
{
	if(!isObject(Terrain))
		%offset = vectorScale(%offset, 8 * 256);
	else
		%offset = vectorScale(%offset, Terrain.squareSize * 256);

	%lines = getClipboard();
	%cts = getRecordCount(%lines);
	for(%i = 0; %i < %cts; %i++)
	{
		%line = getRecord(%lines, %i);

		if(getField(%line, 0) $= "0") // static
		{
			%file = getField(%line, 1);
			%pos = vectorAdd(getField(%line, 2), %offset);
			%rot = getField(%line, 3);
			%siz = getField(%line, 4);

			%file = sFind(%dir, %file);

			if(!isFile(%file))
			{
				warn("pasteStatics() - file " @ getField(%line, 1) @ " not found");
				continue;
			}
			else
			{
				%obj = new TSStatic()
				{
					shapeName = %file;
					position = %pos;
					rotation = %rot;
					scale = %siz;
				};
			}
		}
		else // interior
		{
			%file = getField(%line, 1);
			%pos = vectorAdd(getField(%line, 2), %offset);
			%rot = getField(%line, 3);
			%siz = getField(%line, 4);
			%ter = getField(%line, 5);

			%file = sFind(%dir, %file);

			if(!isFile(%file))
			{
				warn("pasteStatics() - file " @ getField(%line, 1) @ " not found");
				continue;
			}
			else
			{
				%obj = new InteriorInstance()
				{
					interiorFile = %file;
					position = %pos;
					rotation = %rot;
					scale = %siz;
					showTerrainInside = %ter;
				};
			}
		}
	}
}

function sFind(%dir, %name)
{
	return findFirstFile(%dir @ "/" @ %name);
}

// deletes all tsstatics and interiors
function clearStatics()
{
	if(!isObject(MissionGroup))
		return;

	%cts = MissionGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionGroup.getObject(%i);
		%name = %obj.getClassName();
		if(%name $= "TSStatic" || %name $= "InteriorInstance")
			%obj.schedule(0, delete);
	}
}
function serverCmdLocateFar(%cl, %dist)
{
	if(!isObject(%pl = %cl.Player) || !%cl.isSuperAdmin)
		return;
	
	for(%i = 0; %i < mainBrickGroup.getCount(); %i++)
	{
		%gr = mainBrickGroup.getObject(%i);
		for(%o = 0; %o < %gr.getCount(); %o++)
		{
			%brk = %gr.getObject(%o);

			if((%d = vectorDist(%brk.getPosition(), %pl.getPosition())) >= %dist)
				messageClient(%cl, '', "\c5Located brick " @ %brk.getID() @ " " @ %d @ "tu away");
		}
	}
}

function serverCmdGotoBrick(%cl, %id)
{
	if(!isObject(%pl = %cl.Player) || !%cl.isAdmin)
		return;
	
	if(isObject(%id) && %id.getClassName() $= "fxDtsBrick")
		%pl.setTransform(%id.getPosition());
}

function serverCmdGhostAll(%cl)
{
	if(!%cl.isAdmin)
		return;
	
	echo(%cl.name @ " is ghosting everything to all clients");
	
	for(%x = 0; %x < ClientGroup.getCount(); %x++)
	{
		%cc = ClientGroup.getObject(%x);
		%cc.ForceGhostEverything();
	}
}

function serverCmdGhost(%cc)
{
	if(getSimTime() - %cc.lastGhost < 30000)
		return;

	if(%cc.hasSpawnedOnce)
	{
		%cc.lastGhost = getSimTime();
		
		echo(%cc.name @ " is ghosting everything to themselves");
		
		%cc.ForceGhostEverything();
	}
	else
	{
		messageClient(%cc, "\c5You need to spawn first!");
	}
}

function GameConnection::ForceGhostEverything(%cc)
{
	if(%cc.hasSpawnedOnce)
	{
		for(%o = 0; %o < mainBrickGroup.getCount(); %o++)
		{
			%group = mainBrickGroup.getObject(%o);
			for(%i = 0; %i < %group.getCount(); %i++)
			{
				%group.getObject(%i).scopeToClient(%cc);
			}
		}

		for(%o = 0; %o < MissionCleanup.getCount(); %o++)
		{
			%obj = MissionCleanup.getObject(%o);
			%class = %obj.getClassName();
			if( %class $= "Player"         ||
					%class $= "AIPlayer"       ||
					%class $= "WheeledVehicle" ||
					%class $= "FlyingVehicle"  ||
					%class $= "Projectile"     ||
					%class $= "Item"           ||
					%class $= "StaticShape"    )
			{
				if(%cc.player.hatBot.sourceObject == %cc.player)
					continue;
				
				%obj.scopeToClient(%cc);
			}
		}
	}
}

package EventWatch
{
	function fxDTSBrick::processInputEvent(%brk, %evt, %src)
	{
		%ls = "";
		for(%i = 0; %i < %brk.numEvents; %i++)
		{
			if (%brk.eventInput[%i] $= %evt && %brk.eventEnabled[%i])
			{
				if(%ls $= "")
					%ls = %i;
				else
					%ls = %ls SPC %i;
			}
		}

		if(%ls !$= "")
		{
			%cts = ClientGroup.getCount();

			for(%i = 0; %i < %cts; %i++)
			{
				%cl = ClientGroup.getObject(%i);

				if(%cl.eventWatching && %cl.isAdmin)
				{
					if(%cl.watches $= "" || getSimTime() - %cl.lastWatch > 3000)
						%cl.watches = 0;

					%cl.watch[%cl.watches] = %brk TAB %evt TAB %src TAB %ls;
					%cl.watches++;

					%long = false;

					for(%w = %cl.watches - 1; %w >= 0; %w--)
					{
						%watch = %cl.watch[%w];
						%brick = getField(%watch, 0);
						%event = getField(%watch, 1);
						%source = getField(%watch, 2);
						%lines = getField(%watch, 3);
						%name = %brick.getName();

						%st2 = (isObject(%source) ? %source.name @ " : " : "") @ (%name $= "" ? "<unnamed>" : %name) @ " (" @ %brick.getId() @ ")" @ " > " @ %event @ " @ " @ %lines;
						%sto = %str;
						if(%str $= "")
							%str = "<font:arial bold:16><color:FFFFFF>" @ %st2;
						else
							%str = %str @ "<br><color:FFFFFF>" @ %st2;
						
						if(strlen(%str) > 255)
						{
							%long = true;
							if(strLen(%str) > 1020)
							{
								%str = %sto;
								break;
							}
						}
					}

					if(getSimTime() - %cl.lastWatch > 16)
					{
						if(!%long)
							%cl.centerPrint(%str, 3);
						else
							commandToClient(%cl, 'centerPrint', '<br>%2%3%4%5', 3, getSubStr(%str, 0, 255), getSubStr(%str, 255, 255), getSubStr(%str, 510, 255), getSubStr(%str, 765, 255));
					}

					%cl.lastWatch = getSimTime();
				}
			}
		}

		Parent::processInputEvent(%brk, %evt, %src);
	}
};
activatePackage(EventWatch);

function serverCmdEventWatch(%cl)
{
	if(!%cl.isAdmin)
		return;
	
	if(%cl.eventWatching)
	{
		%cl.eventWatching = false;
		messageClient(%cl, '', "\c5Disabled event watch.");
	}
	else
	{
		%cl.eventWatching = true;
		messageClient(%cl, '', "\c5Enabled event watch.");
	}
}

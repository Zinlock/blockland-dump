datablock StaticShapeData(KillZoneStaticShape)
{
	shapeFile = "./zonex4.dts";
};

datablock StaticShapeData(KillZoneWallStaticShape)
{
	shapeFile = "./zonebounds.dts";
};

datablock AudioProfile(kzLurkSound)
{
	filename = "./zone_lurk.wav";
	description = AudioCloseLooping3d;
	preload = true;
};

datablock AudioProfile(kzEnterSound)
{
	filename = "./zone_enter.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(kzDamageSound)
{
	filename = "./zone_damage.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(kzExitSound)
{
	filename = "./zone_exit.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(kzNextSound)
{
	filename = "./zone_next.wav";
	description = AudioDefault3d;
	preload = true;
};

package mxDismount {
	function Player::removeBody(%pl,%x)
	{
		if(isObject(%pl) && %pl.getDatablock().isMXBot)
			return;
		
		Parent::removeBody(%pl,%x);
	}

	function Armor::onMount(%this, %obj, %mount, %node)
	{
		if(isObject(%obj) && %this.isMXBot)
			return;

		Parent::onMount(%this, %obj, %mount, %node);
	}

	function Armor::onUnMount(%this, %obj, %mount, %node)
	{
		Parent::onUnMount(%this, %obj, %mount, %node);

		if(isObject(%obj) && %this.isMXBot)
		{
			%obj.setTransform("0 0 -8192");// apparently preventing onUnMount from being parented still causes the console to be spammed with 30 errors as you die
			%obj.schedule(0, delete);   // so instead i'm just letting it do its thing before deleting the bot
		}
	}

	function Armor::onRemove(%this, %obj)
	{
		if(%this.isMXBot)
			return;
		
		Parent::onRemove(%this, %obj);
	}
};
activatePackage(mxDismount);

datablock PlayerData(EmptyAI : PlayerStandardArmor)
{
	renderFirstPerson = false;
	emap = false;

	className = Armor;
	shapeFile = "base/data/shapes/empty.dts";

	maxDamage = 1;

	boundingBox = vectorScale("20 20 20", 4);
	crouchBoundingBox = vectorScale("20 20 20", 4);

	drag = 20;

	UIName = "";
	isMXBot = true;
	
	useCustomPainEffects = true;
	painSound = "";
	deathSound = "";
};

function mFloatLerp(%from, %to, %at)
{
    return %to + %at * (%from - %to);
}

function hex2rgba(%hex)
{
	%len = strLen(%hex);

	if(%len > 0)
	{
		%rh = getSubStr(%hex, 0, 2);
		%r = eval("return 0x" @ %rh @ ";");
		%str = %r / 255;
	}

	if(%len > 2)
	{
		%gh = getSubStr(%hex, 2, 2);
		%g = eval("return 0x" @ %gh @ ";");
		%str = %str SPC %g / 255;
	}

	if(%len > 4)
	{
		%bh = getSubStr(%hex, 4, 2);
		%b = eval("return 0x" @ %bh @ ";");
		%str = %str SPC %b / 255;
	}

	if(%len > 6)
	{
		%ah = getSubStr(%hex, 6, 2);
		%a = eval("return 0x" @ %ah @ ";");
		%str = %str SPC %a / 255;
	}

	return %str;
}

forceRequiredAddon("Projectile_Radio_Wave");

registerOutputEvent(fxDtsBrick, KZSpawnBounds, "string 200 200" TAB "int 0 500 2", 0); // [end brick name] [damage]
registerOutputEvent(fxDtsBrick, KZColorHex, "string 6 60", 0); // [RRGGBB hex]
registerOutputEvent(fxDtsBrick, KZSpawn, "int 16 8192 64" TAB "int 0 1800 20" TAB "int 0 1800 120" TAB "int 0 500 2", 0); // [size] [delay] [time] [damage]
registerOutputEvent(fxDtsBrick, KZDespawn, "", 0);
registerOutputEvent(fxDtsBrick, KZAddPhase, "string 100 60" TAB "int 0 1800 20" TAB "int 0 1800 120" TAB "int 0 500 2", 0); // [brick name | size] [delay] [time] [damage]
registerOutputEvent(Player, KZMakeImmune, "bool", 0);
registerOutputEvent(Minigame, KZLinkLast, "", 0); // links the last spawned killzone to the current minigame
registerInputEvent(fxDtsBrick, onKZSpawn, "Self fxDtsBrick" TAB "Minigame Minigame"); // killzone just spawned
registerInputEvent(fxDtsBrick, onKZPhaseEnd, "Self fxDtsBrick" TAB "Minigame Minigame"); // killzone phase ended
registerInputEvent(fxDtsBrick, onKZPhaseStart, "Self fxDtsBrick" TAB "Minigame Minigame"); // killzone phase started
registerInputEvent(fxDtsBrick, onKZPhasesComplete, "Self fxDtsBrick" TAB "Minigame Minigame"); // killzone has no more phases left

$KZ_Color = "1.0 0.05 0.0";
$KZ_Height = 256;
$KZ_ZOffset = 256;
$KZ_Debug = false;

$KZ_BoundsColor = "0.7 0.0 0.0 0.25";
$KZ_BoundsHeight = 128;
$KZ_BoundsZOffset = 64;

function Player::KZMakeImmune(%pl, %val)
{
	%pl.kzImmune = %val;
}

function fxDtsBrick::KZColorHex(%brk, %hex)
{
	if(isObject(%brk.killzone))
	{
		if(trim(%hex) $= "")
			%brk.killzone.customColor = $KZ_Color;
		else
		{
			%rgb = hex2rgba(%hex);

			if(getWordCount(%rgb) < 3)
				%rgb = $KZ_Color;

			%brk.killzone.customColor = %rgb;
		}
	}
}

function fxDtsBrick::KZLoop(%brk)
{
	cancel(%brk.kzl);

	if(!isObject(%brk.killZoneSet) || %brk.killZoneSet.getCount() <= 0)
		return;
	
	%dmg = false;
	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);

		if(!isObject(%pl = %cc.Player) || !isObject(%cc.minigame) || (isObject(%cc.minigame) && isObject(%brk.kzMinigame) && %cc.minigame.getID() != %brk.kzMinigame.getID()))
			continue;
			
		if(!%pl.kzImmune)
		{
			%pos = %pl.getPosition();
			%posX = getWord(%pos, 0);
			%posY = getWord(%pos, 1);

			%area = %brk.kzArea;
			%areaXMin = getWord(%area, 0);
			%areaYMin = getWord(%area, 1);
			%areaXMax = getWord(%area, 3);
			%areaYMax = getWord(%area, 4);

			if(getSimTime() - %brk.lastDamageTime >= 1000)
			{
				if(%posX > %areaXMax || %posY > %areaYMax || %posX < %areaXMin || %posY < %areaYMin)
				{
					%cc.play3D(kzDamageSound, %pl.getPosition());
					%pl.spawnExplosion(radioWaveProjectile, 2);
					%pl.damage(%pl, %pl.getHackPosition(), %brk.killZoneDamage, $DamageType::Suicide);
					%dmg = true;
				}
			}
		}
	}

	if(%dmg)
		%brk.lastDamageTime = getSimTime();

	%brk.kzl = %brk.schedule(100, KZLoop);
}

function fxDtsBrick::KZSpawnBounds(%brk, %end, %dmg)
{
	if(isObject(%brk.killZoneSet))
		%brk.killZoneSet.deleteAll();
	else
		%brk.killZoneSet = new SimSet(killzoneset);
	
	%brk.killZoneDamage = %dmg;

	%grp = %brk.getGroup();

	%name = "_" @ %end;

	if(%grp.NTObjectCount[%name] <= 0)
		return;
	
	%targ = %grp.NTObject[%name, 0];

	%posA = %brk.getPosition();
	%posB = %targ.getPosition();

	%size = vectorSub(%posB, %posA);
	%sizeX = getWord(%size, 0);
	%sizeY = getWord(%size, 1);

	if(%sizeX < 0)
	{
		%xA = getWord(%posA, 0);
		%posA = setWord(%posA, 0, getWord(%posB, 0));
		%posB = setWord(%posB, 0, %xA);
		%size = setWord(%size, 0, getWord(%size, 0) * -1);
		%sizeX *= -1;
	}
	
	if(%sizeY < 0)
	{
		%yA = getWord(%posA, 1);
		%posA = setWord(%posA, 1, getWord(%posB, 1));
		%posB = setWord(%posB, 1, %yA);
		%size = setWord(%size, 1, getWord(%size, 1) * -1);
		%sizeY *= -1;
	}

	%brk.kzArea = %posA SPC %posB;

	%width = 32;
	%wOffset = 0;
	%length = 32;
	%lOffset = 0;

	%wallWidth = 1;

	%sX = 0;
	%done = false;
	while(!%done)
	{
		if(%sX + %width * 2 > %sizeX)
		{
			%diff = %sX + %width * 2 - %sizeX;
			%width -= %diff / 2;
			%done = true;
		}

		%pos = vectorAdd(vectorAdd(%posA, "0 0 " @ $KZ_BoundsZOffset), %width + %sX);

		%kz = new StaticShape(killzone)
		{
			datablock = KillZoneWallStaticShape;
			sourceObject = %brk;
		};

		%kz.setTransform(%pos SPC "0 0 1 0");
		%kz.setScale(%width - %wOffset SPC %wallWidth SPC $KZ_BoundsHeight);
		
		%kz2 = new StaticShape(killzone)
		{
			datablock = KillZoneWallStaticShape;
			sourceObject = %brk;
		};

		%kz2.setTransform(vectorAdd(%pos, "0 " @ %sizeY) SPC "0 0 1 0");
		%kz2.setScale(%width - %wOffset SPC %wallWidth SPC $KZ_BoundsHeight);

		%kz.setNodeColor("ALL", $KZ_BoundsColor);
		%kz2.setNodeColor("ALL", $KZ_BoundsColor);

		%brk.killZoneSet.add(%kz);
		%brk.killZoneSet.add(%kz2);

		%sX += %width * 2;
	}

	%sY = 0;
	%done = false;
	while(!%done)
	{
		if(%sY + %length * 2 > %sizeY)
		{
			%diff = %sY + %length * 2 - %sizeY;
			%length -= %diff / 2;
			%done = true;
		}

		%pos = vectorAdd(vectorAdd(%posA, "0 0 " @ $KZ_BoundsZOffset), "0 " @ %length + %sY);

		%kz = new StaticShape(killzone)
		{
			datablock = KillZoneWallStaticShape;
			sourceObject = %brk;
		};

		%kz.setTransform(%pos SPC "0 0 1 " @ $pi / 2);
		%kz.setScale(%length - %lOffset SPC %wallWidth SPC $KZ_BoundsHeight);
		
		%kz2 = new StaticShape(killzone)
		{
			datablock = KillZoneWallStaticShape;
			sourceObject = %brk;
		};

		%kz2.setTransform(vectorAdd(%pos, %sizeX) SPC "0 0 1 " @ $pi / 2);
		%kz2.setScale(%length - %lOffset SPC %wallWidth SPC $KZ_BoundsHeight);

		%kz.setNodeColor("ALL", $KZ_BoundsColor);
		%kz2.setNodeColor("ALL", $KZ_BoundsColor);

		%brk.killZoneSet.add(%kz);
		%brk.killZoneSet.add(%kz2);

		%sY += %length * 2;
	}

	%brk.KZLoop();
}

function fxDtsBrick::KZSpawn(%brk, %size, %delay, %time, %dmg)
{
	if(isObject(%brk.killZone))
		%brk.killZone.delete();

	%kz = new StaticShape(killzone)
	{
		datablock = KillZoneStaticShape;
		isKillZone = true;
		phase = 0;
		phase[0] = getWords(%brk.getPosition(), 0, 1) SPC 0 SPC %delay SPC %time SPC %dmg;
		phases = 0;
		phaseTime = getSimTime();
		moving = false;
		newPhase = true;
		minigame = -1;
		customColor = $KZ_Color;
	};

	%kz.sourceObject = %brk;

	%size = %size / 4;

	%kz.setTransform(getWords(%brk.getPosition(), 0, 1) SPC $KZ_ZOffset);
	%kz.setScale(%size SPC %size SPC $KZ_Height);

	%kz.sourcePosition = %kz.getPosition();
	%kz.sourceScale = %kz.getScale();

	%kz.schedule(0, killZoneLoop);

	%brk.killZone = %kz;

	$lastKillZone = %kz;

	missionCleanup.add(%kz);
}

function fxDtsBrick::KZDespawn(%brk)
{
	if(isObject(%brk.killZone))
	{
		%brk.killZone.delete();
		%brk.killZone = "";
	}
	
	if(isObject(%brk.killZoneSet))
	{
		%brk.killZoneSet.deleteAll();
		%brk.killZoneSet.delete();
		%brk.killZoneSet = "";
	}
}

function fxDtsBrick::KZAddPhase(%brk, %goto, %time, %stime, %dmg)
{
	if(!isObject(%kz = %brk.killZone))
		return;
	
	%pos = "0 0 0";
	%name = firstWord(%goto);
	%size = getWord(%goto, 1);

	%size = %size / 4;

	%group = %brk.getGroup();
	for(%i = 0; %i < %group.getCount(); %i++)
	{
		%brick = %group.getObject(%i);
		if(getSubStr(%brick.getName(), 1, 50) $= %name)
		{
			%pos = getWords(%brick.getPosition(), 0, 1);
			break;
		}
	}

	if(%pos $= "0 0 0")
		warn("fxDtsBrick::KZAddPhase() - couldn't find brick " @ %name);

	%kz.phase[%kz.phases] = %pos SPC %size SPC %time SPC %stime SPC %dmg;
	if($KZ_Debug)
		talk(%kz.phase[%kz.phases] SPC getWord(%goto, 1) SPC %size);
	%kz.phases++;
	%kz.newPhase = true;
}

function MinigameSO::KZLinkLast(%mg)
{
	if(isObject(%kz = $lastKillZone))
		%kz.minigame = %mg;
}

function StaticShape::killZoneLoop(%kz)
{
	cancel(%kz.kzl);

	if(%kz.sourceObject.killzone != %kz)
	{
		warn("StaticShape::killZoneLoop() - Duplicate kill zones found!");
		%kz.delete();
		return;
	}

	if($KZ_Debug)
	{
		%kz.setShapeName("phase " @ %kz.phase+1 @ " / " @ %kz.phases+1);
		%kz.setShapeNameDistance(4096);
		%kz.setShapeNameColor("1 0.1 0.1");
	}

	%kz.setNodeColor("top", %kz.customColor @ " 0.4");
	%kz.setNodeColor("bot", %kz.customColor @ " 0.4");

	%phase = %kz.phase[%kz.phase];
	%moveNotify = false;

	if(%kz.spawned $= "")
	{
		%kz.spawned = true;
		$InputTarget_Self = %kz.sourceObject;
		$InputTarget_Minigame = %kz.minigame;
		%kz.sourceObject.processInputEvent(onKZSpawn);
	}

	if(%phase !$= "")
	{
		%timeMS = getWord(%phase, 3) * 1000;
		%targetMS = getWord(%phase, 4) * 1000;
		%past = getSimTime() - %kz.phaseTime;
		%time = %past - %timeMS;
		%progress = %time / %targetMS;

		if(%targetMS > 0)
		{
			if(%past > %timeMS)
			{
				if(%progress <= 1)
				{
					if(!%kz.moving)
					{
						%kz.moving = true;
						%moveNotify = true;

						$InputTarget_Self = %kz.sourceObject;
						$InputTarget_Minigame = %kz.minigame;
						%kz.sourceObject.processInputEvent(onKZPhaseStart);
					}

					%kz.setNodeColor("top", %kz.customColor SPC (0.3 * (mSin(mDegToRad(getSimTime() / 5)) + 1) / 2) + 0.2);
					%pos = %kz.sourcePosition;
					%posX = mFloatLerp(getWord(%pos, 0), getWord(%phase, 0), 1 - %progress);
					%posY = mFloatLerp(getWord(%pos, 1), getWord(%phase, 1), 1 - %progress);

					%size = %kz.sourceScale;
					%sizeX = mFloatLerp(getWord(%size, 0), getWord(%phase, 2), 1 - %progress);

					%kz.setTransform(%posX SPC %posY SPC $KZ_ZOffset);
					%kz.setScale(%sizeX SPC %sizeX SPC $KZ_Height);
				}
				else
				{
					if(%kz.moving) %kz.moving = false;

					%kz.setTransform(getWords(%phase, 0, 1) SPC $KZ_ZOffset);
					%kz.setScale(getWord(%phase, 2) SPC getWord(%phase, 2) SPC $KZ_Height);

					%kz.sourcePosition = %kz.getPosition();
					%kz.sourceScale = %kz.getScale();

					if(%kz.phase < %kz.phases - 1)
					{
						%kz.phase++;
						%kz.phaseTime = getSimTime();
						%kz.newPhase = true;
						
						$InputTarget_Self = %kz.sourceObject;
						$InputTarget_Minigame = %kz.minigame;
						%kz.sourceObject.processInputEvent(onKZPhaseEnd);
					}
					else if(!%kz.complete)
					{
						%kz.complete = true;

						$InputTarget_Self = %kz.sourceObject;
						$InputTarget_Minigame = %kz.minigame;
						%kz.sourceObject.processInputEvent(onKZPhasesComplete);
					}
				}
			}
			else %kz.moving = false;
		}
		else
		{
			%kz.complete = true;
			%kz.moving = false;
		}
	}

	%dmg = false;
	%scale = firstWord(%kz.getScale()) * 4;

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);

		if(!isObject(%pl = %cc.Player) || !isObject(%cc.minigame) || (isObject(%cc.minigame) && isObject(%kz.minigame) && %cc.minigame.getID() != %kz.minigame.getID()))
			continue;

		%size = getWord(%kz.phase[%kz.phase], 2);
		%sizeK = getWord(%kz.getScale(), 0);

		if(%kz.newPhase && %targetMS > 0)
		{
			%str = (%size > %sizeK ? "grow" : (%size == %sizeK ? "move" : (%size <= 0.6 ? "collapse" : "shrink")));
			messageClient(%cc, '', "\c3The circle will " @ %str @ " in " @ %timeMS / 1000 @ " seconds (" @ getWord(%kz.phase[%kz.phase], 5) @ " dps)");
			%cc.play2D(kzNextSound);
		}

		if(%moveNotify)
		{
			%str = (%size > %sizeK ? "growing" : (%size == %sizeK ? "moving" : (%size <= 0.6 ? "collapsing" : "shrinking")));
			messageClient(%cc, '', "\c3The circle is now " @ %str @ "! (" @ getWord(%kz.phase[%kz.phase], 5) @ " dps)");
			%cc.play2D(kzNextSound);
		}

		if(!%pl.kzImmune)
		{
			%dist = vectorDist(getWords(%kz.getPosition(), 0, 1), getWords(%pl.getPosition(), 0, 1));

			if(%dist > %scale - kzLurkSound.description.maxDistance)
			{
				if(isObject(%lr = %pl.lurkSource))
				{
					cancel(%lr.cleanup);

					if(%dist > %scale)
						%lr.setTransform(%pl.getPosition());
					else
					{
						%pos = getWords(%kz.getPosition(), 0, 1) SPC getWord(%pl.getPosition(), 2);
						%target = %pl.getPosition();
						%dir = vectorNormalize(vectorSub(%target, %pos));
						%lr.setTransform(vectorAdd(%pos, vectorScale(%dir, %scale)));
					}

					%lr.cleanup = %lr.schedule(250, delete);
				}
				else
				{
					%lr = new AIPlayer(lr)
					{
						datablock = EmptyAI;
						position = vectorAdd(%pl.getPosition(), "0 0 -256");
					};

					%lr.kill();
					%pl.lurkSource = %lr;
					%lr.playAudio(2, kzLurkSound);
					%lr.cleanup = %lr.schedule(500, delete);
				}
			}
			
			if(%dist > %scale && %scale > 0.6)
			{
				if(!%pl.inStorm)
				{
					%pl.inStorm = true;
					%cc.play2D(kzExitSound);
				}
			}
			else if(%scale > 0.6)
			{
				if(%pl.inStorm)
				{
					%pl.inStorm = false;
					%cc.play2D(kzEnterSound);
				}
			}

			if(getSimTime() - %kz.lastDamageTime >= 1000)
			{
				if(%dist > %scale || %scale < 0.6)
				{
					%cc.play3D(kzDamageSound, %pl.getPosition());
					%pl.spawnExplosion(radioWaveProjectile, 2);
					%pl.damage(%pl, %pl.getHackPosition(), getWord(%kz.phase[%kz.phase], 5), $DamageType::Suicide);
					%dmg = true;
				}
			}
		}
	}
	
	if(%dmg)
		%kz.lastDamageTime = getSimTime();

	%kz.newPhase = false;
	%moveNotify = false;

	%kz.kzl = %kz.schedule(50, killZoneLoop);
}

package kzCleanup
{
	function fxDtsBrick::onRemove(%brk)
	{
		%brk.KZDespawn();

		Parent::onRemove(%brk);
	}
};
activatePackage(kzCleanup);
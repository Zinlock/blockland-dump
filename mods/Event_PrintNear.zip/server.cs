registerOutputEvent(fxDtsBrick, "PrintNearby", "string 200 200\tint 1 999 6\tlist Center 0 Bottom 1 Chat 2\tint 1 999 3", 1);
registerOutputEvent(Player, "PrintNearby", "string 200 200\tint 1 999 6\tlist Center 0 Bottom 1 Chat 2\tint 1 999 3", 1);
registerOutputEvent(Bot, "PrintNearby", "string 200 200\tint 1 999 6\tlist Center 0 Bottom 1 Chat 2\tint 1 999 3", 1);

function Player::PrintNearby(%pl, %msg, %dist, %act, %time)
{
	if(isObject(%pl))
		PrintNearby(%pl.getHackPosition(), %msg, %dist, %act, %time);
}

function fxDtsBrick::PrintNearby(%brk, %msg, %dist, %act, %time)
{
	if(isObject(%brk))
		PrintNearby(%brk.getPosition(), %msg, %dist, %act, %time);
}

function PrintNearby(%pos, %msg, %dist, %act, %time)
{
	initContainerRadiusSearch(%pos, %dist, $TypeMasks::PlayerObjectType);
		
	while(isObject(%obj = containerSearchNext()))
	{
		if(isObject(%cc = %obj.Client))
		{
			if(%act == 0)
				%cc.centerPrint(%msg, %time);
			else if(%act == 1)
				%cc.bottomPrint(%msg, %time, 1);
			else if(%act == 2)
				messageClient(%cc, '', %msg, %cc.name);
		}
	}
}
datablock PlayerData(InvisiblePlayerNoJet : PlayerStandardArmor)
{
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
	maxForwardSpeed = 11;
	maxSideSpeed = 9;
	maxBackwardSpeed = 7;
	lifeSteal = 1.0;
	energySteal = 1.0;
	jumpSound = "";
	jumpForce = 900;
	maxDamage = 300;

	leapEnergy = 60;
	leapForce = 15;
	maxEnergy = 100;

	rechargeRate = 7.5 / 31.25;

  uiName = "The Hidden";
  showEnergyBar = true;
};

datablock fxLightData(PlayerNVGLight)
{
	uiName = "Hidden Light";
	LightOn = 1;
	radius = 128;
	Brightness = 3;
	color = "1 0.85 0.13 1";
	FlareOn = 0;
	FlareTP = 1;
	FlareBitmap = "";
	FlareColor = "1 1 1";
	ConstantSizeOn = 1;
	ConstantSize = 1;
	NearSize = 3;
	FarSize = 0.5;
	NearDistance = 10;
	FarDistance = 30;
	FadeTime = 0.1;
	BlendMode = 0;
};

if(isFunction(NetObject, setNetFlag))
	$thnvg = true;
else
	$thnvg = false;

function InvisiblePlayerNoJet::onNewDatablock(%data, %obj)
{
	Parent::onNewDatablock(%data, %obj);

	%obj.updateTransparency();

	if(isObject(%obj.client) && $thnvg && !%obj.thw)
	{
		%obj.thw = true;
		messageClient(%obj.client, '', "\c5You are the Hidden. Only you can see your light, though other players may hear you turn it on.");
		messageClient(%obj.client, '', "\c5Press right click to leap. Dealing damage gives you back some of your health.");
	}
}

function Player::updateTransparency(%pl)
{
	cancel(%pl.transsched);
	if(isObject(%pl) && %pl.getDatablock() == InvisiblePlayerNoJet.getID())
	{
		%pl.canOverwriteSHat = true;
		if(isFunction(GameConnection, unMountAllHats) && isObject(%pl.client))
			%pl.client.unMountAllHats();
		
		%alpha = 0;

		%time = 500;

		if(%pl.getDamagePercent() >= 1.0)
			%time = 5000;

		%delta = getSimTime() - %pl.lastDamageTime;
		if(%delta < %time)
			%alpha = 0.3 * (1 - %delta / %time);

		%pl.startFade(1,0,1);
		%pl.setNodeColor("ALL", "0 0 0 " @ %alpha);
		
		%pl.hideNode("ALL");

		if(%alpha > 0)
		{
			%pl.unHideNode("headSkin");
			%pl.unHideNode("chest");
			%pl.unHideNode("LArm");
			%pl.unHideNode("LHand");
			%pl.unHideNode("RArm");
			%pl.unHideNode("RHand");
			%pl.unHideNode("pants");
			%pl.unHideNode("LShoe");
			%pl.unHideNode("RShoe");
		}

		%pl.setShapeNameDistance(0);

		if(isObject(%light = %pl.light) && !%light.getNetFlag(6))
		{
			%light.clearScopeAlways();
			%light.setNetFlag(6, true);

			%light.scopeToClient(%cl);
		}

		return %pl.transsched = %pl.schedule(250, updateTransparency);
	}

	%pl.unHideNode("ALL");

	%pl.client.applyBodyParts();
	%pl.client.applyBodyColors();
}

deactivatePackage(theHiddenPlayer);

package theHiddenPlayer
{
	function Armor::onTrigger(%this, %player, %slot, %val)
	{
		Parent::onTrigger(%this, %player, %slot, %val);

		if(%slot != 4 || !%val || %player.getDatablock() != InvisiblePlayerNoJet.getId())
			return;
		
		if((%energ = %player.getEnergyLevel()) >= InvisiblePlayerNoJet.leapEnergy)
		{
			%player.setEnergyLevel(%energ - InvisiblePlayerNoJet.leapEnergy);
			%player.AddVelocity(vectorScale(%player.getEyeVector(), InvisiblePlayerNoJet.leapForce));
		}
	}

	function Armor::onAdd(%this, %obj)
	{
		Parent::onAdd(%this,%obj);

		if(%obj.getDatablock() == InvisiblePlayerNoJet.getId())
		{
			%obj.updateTransparency();

			if(isObject(%obj.client) && $thnvg && !%obj.thw)
			{
				%obj.thw = true;
				messageClient(%obj.client, '', "\c5You are the Hidden. Only you can see your light, though other players may hear you turn it on.");
				messageClient(%obj.client, '', "\c5Press right click to leap. Dealing damage gives you back some of your health.");
			}
		}
	}

	function Armor::Damage(%this, %obj, %src, %pos, %dmg, %dmType)
	{
		Parent::Damage(%this, %obj, %src, %pos, %dmg, %dmType);

		%spl = %src.player;

		if(!isObject(%spl) && isObject(%src) && %src.getType() & $TypeMasks::PlayerObjectType)
			%spl = %src;

		if(isObject(%spl) && %spl.getDatablock() == InvisiblePlayerNoJet.getID() && %spl != %obj)
		{
			%spl.addHealth(%dmg * InvisiblePlayerNoJet.lifeSteal);
			%spl.setEnergyLevel(%spl.getEnergyLevel() + %dmg * InvisiblePlayerNoJet.energySteal);
		}

		if(%obj.getDataBlock() == InvisiblePlayerNoJet.getID())
			%obj.lastDamageTime = getSimTime();
	}

	function serverCmdLight(%cl)
	{
		Parent::serverCmdLight(%cl);

		if(isObject(%pl = %cl.Player) && %pl.getDatablock() == InvisiblePlayerNoJet.getID() && isObject(%light = %pl.light) && $thnvg)
		{
			%light.clearScopeAlways();
			%light.setNetFlag(6, true);

			%light.scopeToClient(%cl);
			%light.setDataBlock(PlayerNVGLight);
		}
	}

	function GameConnection::applyBodyColors(%cl)
	{
		if(isObject(%pl = %cl.player) && %pl.getDatablock() == InvisiblePlayerNoJet.getID())
			return;
		else
			Parent::applyBodyColors(%cl);
	}

	function GameConnection::applyBodyParts(%cl)
	{
		if(isObject(%pl = %cl.player) && %pl.getDatablock() == InvisiblePlayerNoJet.getID())
			return;
		else
			Parent::applyBodyParts(%cl);
	}
};

activatePackage(theHiddenPlayer);

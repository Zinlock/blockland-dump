datablock audioProfile(plMuted)
{
	filename = "./plMuted.wav";
	description = audio2D;
	preload = true;
};

datablock audioProfile(plUnmuted)
{
	filename = "./plUnmuted.wav";
	description = audio2D;
	preload = true;
};

package AUMute
{
	function serverCmdMessageSent(%cl, %msg)
	{
		if(%cl.isMuted)
			return messageClient(%cl, '', "You are muted.");

		Parent::serverCmdMessageSent(%cl, %msg);
	}

	function serverCmdTeamMessageSent(%cl, %msg)
	{
		if(%cl.isMuted)
			return messageClient(%cl, '', "You are muted.");

		Parent::serverCmdTeamMessageSent(%cl, %msg);
	}

	function GameConnection::StartLoad(%cl, %c)
	{
		Parent::StartLoad(%cl);

		if((%dt = $muteLog[%cl.getBLID()]) !$= "")
		{
			if(%dt == 1)
			{
				%cl.isMuted = true;
				messageClient(%cl, '', "<color:" @ $AUColorA @ ">You are still muted.");
				messageClient(%cl, '', "<color:" @ $AUColorA @ ">Your mute is not set to expire automatically.");
			}
			else if(%dt > 1)
			{
				%timeLeft = %dt - getSimTime();
				if(%timeLeft > 0)
				{
					%cl.isMuted = true;
					%cl.muteLoop = %cl.schedule(%timeLeft, unMute);
					messageClient(%cl, '', "<color:" @ $AUColorA @ ">You are still muted.");
					%len = (%timeLeft / 1000) / 60;
					if(%len < 2)
						messageClient(%cl, '', "<color:" @ $AUColorA @ ">Your mute will expire in <color:" @ $AUColorC @ ">" @ mCeil(%len * 60) @ "<color:" @ $AUColorA @ "> second" @ (%len * 60 > 1 ? "s" : "") @ ".");
					else
						messageClient(%cl, '', "<color:" @ $AUColorA @ ">Your mute will expire in <color:" @ $AUColorC @ ">" @ mCeil(%len) @ "<color:" @ $AUColorA @ "> minutes.");
				}
				else
				{
					%len = mAbs((%timeLeft / 1000) / 60);
					messageClient(%cl, '', "<color:" @ $AUColorA @ ">You are no longer muted.");
					if(%len < 2)
						messageClient(%cl, '', "<color:" @ $AUColorA @ ">Your last mute expired <color:" @ $AUColorB @ ">" @ mCeil(%len * 60) @ "<color:" @ $AUColorA @ "> second" @ (%len * 60 > 1 ? "s" : "") @ " ago.");
					else
						messageClient(%cl, '', "<color:" @ $AUColorA @ ">Your last mute expired <color:" @ $AUColorB @ ">" @ mCeil(%len) @ "<color:" @ $AUColorA @ "> minute" @ (%len > 1 ? "s" : "") @ " ago.");
				}
			}
		}
	}
};
activatePackage(AUMute);

function GameConnection::unMute(%cl)
{
	%cl.isMuted = false;
	$muteLog[%cl.getBLID()] = 0;
	announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %cl.name @ "<spop>'s mute has expired.");
	serverPlay2D(plUnmuted);
	echo(" - " @ %cl.name @ "'s mute expired");
}

function serverCmdMute(%cl, %tr, %len)
{
	if(trim(%len) $= "" || %len <= 0)
		%len = -1;
	
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You aren't admin.");

	if(%tr $= "")
		return messageClient(%cl, '', "\c5No target input.");

	%targ = findClientByName(%tr);
	if(!isObject(%targ))
		return messageClient(%cl, '', "\c5Player not found.");
	
	if(%len > 16)
		return messageClient(%cl, '', "\c5Schedules can't last over 16 minutes.");

	%mute = !%targ.isMuted;
	%targ.isMuted = %mute;
	if(!%mute)
	{
		cancel(%targ.muteLoop);
		announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name @ "<spop> has been <spush><color:" @ $AUColorB @ ">un-muted <spop>by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
		$muteLog[%targ.getBLID()] = 0;
		echo(" - " @ %cl.name @ " unmuted " @ %targ.name);
	}
	else
	{
		if(%len <= -1)
		{
			announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name @ "<spop> has been <spush><color:" @ $AUColorC @ ">muted <spop>by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
			$muteLog[%targ.getBLID()] = 1;
			echo(" - " @ %cl.name @ " muted " @ %targ.name);
		}
		else
		{
			%timeout = (%len * 60 * 1000);
			%ln = (%timeout / 1000) / 60;
			$muteLog[%targ.getBLID()] = getSimTime() + %timeout;
			echo(" - " @ %cl.name @ " muted " @ %targ.name @ " (" @ %len @ " mins)");
			%targ.muteLoop = %targ.schedule(%timeout, unMute);
			if(%ln < 2)
				announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name @ "<spop> has been <spush><color:" @ $AUColorC @ ">muted <spop>by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop> for <color:" @ $AUColorC @ ">" @ %ln * 60 @ "<color:" @ $AUColorA @ "> second" @ (%ln * 60 > 1 ? "s" : "") @ ".");
			else
				announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name @ "<spop> has been <spush><color:" @ $AUColorC @ ">muted <spop>by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop> for <color:" @ $AUColorC @ ">" @ %ln @ "<color:" @ $AUColorA @ "> minute" @ (%ln > 1 ? "s" : "") @ ".");
		}
	}
	
	serverPlay2D(%mute ? plMuted : plUnmuted);
}

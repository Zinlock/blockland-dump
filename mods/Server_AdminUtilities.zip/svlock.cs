if(isFile($f = "config/server/joinLogs.cs")) exec($f);
if(isFile($f = "config/server/autrust.cs")) exec($f);

datablock audioProfile(svUnlocked)
{
	filename = "./svunlocked.wav";
	description = audio2D;
	preload = true;
};

datablock audioProfile(svLocked)
{
	filename = "./svlocked.wav";
	description = audio2D;
	preload = true;
};

datablock audioProfile(connectionRequest)
{
	filename = "./svconnectionRequest.wav";
	description = audio2D;
	preload = true;
};

function serverCmdBuildBan(%cl, %t)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%targ = findClientByName(trim(%t));
	if(trim(%t) $= "" || !isObject(%targ) || %targ.isAdmin || %targ.isSuperAdmin)
		return messageClient(%cl, '', "\c5Invalid target.");
	
	if(%targ.auBuildBanned)
	{
		%targ.auBuildBanned = false;
		echo(" - " @ %cl.name @ " enabled building for " @ %targ.name);
		messageAll('', "<color:" @ $AUColorB @ "><spush>" @ %targ.name @ "<color:" @ $AUColorA @ "> has been <color:" @ $AUColorB @ ">unblocked <color:" @ $AUColorA @ ">from building by <spop>" @ %cl.name @ "<color:" @ $AUColorA @ ">.");
		serverPlay2D(plUnmuted);
	}
	else
	{
		%targ.auBuildBanned = true;
		echo(" - " @ %cl.name @ " disabled building for " @ %targ.name);
		messageAll('', "<color:" @ $AUColorB @ "><spush>" @ %targ.name @ "<color:" @ $AUColorA @ "> has been <color:" @ $AUColorC @ ">blocked <color:" @ $AUColorA @ ">from building by <spop>" @ %cl.name @ "<color:" @ $AUColorA @ ">.");
		serverPlay2D(plMuted);
	}

	$AuBanned::Build[%targ.getBLID()] = %targ.auBuildBanned;

	export("$AuBanned::*", "config/server/autrust.cs");
}

function serverCmdEventBan(%cl, %t)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%targ = findClientByName(trim(%t));
	if(trim(%t) $= "" || !isObject(%targ) || %targ.isAdmin || %targ.isSuperAdmin)
		return messageClient(%cl, '', "\c5Invalid target.");

	if(%targ.auEventBanned)
	{
		%targ.auEventBanned = false;
		echo(" - " @ %cl.name @ " enabled eventing for " @ %targ.name);
		messageAll('', "<color:" @ $AUColorB @ "><spush>" @ %targ.name @ "<color:" @ $AUColorA @ "> has been <color:" @ $AUColorB @ ">unblocked <color:" @ $AUColorA @ ">from eventing by <spop>" @ %cl.name @ "<color:" @ $AUColorA @ ">.");
		serverPlay2D(plUnmuted);
	}
	else
	{
		%targ.auEventBanned = true;
		echo(" - " @ %cl.name @ " disabled eventing for " @ %targ.name);
		messageAll('', "<color:" @ $AUColorB @ "><spush>" @ %targ.name @ "<color:" @ $AUColorA @ "> has been <color:" @ $AUColorC @ ">blocked <color:" @ $AUColorA @ ">from eventing by <spop>" @ %cl.name @ "<color:" @ $AUColorA @ ">.");
		serverPlay2D(plMuted);
	}

	$AuBanned::Events[%targ.getBLID()] = %targ.auEventBanned;

	export("$AuBanned::*", "config/server/autrust.cs");
}

package SVLP
{
	function GameConnection::StartLoad(%cl, %c)
	{
		if((%dt = $LastSeen_[%cl.getBLID()]) !$= "")
		{
			for(%i = 0; %i < clientGroup.getCount(); %i++)
			{
				%cc = clientGroup.getObject(%i);
				if(%cc.isAdmin)
					messageClient(%cc, '', "<color:" @ $AUColorB @ ">" @ %cl.name SPC "<color:" @ $AUColorA @ ">was last seen on<color:" @ $AUColorB @ ">" SPC getField(%dt, 1));
			}
		}

		if(%cl.getBLID() >= 0)
		{
			$LastSeen_[%cl.getBLID()] = %cl.name TAB getDateTime();
			$LastSeen_JoinLog[$LastSeen_JoinLogCount++] = %cl.name @ "(" @ %cl.getBLID() @ ") on" SPC getDateTime();
		}

		export("$LastSeen*", "config/server/joinLogs.cs");

		if($AuBanned::Events[%cl.getBLID()])
			%cl.auEventBanned = true;

		if($AuBanned::Build[%cl.getBLID()])
			%cl.auBuildBanned = true;

		Parent::StartLoad(%cl);
	}

	function GameConnection::onDrop(%cl, %res)
	{
		if(%cl.getBLID() >= 0)
			$LastSeen_[%cl.getBLID()] = %cl.name TAB getDateTime();

		Parent::onDrop(%cl, %res);
	}

	function GameConnection::spawnPlayer(%cl)
	{
		if($spawnDisabled && !%cl.spawnAllowed)
		{
			if(!%cl.isAdmin)
			{
				%cl.camera.setTransform("0 0 0");
				%cl.camera.setFlyMode();
				%cl.setControlObject(%cl.camera);
				if(!%cl.hasSpawnedOnce)
				{
					%cl.hasSpawnedOnce = true;
					messageAllExcept(%cl, '', '', "\c1%1 spawned.");
				}

				return;
			}
		}

		return Parent::spawnPlayer(%cl);
	}

	function Observer::onTrigger(%db, %obs, %act, %val)
	{
		if(isObject(%cl = %obs.getControllingClient()))
		{
			if(!$spawnDisabled || isObject(%cl.player) || %cl.isAdmin)
				return Parent::onTrigger(%db, %obs, %act, %val);
			else
			{
				if(!%cl.spawnAllowed)
				{
					messageClient(%cl, 'MsgYourDeath', '', '', '', 0);
					%cl.centerPrint();
					if(%val)
					{
						%spec = getAllPlayerObjects();
						if(getFieldCount(%spec) > 0)
						{
							if(%act == 0 || %act == 4)
							{
								%idx = %obs.spectatorIndex;
								%idx += %act==0?1:-1;
								if(%idx >= getFieldCount(%spec))
									%idx = 0;
								else if(%idx < 0)
									%idx = getFieldCount(%spec);

								%obs.setOrbitMode(getField(%spec, %idx), %obs.getTransform(), 0, 8, 8);
								%obs.mode = "Corpse";
								%obs.spectatorIndex = %idx;
							}
							else if(%act == 2)
							{
								if(%obs.mode $= "Corpse")
								{
									%obs.setFlyMode();
									%obs.mode = "Observer";
								}
								else if(%obs.mode $= "Observer")
								{
									%obs.setOrbitMode(getField(%spec, %obs.spectatorIndex), %obs.getTransform(), 0, 8, 8);
									%obs.mode = "Corpse";
								}
							}
						}
						else
						{
							%obs.setFlyMode();
							%obs.mode = "Observer";
						}
					}

					if(%obs.mode $= "Corpse")
					{
						if(isObject(%targ = %obs.getOrbitObject()))
							%cl.bottomPrint("<just:center><font:arial:14><color:" @ $AUColorA @ ">Watching <color:" @ $AUColorB @ ">" @ %targ.client.name @ "<br><color:" @ $AUColorA @ ">Flying  |  <color:" @ $AUColorB @ ">Orbiting", 512, 1);
						else
							%cl.bottomPrint("<just:center><font:arial:14><color:" @ $AUColorA @ ">Watching <color:" @ $AUColorB @ ">nobody<br><color:" @ $AUColorA @ ">Flying  |  <color:" @ $AUColorB @ ">Orbiting", 512, 1);
					}
					else
						%cl.bottomPrint("<just:center><font:arial:14><color:" @ $AUColorA @ ">Watching <color:" @ $AUColorB @ ">nobody<br><color:" @ $AUColorB @ ">Flying<color:" @ $AUColorA @ ">  |  Orbiting", 512, 1);
				}
			}
		}

		Parent::onTrigger(%db, %obs, %act, %val);
	}

	function serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4)
	{
		if(%client.auEventBanned && !%client.isAdmin && !%client.isSuperAdmin)
		{
			if(getSimTime() - %client.lastBanWarn > 100)
			{
				messageClient(%client, '', "\c5You are blocked from adding brick events.");
				%client.lastBanWarn = getSimTime();
			}
			return;
		}

		Parent::serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4);
	}

	function GameConnection::ndSetMode(%client, %newMode)
	{
		if(%client.auBuildBanned && !%client.isAdmin && !%client.isSuperAdmin)
		{
			if(getSimTime() - %client.lastBanWarn > 100)
			{
				messageClient(%client, '', "\c5You are blocked from building.");
				%client.lastBanWarn = getSimTime();
			}

			%client.ndKillMode();

			if(isObject(%client.player))
				%client.player.unMountImage(0);
		}

		Parent::ndSetMode(%client, %newMode);
	}

	function serverCmdPlantBrick(%client)
	{
		if(isObject(%brk = %client.player.tempBrick) && %client.auBuildBanned && !%client.isAdmin && !%client.isSuperAdmin)
		{
			if(getSimTime() - %client.lastBanWarn > 100)
			{
				messageClient(%client, '', "\c5You are blocked from building.");
				%client.lastBanWarn = getSimTime();
			}

			%brk.delete();
			return;
		}

		Parent::serverCmdPlantBrick(%client);
	}
};
activatePackage(SVLP);

function getAllPlayerObjects()
{
	%str = 0;
	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cl = clientGroup.getObject(%i);
		if(isObject(%pl = %cl.Player))
			%str = %str TAB %pl;
	}

	return removeField(%str, 0);
}

function serverCmdToggleSpawn(%cl)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	$spawnDisabled = !$spawnDisabled;
	announce("<color:" @ $AUColorA @ ">Spawning has been<spush><color:" @ $AUColorB @ ">" SPC ($spawnDisabled ? "<color:" @ $AUColorC @ ">disabled" : "enabled") SPC "<spop>by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
	serverPlay2D($spawnDisabled ? svLocked : svUnlocked);
	echo(" - " @ %cl.name @ ($spawnDisabled ? " disabled" : " enabled") @ " spawning");

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);
		if(!%cc.isAdmin)
		{
			if($spawnDisabled)
			{
				messageClient(%cc, '', "<color:" @ $AUColorA @ ">Spawning has been <spush><color:" @ $AUColorC @ ">disabled<spop> for normal clients.");
				if(isObject(%pl = %cc.Player))
				{
					%cc.camera.setTransform(%pl.getEyePoint());
					%cc.camera.setFlyMode();
					%cc.setControlObject(%cc.camera);
					%pl.delete();
				}	
				messageClient(%cc, 'MsgYourDeath', '', '', '', 0);
				%cc.centerPrint();
				%cc.spawnAllowed = false;
			}
			else
				%cc.spawnAllowed = true;
		}
	}
}

function serverCmdDisableSpawn(%cl, %tr)
{
	serverCmdAllowSpawn(%cl, %tr);
}

function serverCmdAllowSpawn(%cl, %tr)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You aren't admin.");
	
	if(trim(%tr) $= "")
		return messageClient(%cl, '', "\c5No target input.");
	
	if(!isObject(%cc = findClientByName(%tr)))
		return messageClient(%cl, '', "\c5Target not found.");

	if(%cc.spawnAllowed $= "")
		%cc.spawnAllowed = true;

	%cc.spawnAllowed = !%cc.spawnAllowed;
	if(!%cc.isAdmin)
	{
		if(!%cc.spawnAllowed)
		{
			echo(" - " @ %cl.name @ " disabled spawning for " @ %cc.name);
			messageClient(%cc, '', "<color:" @ $AUColorA @ ">Spawning has been <spush><color:" @ $AUColorC @ ">disabled<spop> for you.");
			messageClient(%cl, '', "<color:" @ $AUColorA @ ">Spawning has been <spush><color:" @ $AUColorC @ ">disabled<spop> for <spush><color:" @ $AUColorB @ ">" @ %cc.name @ "<spop>.");
			if(isObject(%pl = %cc.Player))
			{
				%cc.camera.setTransform(%pl.getEyePoint());
				%cc.camera.setFlyMode();
				%cc.setControlObject(%cc.camera);
				%pl.delete();
			}
			messageClient(%cc, 'MsgYourDeath', '', '', '', 0);
			%cc.centerPrint();
		}
		else
		{
			echo(" - " @ %cl.name @ " enabled spawning for " @ %cc.name);
			messageClient(%cc, '', "<color:" @ $AUColorA @ ">Spawning has been <spush><color:" @ $AUColorB @ ">enabled<spop> for you.");
			messageClient(%cl, '', "<color:" @ $AUColorA @ ">Spawning has been <spush><color:" @ $AUColorB @ ">enabled<spop> for <spush><color:" @ $AUColorB @ ">" @ %cc.name @ "<spop>.");
		}
	}
	else
		messageClient(%cl, '', "\c5Target is admin.");
}
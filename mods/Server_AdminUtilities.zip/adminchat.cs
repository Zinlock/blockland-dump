function serverCmdAdminChat(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%fullMSG = trim(stripMLControlChars(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m SPC %n SPC %o SPC %p SPC %q SPC %r));
	if(%fullMSG $= "")
		return messageClient(%cl, '', "\c5No message.");

	echo(" - (admin) " @ %cl.name @ " said: " @ %fullMSG);

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);
		if(%cc.isAdmin)
		{
			%cc.play2D(connectionRequest);
			messageClient(%cc, '', "<color:" @ $AUColorB @ ">[AC]" SPC %cl.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
		}
	}
}

function serverCmdAC(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
     serverCmdAdminChat(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r);
}

function serverCmdDirectMessage(%cl, %targ,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	if(!%cl.isAdmin)
        return messageClient(%cl, '', "\c5You are not an admin.");
		
	%trg = findClientByName(%targ);
	if(!isObject(%trg) || trim(%targ) $= "" || %trg.isAdmin)
		return messageClient(%cl, '', "\c5Invalid target.");
	
	%fullMSG = trim(stripMLControlChars(%b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m SPC %n SPC %o SPC %p SPC %q SPC %r));
	if(%fullMSG $= "")
        return messageClient(%cl, '', "\c5No message.");

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);
		if(%cc.isAdmin)
		{
			%cc.play2D(connectionRequest);
			messageClient(%cc, '', "<color:" @ $AUColorB @ "><spush>[DM]" SPC %cl.name @ "<color:" @ $AUColorA @ "> to <spop>" @ %trg.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
		}
	}

	%trg.play2D(connectionRequest);
	messageClient(%trg, '', "<color:" @ $AUColorB @ "><spush>[DM] " @ %cl.name @ " <color:" @ $AUColorA @ ">to <spop>you<color:" @ $AUColorA @ ">:" SPC %fullMSG);
	messageClient(%trg, '', "<font:palatino linotype:16><color:" @ $AUColorA @ ">Use<spush><color:" @ $AUColorB @ "> /re<spop> to reply.");
	echo(" - (direct) " @ %cl.name @ " said to " @ %trg.name @ ": " @ %fullMSG);
	%trg.canRe = true;
}

function serverCmdDM(%cl, %targ,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	serverCmdDirectMessage(%cl, %targ,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r);
}

function serverCmdRe(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	if(%cl.isAdmin)
        return messageClient(%cl, '', "\c5You are an admin.");
	
	if(!%cl.canRe)
        return messageClient(%cl, '', "\c5You have nothing to reply to.");
	
	if(getSimTime() - %cl.lastReply < 3000)
		return messageClient(%cl, '', "\c5Please wait before replying again.");
	
	%fullMSG = trim(stripMLControlChars(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m SPC %n SPC %o SPC %p SPC %q SPC %r));
	if(%fullMSG $= "")
        return messageClient(%cl, '', "\c5No message.");

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);
		if(%cc.isAdmin)
		{
			%cc.play2D(connectionRequest);
			messageClient(%cc, '', "<color:" @ $AUColorB @ ">[RE] " @ %cl.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
		}
	}

	%cl.play2D(connectionRequest);
	messageClient(%cl, '', "<color:4477FF>[RE] " @ %cl.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
	echo(" - (reply) " @ %cl.name @ " said: " @ %fullMSG);

	%cl.lastReply = getSimTime();
}

function serverCmdSupport(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	if(%cl.isAdmin)
        return messageClient(%cl, '', "\c5You are an admin.");
	
	if(getSimTime() - %cl.lastSupport < 3000)
		return messageClient(%cl, '', "\c5Please wait before asking again for support.");
	
	%fullMSG = trim(stripMLControlChars(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m SPC %n SPC %o SPC %p SPC %q SPC %r));
	if(%fullMSG $= "")
        return messageClient(%cl, '', "\c5No message.");

	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cc = clientGroup.getObject(%i);
		if(%cc.isAdmin)
		{
			%cc.play2D(connectionRequest);
			messageClient(%cc, '', "<color:" @ $AUColorB @ ">[SUP] " @ %cl.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
			messageClient(%cc, '', "<font:palatino linotype:16><color:" @ $AUColorA @ ">Use<spush><color:" @ $AUColorB @ "> /dm<spop> to reply.");
		}
	}

	%cl.play2D(connectionRequest);
	messageClient(%cl, '', "<color:" @ $AUColorB @ ">[SUP] " @ %cl.name @ "<color:" @ $AUColorA @ ">:" SPC %fullMSG);
	echo(" - (support) " @ %cl.name @ " said: " @ %fullMSG);

	%cl.lastSupport = getSimTime();
}

function serverCmdReport(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	serverCmdSupport(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r);
}
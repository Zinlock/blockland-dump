// server and minigame timeouts are limited to 16 minutes because schedules can't go over 1000s

if(isFunction("RTB_RegisterPref"))
{
	RTB_registerPref("AFK Time", "Admin Utilities", "$Pref::xAU::afkPlayerTimeout", "int 0 99", "Server_AdminUtilities", 2, false, false, "");
	RTB_registerPref("Kick from minigames in...", "Admin Utilities", "$Pref::xAU::afkMinigameTimeout", "int 0 16", "Server_AdminUtilities", 2, false, false, "");
	RTB_registerPref("Kick from the server in...", "Admin Utilities", "$Pref::xAU::afkServerTimeout", "int 0 16", "Server_AdminUtilities", 0, false, false, "");
	RTB_registerPref("Mute lag notifications", "Admin Utilities", "$Pref::xAU::lagMute", "bool", "Server_AdminUtilities", 0, false, false, "");
}
else
{
	if($Pref::xAU::afkPlayerTimeout $= "") $Pref::xAU::afkPlayerTimeout = 2;    // time to get marked as afk (mins, 0 - inf)
	if($Pref::xAU::afkMinigameTimeout $= "") $Pref::xAU::afkMinigameTimeout = 2; // time to get kicked from a minigame (mins, 0 - 16)
	if($Pref::xAU::afkServerTimeout $= "") $Pref::xAU::afkServerTimeout = 0; // time to get kicked from the server (mins, 0 - 16)
	if($Pref::xAU::lagMute $= "") $Pref::xAU::lagMute = 0;
}

$cc_afkTrackMovement = false;
$cc_afkTrackAim = true;

$cc_join = "4477FF";
$cc_disc = "595959";
$cc_admin = "44FF44";

$cc_lognetdrop = false;
$cc_lognetdrop2 = true;

datablock StaticShapeData(lagIconShape)
{
	shapeFile = "./lag.dts";
};

datablock AudioDescription(cc_quietAudio : AudioDefault3D)
{
	volume = 0.5;
};

datablock AudioProfile(cc_lagSound)
{
	fileName = "./lag.wav";
	preload = true;
	description = cc_quietAudio;
};

datablock AudioProfile(cc_timeoutSound)
{
	fileName = "./timeout.wav";
	preload = true;
	description = cc_quietAudio;
};

datablock AudioProfile(cc_awaySound)
{
	fileName = "./away.ogg";
	preload = true;
	description = cc_quietAudio;
};

datablock AudioProfile(cc_backSound)
{
	fileName = "./back.ogg";
	preload = true;
	description = cc_quietAudio;
};

if(!isObject(CC_InactiveSet)) new SimSet(CC_InactiveSet);

package CustomChatPkg
{
	function GameConnection::startLoad(%cl) //dumb shit
	{
		$hideAdmin[%cl.getPlayerName()] = true;

		Parent::startLoad(%cl);
		
		$hideAdmin[%cl.getPlayerName()] = false;

		if(!isObject(CC_InactiveSet)) new SimSet(CC_InactiveSet);

		%ct = CC_InactiveSet.getCount();
		for(%i = 0; %i < %ct; %i++)
		{
			%cx = CC_InactiveSet.getObject(%i);
			messageClient(%cl, '', "<color:" @ $AUColorA @ "><font:arial:14><spush><color:" @ $AUColorB @ "><font:arial:16>" @ %cx.getPlayerName() @ "<spop> is currently AFK.");
		}
	}

	function GameConnection::onDrop(%cl, %res)
	{
		if(isObject(%cl.afkIcon))
			%cl.afkIcon.delete();

		%cl.netDropR = trim(%res);
		if($cc_lognetdrop)
			talk(%res);
		
		if($cc_lognetdrop2)
			echo(%res);

		Parent::onDrop(%cl, %res);
	}

	function Player::setShapeNameColor(%pl, %col)
	{
		%pl.lastShapeNameColor = %col;
		Parent::setShapeNameColor(%pl, %col);
	}

	function GameConnection::resetLagStatus(%cl)
	{
		%cl.lagging = false;
		if(isObject(%cl.lagIcon))
			%cl.lagIcon.delete();
	}

	function GameConnection::onInfiniteLag(%cl)
	{
		Parent::onInfiniteLag(%cl);

		if(%cl.lagTime $= "")
			%cl.lagTime = getSimTime();

		if(!%cl.lagging)
		{
			%cl.lagging = true;
			if(getSimTime() - %cl.lagTime > 10000)
				%cl.lagTime = getSimTime();
			
			if(getSimTime() - $cc_lasterror > 400)
			{
				serverPlay2D(cc_lagSound);
				$cc_lasterror = getSimTime();
			}

			if(!$Pref::xAU::lagMute)
				messageAll('', '%1%2 is lagging... \c7(%3ms)', "<color:"@$cc_disc@">", %cl.name, %cl.getPing());
		}
		
		if(isObject(%pl = %cl.player))
		{
			if(%pl.lagC !$= "")
				%pl.setShapeNameColor(%pl.lagC);
			%pl.lagC = %pl.lastShapeNameColor;
			%pl.setShapeNameColor("0.5 0.5 0.5 1");
			if(isEventPending(%pl.infLagName))
				cancel(%pl.infLagName);

			%pl.infLagName = %pl.schedule(100, setShapeNameColor, %pl.lagC);

			if(isEventPending(%cl.lagStatusSched))
				cancel(%cl.lagStatusSched);
			
			%cl.lagStatusSched = %cl.schedule(100, resetLagStatus);

			if(!isObject(%cl.afkIcon))
			{
				if(!isObject(%ico = %cl.lagIcon))
				{
					%ico = new StaticShape()
					{
						datablock = lagIconShape;
						position = vectorAdd(%pl.getEyePoint(), "0 0 1.5");
					};
					missionCleanup.add(%ico);
					%ico.setNodeColor("ALL", "1 0 0 1");
					%ico.hideNode("ALL");
					%ico.unHideNode("lagTxt");
					%ico.unHideNode("txtBars");
					%ico.playThread(0, spin);
					%cl.lagIcon = %ico;
				}
				
				%ico.setNodeColor("ALL", "1 0 0 1");
				%ico.setTransform(vectorAdd(%pl.getEyePoint(), "0 0 1.5"));
				if(!isEventPending(%ico.spinLoop))
					%ico.spinLoop = %ico.schedule((100 / 24) * 1000, playThread, 0, spin);
				
				if(isEventPending(%ico.deleteSched))
					cancel(%ico.deleteSched);
				
				%ico.deleteSched = %ico.schedule(100, delete);
			}
		}
		else if(isObject(%cl.lagIcon))
			%cl.lagIcon.delete();
	}

	function messageClient(%client, %tag, %msg, %obj, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13)
	{
		if(%tag $= 'MsgClientInYourMiniGame')
		{
			if(strstr(%msg, "joined") != -1)
				%msg = "<color:"@$cc_join@">" @ %obj.name SPC "joined this minigame.";
			else if(strstr(%msg, "left") != -1)
				%msg = "<color:"@$cc_disc@">" @ %obj.name SPC "left this minigame.";
		}

		Parent::messageClient(%client, %tag, %msg, %obj, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13);
	}

	function messageAllExcept(%client, %team, %msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13)
	{
		if(%msgString $= '\c1%1 connected.' || %msgString $= '\c1%1 has left the game.' || %msgString $= '\c1%1 spawned.')
		{
			%a2 = %client.bl_id;
			%a3 = "<color:"@$cc_join@">";
			%a4 = %client.isSuperAdmin ? "super-" : "";

			switch$(%msgString)
			{
				case '\c1%1 connected.':
					if(%client.isAdmin || %client.isSuperAdmin)
						%msgString = '%3%1 connected <spush>\c1(id %2)<spop> as %4admin.';
					else
						%msgString = '%3%1 connected. \c1(id %2)';
				case '\c2%1 Authentication Failed (%2).':
					%a3 = "<color:"@$cc_disc@">";
					%msgString = '%3Authentication failed for %1... \c7(id %2)';
				case '\c1%1 has left the game.':
					%a3 = "<color:"@$cc_disc@">";
					%msgString = '%3%1 disconnected. \c7(id %2)';
					
					if(strLen(%client.netDropR))
					{
						if(%client.netDropR $= "TimedOut")
						{
							%msgString = '%3%1 timed out. \c7(id %2)';
							serverPlay2D(cc_timeoutSound);
							echo(" - " @ %client.name @ " timed out");
						}
						else if(strstr(strlwr(%client.netDropR), "invalid packet") != -1)
						{
							%msgString = '%3%1 received an invalid packet. \c7(id %2)';
							serverPlay2D(cc_timeoutSound);
							echo(" - " @ %client.name @ " received invalid packets");
						}
					}
				case '\c1%1 spawned.':
					%msgString = '%3%1 spawned.';
			}
		}

		Parent::messageAllExcept(%client, %team, %msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13);
	}

	function messageAll(%msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13, %a14, %a15)
	{
		if($hideAdmin[%a1])
		{
			if(%msgString $= '\c2%1 has become Admin (Auto)')
				return;//%msgString = '\c1%1 is now an admin.';
			else if(%msgString $= '\c2%1 has become Super Admin (Auto)')
				return;//%msgString = '\c1%1 is now a super-admin.';
			else if(%msgString $= '\c2%1 has become Super Admin (Host)')
				return;//%msgString = '\c1%1 is the host.';
		}
		else
		{
			if(%msgString $= '\c2%1 is now Admin (Auto)' || %msgString $= '\c2%1 is now Admin (Manual)')
			{
				%msgString = '%2%1 is now an admin.';
				%a2 = "<color:"@$cc_admin@">";
			}
			else if(%msgString $= '\c2%1 is now Super Admin (Auto)' || %msgString $= '\c2%1 is now Super Admin (Manual)')
			{
				%msgString = '%2%1 is now a super-admin.';
				%a2 = "<color:"@$cc_admin@">";
			}

			if(%msgString $= '\c2%1 is no longer Admin (Auto)' || %msgString $= '\c2%1 is no longer Admin (Manual)')
			{
				%msgString = '%2%1 is no longer an admin.';
				%a2 = "<color:"@$cc_admin@">";
			}
			else if(%msgString $= '\c2%1 is no longer Super Admin (Auto)' || %msgString $= '\c2%1 is no longer Super Admin (Manual)')
			{
				%msgString = '%2%1 is no longer a super-admin.';
				%a2 = "<color:"@$cc_admin@">";
			}
		}

		Parent::messageAll(%msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13, %a14, %a15);
	}

	function serverCmdMessageSent(%client,%msg)
	{
		%client.CC_Active();

		parent::serverCmdMessageSent(%client,%msg);
	}

	function serverCmdTeamMessageSent(%client,%msg)
	{
		%client.CC_Active();

		parent::serverCmdTeamMessageSent(%client,%msg);
	}

	function serverCmdUseTool(%client, %id)
	{
		%client.CC_Active();

		parent::serverCmdUseTool(%client, %id);
	}

	function serverCmdUnUseTool(%client)
	{
		%client.CC_Active();

		parent::serverCmdUnUseTool(%client);
	}

	function serverCmdDropCameraAtPlayer(%client)
	{
		%client.CC_Active();

		Parent::serverCmdDropCameraAtPlayer(%client);
	}

	function serverCmdDropPlayerAtCamera(%client)
	{
		%client.CC_Active();

		Parent::serverCmdDropPlayerAtCamera(%client);
	}

	function serverCmdSpy(%client, %target)
	{
		%client.CC_Active();

		Parent::serverCmdSpy(%client, %target);
	}

	function serverCmdLight(%client)
	{
		%client.CC_Active();

		Parent::serverCmdLight(%client);
	}
	
	function serverCmdGreenLight(%client, %val)
	{
		%client.CC_Active();

		Parent::serverCmdGreenLight(%client, %val);
	}
	
	function serverCmdAlarm(%client)
	{
		%client.CC_Active();

		Parent::serverCmdAlarm(%client);
	}
	
	function serverCmdHate(%client)
	{
		%client.CC_Active();

		Parent::serverCmdHate(%client);
	}
	
	function serverCmdLove(%client)
	{
		%client.CC_Active();

		Parent::serverCmdLove(%client);
	}

	function serverCmdSit(%client)
	{
		%client.CC_Active();

		Parent::serverCmdSit(%client);
	}

	function serverCmdSuicide(%client)
	{
		%client.CC_Active();

		Parent::serverCmdSuicide(%client);
	}
	
	function serverCmdPlantBrick(%client)
	{
		%client.CC_Active();

		Parent::serverCmdPlantBrick(%client);
	}

	function Player::activateStuff(%pl)
	{
		Parent::activateStuff(%pl);

		if(isObject(%client = %pl.Client))
			%client.CC_Active();
	}

	function Armor::onTrigger(%db, %pl, %trig, %val)
	{
		if(isObject(%client = %pl.Client))
			%client.CC_Active();
		
		Parent::onTrigger(%db, %pl, %trig, %val);
	}

	function Observer::onTrigger(%db, %obs, %trig, %val)
	{
		if(isObject(%client = %obs.getControllingClient()))
			%client.CC_Active();

		Parent::onTrigger(%db, %obs, %trig, %val);
	}

	function Armor::onAdd(%db, %pl)
	{
		Parent::onAdd(%db, %pl);

		if(isObject(%pl))
			serverActivityTick();
	}
};
activatePackage(CustomChatPkg);

// function AIPlayer::CC_Active() { }
// function GameConnection::CC_Active() { }
// return;

function serverActivityTick()
{
	cancel($actTick);

	if($Pref::xAU::afkPlayerTimeout > 0)
	{
		%cls = clientGroup.getCount();
		for(%i = 0; %i < %cls; %i++)
		{
			%cl = clientGroup.getObject(%i);
			if(%cl.hasSpawnedOnce)
			{
				if(!%cl.isInactive)
				{ 
					%co = %cl.getControlObject();
					if(isObject(%co))
					{
						if(vectorDist(%co.getEyeVector(), %co.lastActiveAngle) > 0.3 || %co.getMountedImage(0) != %co.lastActiveImage)
							%cl.CC_Active();
					}

					if(getSimTime() - %cl.lastActiveTime >= $Pref::xAU::afkPlayerTimeout * 60 * 1000)
					{
						%cl.CC_InactiveLoop();
					}
				}
			}
			else
				%cl.CC_Active(); // don't flag loading players as afk during or right after loading
			
			if(!isObject(%cl.minigame))
				%cl.score = %cl.getPing(); //setScore spams client consoles with "Stored stats for Steam"
		}
	}

	$actTick = schedule(1000, 0, serverActivityTick);
}

function AIPlayer::CC_Active() { } // bots can call server commands for some reason

function GameConnection::CC_Active(%cl)
{
	if(!isObject(%cl))
		return;
	
	if(getSimTime() - %cl.inactiveTime < 300)
		return;
	
	if(isObject(%cl.afkIcon))
		%cl.afkIcon.delete();
	
	if(!isObject(CC_InactiveSet))	new SimSet(CC_InactiveSet);

	if(CC_InactiveSet.isMember(%cl))
			CC_InactiveSet.remove(%cl);

	%cl.lastActiveTime = getSimTime();

	if(%cl.isInactive && !%cl.afkRemoved)
	{
		messageAll('', "<color:" @ $AUColorA @ "><font:arial:14><spush><color:" @ $AUColorB @ "><font:arial:16>" @ %cl.getPlayerName() @ "<spop> is back.");
		serverPlay2D(cc_backSound);
		echo(" - " @ %cl.name @ " is no longer afk");
		%cl.isInactive = false;
		if(%cl.getControlObject() == %cl.camera && isObject(%cl.Player))
			%cl.setControlObject(%cl.player);
	}
	
	cancel(%cl.kickSchedule);
	cancel(%cl.serverKickSchedule);
	
	if(isObject(%mg = %cl.waitingForMG))
	{
		%mg.addMember(%cl);
		%cl.waitingForMG = "";
	}
	
	cancel(%cl.inactiveLoop);

	%co = %cl.getControlObject();
	if(isObject(%co))
	{
		// %pos = %co.getPosition();
		%rot = %co.getEyeVector();
		%ite = %co.getMountedImage(0);

		// %co.lastActivePosition = %pos;
		%co.lastActiveAngle = %rot;
		%co.lastActiveImage = %ite;

		// %cl.lastControlObject = %co;
	}
}

function serverCmdAfk(%cl)
{
	if(getSimTime() - %cl.lastAfk > 5000)
	{
		%cl.schedule(100, CC_InactiveLoop);
		%cl.lastAfk = getSimTime();
	}
}

function GameConnection::CC_ExitMinigame(%cl)
{
	if(!%cl.hasSpawnedOnce)
		return;
	
	if(isObject(%mg = %cl.minigame))
	{
		%cam = %cl.camera;
		%pos = %cam.getPosition();
		%cl.waitingForMG = %mg;
		%mg.removeMember(%cl);
		if(isObject(%pl = %cl.Player))
			%pl.delete();
		
		%cam.SetMode(observer);
		%cam.setTransform(%pos);
		%cl.setControlObject(%cam);
		
		%cam.lastActiveAngle = %cam.getEyeVector();
		%cam.lastActiveImage = %cam.getMountedImage(0);

		messageAll('', "<color:" @ $AUColorA @ "><font:arial:14><spush><color:" @ $AUColorB @ "><font:arial:16>" @ %cl.getPlayerName() @ "<spop> was kicked from their minigame for being AFK.");
		echo(" - " @ %cl.name @ " was removed from a minigame for being afk");
		serverPlay2D(cc_awaySound);
	}
}

function GameConnection::CC_ExitServer(%cl)
{
	if(!%cl.hasSpawnedOnce || %cl.isAdmin)
		return;
	
	messageAll('', "<color:" @ $AUColorA @ "><font:arial:14><spush><color:" @ $AUColorB @ "><font:arial:16>" @ %cl.getPlayerName() @ "<spop> was kicked from the server for being AFK.");
	echo(" - " @ %cl.name @ " was removed from the server for being afk");
	%cl.afkRemoved = true;
	%cl.delete("You've been AFK for a while...");
	serverPlay2D(cc_awaySound);
}

function GameConnection::CC_InactiveLoop(%cl)
{
	if(!%cl.hasSpawnedOnce)
		return;
	
	if(getSimTime() - %cl.lastActiveTime < 300 && getSimTime() - %cl.lastAfk >= 300)
		return;

	cancel(%cl.inactiveLoop);

	if(!%cl.isInactive)
	{
		%cl.inactiveTime = getSimTime();
		messageAll('', "<color:" @ $AUColorA @ "><font:arial:14><spush><color:" @ $AUColorB @ "><font:arial:16>" @ %cl.getPlayerName() @ "<spop> is AFK.");
		serverPlay2D(cc_awaySound);
		echo(" - " @ %cl.name @ " is afk");
		if(!isObject(CC_InactiveSet))	new SimSet(CC_InactiveSet);

		if(!CC_InactiveSet.isMember(%cl))
			CC_InactiveSet.add(%cl);
	}

	%cl.isInactive = true;
	%pl = %cl.Player;
	if(isObject(%pl))
	{
		if(%pl.afkC !$= "")
			%pl.setShapeNameColor(%pl.afkC);
		%pl.afkC = %pl.lastShapeNameColor;
		%pl.setShapeNameColor("0.5 0.5 0.5 1");
		if(isEventPending(%pl.afkName))
			cancel(%pl.afkName);

		%pl.afkName = %pl.schedule(100, setShapeNameColor, %pl.afkC);

		%cl.camera.SetMode(Corpse, %pl);
		%cl.setControlObject(%cl.camera);
		
		if(isObject(%cl.lagIcon))
			%cl.lagIcon.delete();
		
		if(!isObject(%ico = %cl.afkIcon))
		{
			%ico = new StaticShape()
			{
				datablock = lagIconShape;
				position = vectorAdd(%pl.getEyePoint(), "0 0 1.5");
			};
			missionCleanup.add(%ico);
			%ico.setNodeColor("ALL", "0 1 0 1");
			%ico.hideNode("ALL");
			%ico.unHideNode("afkTxt");
			%ico.unHideNode("txtBars");
			%ico.playThread(0, spin);
			%cl.afkIcon = %ico;
		}

		%ico.setNodeColor("ALL", "0 1 0 1");
		%ico.setTransform(vectorAdd(%pl.getEyePoint(), "0 0 1.5"));
		if(!isEventPending(%ico.spinLoop))
			%ico.spinLoop = %ico.schedule((100 / 24) * 1000, playThread, 0, spin);
	}
	else if(isObject(%cl.afkIcon))
		%cl.afkIcon.delete();
	
	%cl.centerPrint("<font:arial:16><color:" @ $AUColorA @ ">You are currently AFK.<br><color:" @ $AUColorB @ ">Click to play.", 1);
	
	if(isObject(%cl.waitingForMG))
		%cl.centerPrint("<font:arial:16><color:" @ $AUColorA @ ">You are currently AFK and have been moved out of the minigame.<br><color:" @ $AUColorB @ ">Click to play.", 1);
	
	%str = mFloatLength((($Pref::xAU::afkMinigameTimeout * 60 * 1000) - (getSimTime() - %cl.inactiveTime)) / 1000, 0);
	%strk = mFloatLength((($Pref::xAU::afkServerTimeout * 60 * 1000) - (getSimTime() - %cl.inactiveTime)) / 1000, 0);

	if(isObject(%cl.minigame) && %cl.minigame.owner != %cl && %str > 0 && (%strk <= 0 || %str < %strk))
	{
		if(%str < 60)
			%str = %str @ " second" @ (%str == 1 ? "" : "s");
		else
			%str = mFloatLength(%str / 60, 0) @ " minute" @ (mFloatLength(%str / 60, 0) == 1 ? "" : "s");
		
		%cl.centerPrint("<font:arial:16><color:" @ $AUColorA @ ">You are currently AFK. You will be removed from the minigame in <color:" @ $AUColorB @ ">" @ %str @ "<color:" @ $AUColorA @ ">.<color:" @ $AUColorB @ "><br>Click to play.", 1);
	}
	else if(%strk > 0 && !%cl.isAdmin)
	{
		if(%strk < 60)
			%strk = %strk @ " second" @ (%strk == 1 ? "" : "s");
		else
			%strk = mFloatLength(%strk / 60, 0) @ " minute" @ (mFloatLength(%strk / 60, 0) == 1 ? "" : "s");
		
		%cl.centerPrint("<font:arial:16><color:" @ $AUColorA @ ">You are currently AFK. You will be removed from the server in <color:" @ $AUColorB @ ">" @ %strk @ "<color:" @ $AUColorA @ ">.<color:" @ $AUColorB @ "><br>Click to play.", 1);
	}

	if(!isEventPending(%cl.kickSchedule) && $Pref::xAU::afkMinigameTimeout > 0 && %cl.minigame.owner != %cl && ($Pref::xAU::afkServerTimeout <= 0 || $Pref::xAU::afkMinigameTimeout < $Pref::xAU::afkServerTimeout))
		%cl.kickSchedule = %cl.schedule($Pref::xAU::afkMinigameTimeout * 60 * 1000, CC_ExitMinigame);

	if(!isEventPending(%cl.serverKickSchedule) && $Pref::xAU::afkServerTimeout > 0)
		%cl.serverKickSchedule = %cl.schedule($Pref::xAU::afkServerTimeout * 60 * 1000, CC_ExitServer);

	%cl.inactiveLoop = %cl.schedule(100, CC_InactiveLoop);
}

serverActivityTick();
function serverCmdGiveItem(%cl, %t, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%iName = stripMLControlChars(trim(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k));

	%cts = DataBlockGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%db = DataBlockGroup.getObject(%i);
		if(%db.getClassName() $= "ItemData" && stripos(%db.uiName, %iName) != -1)
		{
			%item = %db;
			break;
		}
	}

	if(!isObject(%item))
		return messageClient(%cl, '', "\c5Invalid item.");

	%target = findClientByName(%t);
	if(!isObject(%target.player))
		return messageClient(%cl, '', "\c5No player object found for" SPC %target.name @ ".");

	announce("<color:" @ $AUColorB @ ">" @ %target.name SPC "<spush><color:" @ $AUColorA @ ">has been given a(n)<spop>" SPC %Item.UIName SPC "<spush><color:" @ $AUColorA @ ">by<spop>" SPC %cl.name @ "<color:" @ $AUColorA @ ">.");
	echo(" - " @ %cl.name @ " gave " @ %target.name @ " a(n) " @ %item.uiName);
	%pl = %target.player;
	%pl.z_addItem(%item);
}

function serverCmdGiveTool(%cl, %t, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k)
{
	serverCmdGiveItem(%cl, %t, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k);
}

function serverCmdGive(%cl, %t, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k)
{
	serverCmdGiveItem(%cl, %t, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k);
}

function serverCmdClearProjectiles(%cl)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%count = 0;

	%cts = MissionCleanup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionCleanup.getObject(%i);

		if(%obj.getClassName() $= "Projectile")
		{
			%obj.delete();
			%count++;
			%i--;
			%cts--;
		}
	}

	announce("<color:" @ $AUColorB @ ">" @ %cl.name @ "<spush><color:" @ $AUColorA @ "> cleared <spop>" @ %count @ "<color:" @ $AUColorA @ "> projectiles.");
	echo(" - " @ %cl.name @ " cleared " @ %count @ " projectiles");
}

function serverCmdEClear(%cl)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	eclear();
	announce("<color:" @ $AUColorB @ ">" @ %cl.name @ "<spush><color:" @ $AUColorA @ "> triggered an emergency clear.");
	echo(" - " @ %cl.name @ " triggered an emergency clear");
}

function eclear()
{
	%cts = mainBrickGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%group = mainBrickGroup.getObject(%i);

		%quota = %group.QuotaObject;
		if(isObject(%quota))
		{
			cancelQuotaSchedules(%quota);
			%quota.killObjects($TypeMasks::PlayerObjectType | $TypeMasks::ProjectileObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::CorpseObjectType);
		}
	}

	%cts = MissionCleanup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionCleanup.getObject(%i);

		%class = %obj.getClassName();
		if(%class $= "Projectile" || %class $= "FlyingVehicle" || %class $= "WheeledVehicle" || %class $= "StaticShape" || %class $= "Player" || %class $= "AIPlayer" || (%class $= "Item" && !%obj.isStatic()))
		{
			%obj.delete();
			%count++;
			%i--;
			%cts--;
		}
	}

	%cts = ClientGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%cc = ClientGroup.getObject(%i);

		if(isObject(%cc.player))
			%cc.player.delete();

		%cc.setControlObject(%cc.camera);
	}
}

datablock PlayerData(PlayerNoMovement : PlayerStandardArmor)
{
	maxDamage = 1;

   runForce = 0;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 0;
   maxBackwardSpeed = 0;
   maxSideSpeed = 0;
   maxForwardCrouchSpeed = 0;
   maxBackwardCrouchSpeed = 0;
   maxSideCrouchSpeed = 0;
   airControl = 0;
   jumpForce = 0;

	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "Frozen Player";
	showEnergyBar = false;
};

package AUFreeze
{
     function serverCmdSuicide(%cl)
     {
          if(%cl.isFrozen)
               return messageClient(%cl, '', "You can't suicide while frozen.");

          Parent::serverCmdSuicide(%cl);
     }

     function GameConnection::onDeath(%cl, %sObj, %sCl, %dmgTp, %dmgLoc)
     {
          if(%cl.isFrozen)
          {
               %cl.instantRespawn();
               freezeLoop(%cl.Player);
          }
          else
               Parent::onDeath(%cl, %sObj, %sCl, %dmgTp, %dmgLoc);
     }
};
activatePackage(AUFreeze);

function serverCmdFreeze(%cl, %t)
{
		if(!%cl.isAdmin)
				return messageClient(%cl, '', "\c5You are not admin.");

		%targ = findClientByName(%t);

		if(!isObject(%targ))// || %targ == %cl)
				return messageClient(%cl, '', "\c5Invalid target.");

		if(!isObject(%targ.Player))
				return messageClient(%cl, '', "\c5No player object found for" SPC %targ.name @ ".");

		%targ.isFrozen = !%targ.isFrozen;
		announce("<color:" @ $AUColorB @ ">" @ %targ.name SPC "<color:" @ $AUColorA @ ">has been" SPC (%targ.isFrozen ? "<color:" @ $AUColorC @ ">frozen" : "<color:" @ $AUColorB @ ">un-frozen") SPC "<color:" @ $AUColorA @ ">by<color:" @ $AUColorB @ ">" SPC %cl.name @ "<color:" @ $AUColorA @ ">.");
		echo(" - " @ %cl.name @ " has " @ (%targ.isFrozen ? "" : "un-") @ "frozen " @ %targ.name);
		serverPlay2D(!%targ.isFrozen ? plUnmuted : plMuted);

		%pl = %targ.Player;
		if(%targ.isFrozen)
		{
				%targ.previousDatablock = %pl.getDatablock();
				%targ.previousVelocity = %pl.getVelocity();
				%targ.previousTransform = %pl.getTransform();
				freezeLoop(%pl);
				%pl.setDatablock(PlayerNoMovement.getID());
		}
		else
		{
				cancel(%pl.freezeLoop);
				%pl.setTransform(%targ.previousTransform);
				%pl.setVelocity(%targ.previousVelocity);
				%pl.setDatablock(%targ.previousDatablock);
				%targ.previousDatablock = "";
		}
}

function freezeLoop(%pl)
{
     cancel(%pl.freezeLoop);
     serverCmdUnuseTool(%pl.Client);
     %pl.setVelocity(%pl.Client.previousVelocity);
     %pl.setTransform(%pl.Client.previousTransform);
     if(isObject(%pl))
          %pl.freezeLoop = schedule(35, 0, freezeLoop, %pl);
}
function serverCmdSlap(%cl, %t)
{
		 if(trim(%t) $= "" || !isObject(findClientByName(%t)))
          return messageClient(%cl, '', "\c5Invalid target.");

     if(!%cl.isAdmin)
          return messageClient(%cl, '', "\c5You are not admin.");

     %targ = findClientByName(%t);
     if(!isObject(%targ.Player))
          return messageClient(%cl, '', "\c5No player object found for" SPC %targ.name @ ".");

     announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name SPC "<spop>has been <spush><color:" @ $AUColorC @ ">slapped<spop> by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
		echo(" - " @ %cl.name @ " slapped " @ %targ.name);

     %targ.Player.setVelocity(getRandom(-100, 100) SPC getRandom(-100, 100) SPC getRandom(-100, 100));
     tumble(%targ.Player);
}

function serverCmdRes(%cl, %t)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not admin.");

	%targ = findClientByName(%t);
	if(%t $= "" || !isObject(%targ))
		return messageClient(%cl, '', "\c5Invalid target.");

	if(isObject(%targ.Player))
		return messageClient(%cl, '', "\c5Target is already alive.");

	if(!$AddOn__GameMode_Slayer)
		%targ.spawnPlayer();
	else
	{
		if(isObject(%targ.minigame))
		{
			if(%targ.minigame.lives > 0 && %targ.lives <= 0)
			{
				%targ.setDead(0);
				%targ.lives = 1;
			}
		}
		%targ.spawnPlayer();
	}
	announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name SPC "<spop>has been <spush><color:" @ $AUColorB @ ">revived<spop><spush> by<color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
	echo(" - " @ %cl.name @ " respawned " @ %targ.name);
}

function serverCmdResurrect(%cl, %t)
{
	serverCmdRes(%cl, %t);
}

function serverCmdRevive(%cl, %t)
{
	serverCmdRes(%cl, %t);
}

function serverCmdKill(%cl, %t)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not admin.");

	if(trim(%t) $= "" || !isObject(findClientByName(%t)))
		return messageClient(%cl, '', "\c5Invalid target.");

	%targ = findClientByName(%t);
	if(!isObject(%targ.player))
		return messageClient(%cl, '', "\c5Target is already dead.");

	announce("<color:" @ $AUColorB @ "><spush>" @ %targ.name SPC "<color:" @ $AUColorA @ ">has been <color:" @ $AUColorC @ ">killed<color:" @ $AUColorA @ "> by<spop>" SPC %cl.name @ "<color:" @ $AUColorA @ ">." );
	echo(" - " @ %cl.name @ " killed " @ %targ.name);
	%targ.Player.Kill();
}

function serverCmdHeal(%cl, %t)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not admin.");

	if(trim(%t) $= "" || !isObject(findClientByName(%t)))
		return messageClient(%cl, '', "\c5Invalid target.");

	%targ = findClientByName(%t);
	if(!isObject(%targ.player))
		return messageClient(%cl, '', "\c5Target is already dead.");
	
  announce("<color:" @ $AUColorA @ "><spush><color:" @ $AUColorB @ ">" @ %targ.name SPC "<spop>has been <spush><color:" @ $AUColorB @ ">healed<spop> by<spush><color:" @ $AUColorB @ ">" SPC %cl.name @ "<spop>.");
	echo(" - " @ %cl.name @ " healed " @ %targ.name);
	%targ.player.setDamageLevel(0);
}

function serverCmdAnnounce(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	%fullMSG = trim(stripMLControlChars(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k SPC %l SPC %m SPC %n SPC %o SPC %p SPC %q SPC %r));
	if(%fullMSG $= "")
		return messageClient(%cl, '', "\c5No message.");

	announce("<color:" @ $AUColorB @ ">[ALL] " @ %cl.name @ "<color:" @ $AUColorA @ ">: " @ %fullMSG);
	echo(" - " @ %cl.name @ " announced: " @ %fullMSG);
	serverPlay2D(connectionRequest);
}

function serverCmdAnn(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	serverCmdAnnounce(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r);
}

function serverCmdAll(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r)
{
	serverCmdAnnounce(%cl, %a,%b,%c,%d,%e,%f,%g,%h,%i,%j,%k,%l,%m,%n,%o,%p,%q,%r);
}

function serverCmdAUHelp(%cl)
{
	if(!%cl.isAdmin)
		return messageClient(%cl, '', "\c5You are not an admin.");

	messageClient(%cl, '', "\c6Server_AdminUtilities by \c2Oxy (260031)\c6: all admin commands");
	messageClient(%cl, '', "\c3/ac /adminchat \c2[message]\c6 - admin only chat");
	messageClient(%cl, '', "\c3/dm \c2[player] [message]\c6 - send a non-admin a private message. all admins can see this");
	messageClient(%cl, '', "\c3/mute \c2[player] <length>\c6 - mutes a player. length can be up to 16 minutes, permanent otherwise. rejoining can not bypass this");
	messageClient(%cl, '', "\c3/kill \c2[player]\c6 - force kills a player.");
	messageClient(%cl, '', "\c3/res /resurrect /revive \c2[player]\c6 - respawns a player.");
	messageClient(%cl, '', "\c3/heal \c2[player]\c6 - gets a player back to full health.");
	messageClient(%cl, '', "\c3/give /giveitem /givetool \c2[player] [item]\c6 - gives a player a specific item. name does not have to be exact");
	messageClient(%cl, '', "\c3/all /ann /announce \c2[message]\c6 - sends a message in chat. meant for modes where dead chat is disabled");
	messageClient(%cl, '', "\c3/slap \c2[player]\c6 - fly");
	messageClient(%cl, '', "\c3/freeze \c2[player]\c6 - freezes a player in place, preventing them from using weapons, moving or dying.");
	messageClient(%cl, '', "\c3/buildban \c2[player]\c6 - prevents a player from building. rejoining can not bypass this");
	messageClient(%cl, '', "\c3/eventban \c2[player]\c6 - prevents a player from adding brick events. rejoining can not bypass this");
	messageClient(%cl, '', "\c3/clearprojectiles\c6 - clears all existing projectiles.");
	messageClient(%cl, '', "\c3/eclear\c6 - emergency clear, cancels all events and clears all players, bots, vehicles, projectiles and static shapes.");
	messageClient(%cl, '', "\c3/togglespawn\c6 - prevents non admins from spawning.");
	messageClient(%cl, '', "\c3/allowspawn\c6 - allows a non admin player to spawn even while spawning is off.");
}
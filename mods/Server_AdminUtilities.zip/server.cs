$AUColorA = "888888"; // dark gray by default (888888)
$AUColorB = "44FF44"; // green by default (44FF44)
$AUColorC = "FF4444"; // red by default (FF4444)

exec("./support.cs");
exec("./svlock.cs");
exec("./mute.cs");
exec("./adminchat.cs");
exec("./misccmd.cs");
exec("./miscstuff.cs");
function Player::z_addItem(%pl, %item, %slot)
{
	if(%slot $= "")
	{
		for(%i = 0; %i < %pl.getDatablock().maxTools; %i++)
		{
			%tool = %pl.tool[%i];
			if(%tool == 0)
			{
				%pl.tool[%i] = %item;
				%pl.weaponCount++;
				messageClient(%pl.Client, 'MsgItemPickup', '', %i, %item);
				break;
			}
		}
	}
	else
	{
		if(%slot >= %pl.getDatablock().maxTools)
		{
			%slot = %pl.getDatablock().maxTools - 1;

			%tool = %pl.tool[%slot];
			if(%tool == 0)
			{
				%pl.weaponCount++;
				%pl.tool[%slot] = %item;
				messageClient(%pl.Client, 'MsgItemPickup', '', %slot, %item);
			}
		}
	}
}
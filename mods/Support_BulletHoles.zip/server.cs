exec("./Support_decals.cs");
exec("./BulletDecals.cs");
registerCusBHPrefs();

if(isFile("./BHPrefs.cs"))
     exec("./BHPrefs.cs");

function reloadDecals()
{
     exec("./Support_decals.cs");
     exec("./BulletDecals.cs");
}

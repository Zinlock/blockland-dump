$bhtrans = 0.9;

package CusBulletHoles
{
	function Projectile::onAdd(%obj)
	{
		Parent::onAdd(%obj);

		%obj.spawnTime = getSimTime();
	}

	function ProjectileData::onCollision(%this, %obj, %col, %fade, %pos, %normal, %velocity)
	{
		if(getSimTime() - %obj.spawnTime >= %this.armingDelay * 32)
		{
			if(!%this.BulletHolesDisabled && $Pref::BHole::Restrictions != 2)
			{
				if($Pref::BHole::Restrictions == 0 && (%this.particleEmitter !$= "" || %this.BulletHolesEnabled))
					$dec = spawnZBulletDecal(%this, %pos, %normal, %col);
				else if($Pref::BHole::Restrictions == 1 && %this.hasBulletHoles)
					$dec = spawnZBulletDecal(%this, %pos, %normal, %col);
			}
		}

		parent::onCollision(%this, %obj, %col, %fade, %pos, %normal, %velocity);
	}
};
activatePackage(CusBulletHoles);

function spawnZBulletDecal(%this, %pos, %normal, %col)
{
	%size = getRandom($Pref::BHole::MinSize, $Pref::BHole::MaxSize) / 20; //default size
	%mdl = CusBulletHoleSS; //default model
	%rgb = ($Pref::BHole::R/255) SPC ($Pref::BHole::G/255) SPC ($Pref::BHole::B/255); //default color

	if(%this.BulletHoleSS !$= "") //projectile has custom decal, use that instead
		%mdl = %this.BulletHoleSS;

	if(%this.BulletHoleMinSize !$= "" && %this.BulletHoleMaxSize !$= "") //projectile has custom size, use that instead
		%size = getRandom(%this.BulletHoleMinSize, %this.BulletHoleMaxSize) / 20;

	if(%this.BulletHoleColorShift !$="")
		%rgb = %this.BulletHoleColorShift;

	if(($Pref::BHole::ColorShiftToBrick && %col.colorID !$= "") || %this.ColorShiftToBrick) //either the preferences or projectile settings say use brick color, do that
	{
		%rgb = getWordRange(getColorIDTable(%col.colorID), 0, 3); //get the colors, no alpha
	}
	if( !(%col.getType() & $typeMasks::playerObjectType) && !(%col.getType() & $TypeMasks::vehicleObjectType) )
	{
		%decal = spawnDecal(%mdl, vectorAdd(%pos, vectorScale(%normal, 0.02)), %normal, %size); //spawn decal
		%decal.rgb = %rgb; //set the decal's color in here so that the fade out animation doesnt fuck up colors
		%decal.setNodeColor("ALL", %rgb SPC $bhtrans); //set color
		playSSFadeAnimation(%decal, $Pref::BHole::Lifetime * 1000, $Pref::BHole::FadeDelay, $Pref::BHole::OpacityR); //play the fade out animation when lifetime is over
		return %decal; //return the decal so that its possible to edit the decal later
	}
}

if($Pref::BHole::Lifetime $= "") //if some prefs didnt load, reset them to their default value
	$Pref::BHole::Lifetime = "2";
if($Pref::BHole::FadeDelay $= "")
	$Pref::BHole::FadeDelay = "250";
if($Pref::BHole::OpacityR $= "")
	$Pref::BHole::OpacityR = "0.1";
if($Pref::BHole::MinSize $= "")
	$Pref::BHole::MinSize = "15";
if($Pref::BHole::MaxSize $= "")
	$Pref::BHole::MaxSize = "20";
if($Pref::BHole::Restrictions $= "")
	$Pref::BHole::Restrictions = 0;
if($Pref::BHole::ColorShiftToBrick $= "")
 $Pref::BHole::ColorShiftToBrick = false;

function registerCusBHPrefs() //register rtb/blg prefs. only called via server.cs so that you can exec this script at any time without the prefs duplicating in the list
{
	//despawn settings
	RTB_registerPref("Lifetime [S]", "Bullet Decals | Despawn", "$Pref::BHole::Lifetime", "int 0.025 240", "Support_BulletHoles", 2, 0, 0);
	RTB_registerPref("Fading Tick Time [MS]", "Bullet Decals | Despawn", "$Pref::BHole::FadeDelay", "int 1 450", "Support_BulletHoles", 250, 0, 0);
	RTB_registerPref("Opacity Reduction", "Bullet Decals | Despawn", "$Pref::BHole::OpacityR", "int 0.025 1", "Support_BulletHoles", 0.1, 0, 0);
	//size settings
	RTB_registerPref("Min Size", "Bullet Decals | Size", "$Pref::BHole::MinSize", "int 1 250", "Support_BulletHoles", 15, 0, 0);
	RTB_registerPref("Max Size", "Bullet Decals | Size", "$Pref::BHole::MaxSize", "int 1 250", "Support_BulletHoles", 20, 0, 0);
	//other settings
	RTB_registerPref("Appears on...", "Bullet Decals | Other", "$Pref::BHole::Restrictions", "list All 0 Custom 1 Off 2", "Support_BulletHoles", 0, 0, 0);
	//colors
	RTB_registerPref("Colorshift R", "Bullet Decals | Colors", "$Pref::BHole::R", "int 0 255", "Support_BulletHoles", 116, 0, 0);
	RTB_registerPref("Colorshift G", "Bullet Decals | Colors", "$Pref::BHole::G", "int 0 255", "Support_BulletHoles", 116, 0, 0);
	RTB_registerPref("Colorshift B", "Bullet Decals | Colors", "$Pref::BHole::B", "int 0 255", "Support_BulletHoles", 116, 0, 0);
	RTB_registerPref("Colorshift to Brick Color", "Bullet Decals | Colors", "$Pref::BHole::ColorShiftToBrick", "bool", "Support_BulletHoles", false, 0, 0);
}

datablock staticShapeData(CusBulletHoleSS)
{
	shapeFile = "./bulletHole.dts";
};
datablock staticShapeData(PaintDecalBlue)
{
	shapeFile = "./paint_blue.dts";
};
datablock staticShapeData(PaintDecalRed)
{
	shapeFile = "./paint_red.dts";
};
function playSSFadeAnimation(%ssd, %delay, %fadeTime, %rOpacity)
{
	//talk("playSSFadeAnimation called on" SPC %ssd);
	%ssd.opacity = 1;
	%ssd.setNodeColor("ALL", %ssd.rgb SPC $bhtrans);

	%ssd.schedule(%delay, SSFadeLoop, %fadeTime, %rOpacity);
}

function StaticShape::SSFadeLoop(%ssd, %delay, %rOpacity)
{
	cancel(%ssd.objectFadeLoop); //stop existing loop

	%ssd.opacity = %ssd.opacity - %rOpacity;
	%ssd.setNodeColor("ALL", %ssd.rgb SPC %ssd.opacity); //each time this is called, make the decal slightly more transparent
	if(%ssd.opacity <= 0)
	{
		cancel(%ssd.objectFadeLoop);
		%ssd.delete(); //decal is now invisible, delete it
	}

	if(isObject(%ssd))
		%ssd.objectFadeLoop = %ssd.schedule(%delay, SSFadeLoop, %delay, %rOpacity); //reset loop
}

function loadStaticShapeData(%ssData, %position) //for tests
{
	%SSData = new StaticShape()
	{
		datablock = %ssData;
		position = %position;
	};
	$lastSSData = %SSData;
}

function getWordRange(%str, %indStart, %indEnd)
{
	for(%i = %indStart; %i < %indEnd; %i++)
	{
		%m = %m SPC getWord(%str, %i);
	}
	return stripTrailingSpaces(%m);
}

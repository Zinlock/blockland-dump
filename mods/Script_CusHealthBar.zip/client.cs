// nothing to customize here

// i realize since v2.0 this really just functions as a second bottomprint but...
// having the server just send the client the health string is easier

$zuic_ver = 2.2;

if(isObject(HealthBarText)) HealthBarText.delete();
if(isObject(EnergyBarText)) EnergyBarText.delete();
if(isObject(BossBarText)) BossBarText.delete();

exec("./HealthBarGui.gui");

$zuis_YOffset = 15;
$zuis_EnergyYOffset = 10;
$zuis_BossYOffset = 70;

$zuis_XOffset = 0;
$zuis_EnergyXOffset = 0;
$zuis_BossXOffset = 0;

if(isFile("config/client/zui.cs"))
	exec("config/client/zui.cs");

function clientCmdUpdateHealthUI(%str)
{
	HealthBarText.position = "0" SPC $zuis_YOffset;
	HealthBarText.zCenterX($zuis_XOffset);
	
	HealthBarText.setValue(%str);
}

function clientCmdUpdateEnergyUI(%str)
{
	EnergyBarText.position = "0" SPC $zuis_YOffset - $zuis_EnergyYOffset;
	EnergyBarText.zCenterX($zuis_EnergyXOffset);
	
	if(%str !$= "")
		HUD_EnergyBar.setVisible(0); // hide default energy bar

	EnergyBarText.setValue(%str);
}

function clientCmdUpdateBossHealthUI(%str)
{
	BossBarText.position = "0" SPC $zuis_BossYOffset;
	BossBarText.zCenterX($zuis_BossXOffset);
	BossBarText.setValue(%str);
}

function clientCmdResetHealthUI()
{
	HealthBarText.setValue("");
	EnergyBarText.setValue("");
	BossBarText.setValue("");
}

function clientCmdOpenHealthUI()
{
	PlayGui.add(HealthBarGui);
	BossBarText.setValue("");
	EnergyBarText.setValue("");
	HealthBarText.setValue("<just:center><font:arial:14>Waiting for server...");
	HealthBarText.schedule(3000, setValue, "");
	HealthBarText.position = "0 10";
	HealthBarText.zCenterX();
	commandToServer('ConfirmHealthMod', $zuic_ver);
}

package HealthUI
{
	function disconnectedCleanup(%bool)
	{
		clientCmdResetHealthUI();
		export("$zuis_*", "config/client/zui.cs");

		parent::disconnectedCleanup(%bool);
	}

	function onExit()
	{
		export("$zuis_*", "config/client/zui.cs");
		parent::onExit();
	}

	function clientCmdMissionStartPhase3(%x)
	{
		Parent::clientCmdMissionStartPhase3(%x);

		clientCmdOpenHealthUI();
	}
};
activatePackage(HealthUI);

// turns out GuiCtrl.setCenteredX(); is a slayer function

function GuiControl::zCenterX(%this, %offset)
{
	%parExtX = getWord(Canvas.getExtent(), 0);
	%extX = getWord(%this.getExtent(), 0);
	%posX = (%parExtX / 2) - (%extX / 2);

	%this.position = (%posX + %offset) SPC getWord(%this.getPosition(), 1);
}
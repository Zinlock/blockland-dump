function updateZUIPrefs()
{
	if(isFile("config/server/zui.cs"))
		exec("config/server/zui.cs");
	else
	{
		exec("./prefs.cs");
		export("$zuisv_*", "config/server/zui.cs");
	}
}

updateZUIPrefs();

$zui_ver = 2.2;
$zui_globalTarget = "";

package zHealthBar{
	function Armor::Damage(%db, %pl, %sObj, %pos, %dmg, %dt) {
		if(isObject(%pl))
		{
			if(%pl.zuiTargeted)
			{
				for(%i = 0; %i < ClientGroup.getCount(); %i++)
				{
					%cl = ClientGroup.getObject(%i);
					schedule(50, %cl, HealthUILoop, %cl);
				}
			}

			if(isObject(%pl.Client))
				schedule(50, %pl, HealthUILoop, %pl.Client);
		}

		Parent::Damage(%db, %pl, %sObj, %pos, %dmg, %dt);
	}

	function Armor::onAdd(%db, %pl)
	{
		Parent::onAdd(%db, %pl);

		if(isObject(%pl) && isObject(%pl.Client))
		{
			schedule(50, %pl, HealthUILoop, %pl.Client);
		}
	}

	function GameConnection::spawnPlayer(%cl, %x, %y)
	{
		if(!%cl.hasSpawnedOnce)
		{
			%cl.zui = true;
			commandToClient(%cl, 'OpenHealthUI');
		}
		
		Parent::spawnPlayer(%cl, %x, %y);
		schedule(1000, %cl, HealthUILoop, %cl);
	}

	function destroyServer()
	{
		export("$zuisv_*", "config/server/zui.cs");

		parent::destroyServer();
	}

	function onExit()
	{
		export("$zuisv_*", "config/server/zui.cs");

		parent::onExit();
	}
};
activatePackage(zHealthBar);

function serverCmdNoHealthClient(%cl)
{
	if(%cl.zuiMod)
	{
		%cl.zuiMod = false;
		commandToClient(%cl, 'ResetHealthUI');
		%cl.chatMessage("<color:FF7744>Disabled health client");
	}
	else
	{
		commandToClient(%cl, 'OpenHealthUI');
		if(%cl.haszui)
			%cl.chatMessage("<color:44FF44>Enabled health client");
	}
}

function serverCmdNoHealthMod(%cl)
{
	if(%cl.zui)
	{
		%cl.zui = false;
		%cl.zuiMod = false;
		commandToClient(%cl, 'ResetHealthUI');
		%cl.chatMessage("<color:FF7744>Disabled health UI");
	}
	else
	{
		%cl.zui = true;
		commandToClient(%cl, 'OpenHealthUI');
		%cl.chatMessage("<color:44FF44>Enabled health UI");
	}
}

function serverCmdConfirmHealthMod(%cl, %ver)
{
	if(%cl.zuiMod)
		return;
	
	if(%ver !$= "" && %ver > 1.0)
	{
		%cl.zuiMod = true;
		%cl.haszui = true;
		if(%ver >= $zui_ver)
		{
			%cl.chatMessage("<color:44FF44>Your Script_CusHealthBar version is up to date");
		}
		else
		{
			%cl.chatMessage("<color:FF7744>Your (or the host's) Script_CusHealthBar version is outdated");
			%cl.chatMessage("<color:FF7744>The client may not work properly-- use <spush><color:FFFFFF>/NoHealthClient<spop> to disable it if any issues arise");
		}
	}

	export("$zuisv_*", "config/server/zui.cs");
}

function HealthUILoop(%cl) {	
	if(isObject(%cl.Client))
		return;
	
	if(isEventPending(%cl.uiHLoop))
		cancel(%cl.uiHLoop);

	zUpdateUI(%cl);
	zUpdateBUI(%cl);

	%cl.uiHLoop = schedule(250, %cl, HealthUILoop, %cl);
}

function zUpdateUI(%cl)
{
	if(!%cl.zui)
		return;
	
	%pl = %cl.Player;

	if(!isObject(%pl) || %pl.getDamagePercent() >= 1.0)
		%pl = %cl.camera.getOrbitObject();

	%I = $zuisv_HBColorF;
	%M = $zuisv_HBColorE;
	%U = $zuisv_HBColorM;
	%len = getWord($zuisv_HBSymbol, 3);

	%s = getWord($zuisv_HBSymbol, 0);
	%s = strReplace(%s, "[x]", "");
	%b = getWord($zuisv_HBSymbol, 1);
	%e = getWord($zuisv_HBSymbol, 2);
	%e = strReplace(%e, "[x]", "");

	%F = getWord($zuisv_HBColor, 0);
	%O = getWord($zuisv_HBColor, 1);
	%Z = getWord($zuisv_HBColor, 2);

	%SP = $zuisv_HBSpace;
	%NR = $zuisv_HBNumber;
	%NS = $zuisv_HBNumberS;
	%NP = $zuisv_HBNumberP;
	%FN = $zuisv_HBFont;
	%NF = $zuisv_HBFontN;
	%HT = $zuisv_HBTitle;

	%h = 0.0;

	if(isObject(%pl))
	{
		%db = %pl.getDatablock();
		%h = (%db.maxDamage - %pl.getDamageLevel()) / %db.maxDamage;
	}

	if(isPackage(CustomHealth) && $NewHealth::Enabled)
	{
		if(strLen(%pl.health))
			%h = %pl.health / %pl.getMaxHealth();
	}

	if(%pl.tf2Overheal > 0)
	{
		%h = %h + %pl.tf2Overheal;
	}

	%h = mFloatLength(%h, 2);

	%X = rgb2hex(coLerp(%M, %I, ((%h - 0.5) * ((%U * 2)+1)) + 0.5));

	if((isObject(PlayerTF2UberImage) && %pl.getMountedImage(3) == PlayerTF2UberImage.getID()) || %pl.usingUber)
	{
		%h = 1;
		%X = rgb2hex(coLerp(%M, %I, (mSin($Sim::Time * 3.5) + 1) / 2));
	}

	if(isPackage(swol_downed))
	{
		if(%pl.isDowned)
		{
			%h = mFloatLength(%pl.downed_psuedoHealth / 100, 2); // nice typo, swollow! :egg:
			%X = rgb2hex(%M);
		}
	}

	%t = "<just:center>" @ %FN @ "<color:" @ %F @ ">" @ %s @ "<color:" @ %X @ ">";
	for(%i = 0; %i < %len; %i++)
	{
		if(%i == mCeil(%h * %len))
		{
			%t = %t @ "<color:" @ %O @ ">";
		}

		if(%SP)
			%t = %t SPC %b;
		else
			%t = %t @ %b;
	}
	if(%SP)
		%t = %t SPC "<color:" @ %F @ ">" @ %e;
	else
		%t = %t @ "<color:" @ %F @ ">" @ %e;
	
	if(%NR)
	{
		if(%NP)
			%hs = %h * 100 @ "%";
		else
			%hs = mFloatLength(%db.maxDamage - %pl.getDamageLevel(), 0) @ "/" @ %db.maxDamage;
		
		%t = %t @ (%NS ? " " : "<br>") @ "<color:" @ (%z $= "000000" ? %x : %z) @ ">" @ %NF @ "<just:left>" @ %hs;
	}

	if(%HT)
		%t = %t @ " hp";

	if(%cl.zuiMod)
	{
		commandToClient(%cl, 'UpdateHealthUI', %t);

		if(isObject(%db) && %db.showEnergyBar || $zuisv_EBEnable)
		{
			%EF = getWord($zuisv_EBColor, 0);
			%EO = getWord($zuisv_EBColor, 1);
			%EZ = getWord($zuisv_EBColor, 2);
			%EI = $zuisv_EBColorF;
			%EM = $zuisv_EBColorE;
			%EU = $zuisv_EBColorM;

			if($zuisv_EBInherit)
			{
				%ESP = $zuisv_HBSpace;
				%ENR = $zuisv_HBNumber;
				%ENS = $zuisv_HBNumberS;
				%ENP = $zuisv_HBNumberP;
				%EFN = $zuisv_HBFont;
				%ENF = $zuisv_HBFontN;
				%EHT = $zuisv_HBTitle;
				%elen = getWord($zuisv_HBSymbol, 3);
				%es = getWord($zuisv_HBSymbol, 0);
				%es = strReplace(%s, "[x]", "");
				%eb = getWord($zuisv_HBSymbol, 1);
				%ee = getWord($zuisv_HBSymbol, 2);
				%ee = strReplace(%e, "[x]", "");
			}
			else
			{
				%ESP = $zuisv_EBSpace;
				%ENR = $zuisv_EBNumber;
				%ENS = $zuisv_EBNumberS;
				%ENP = $zuisv_EBNumberP;
				%EFN = $zuisv_EBFont;
				%ENF = $zuisv_EBFontN;
				%EHT = $zuisv_EBTitle;
				%elen = getWord($zuisv_EBSymbol, 3);
				%es = getWord($zuisv_EBSymbol, 0);
				%es = strReplace(%s, "[x]", "");
				%eb = getWord($zuisv_EBSymbol, 1);
				%ee = getWord($zuisv_EBSymbol, 2);
				%ee = strReplace(%e, "[x]", "");
			}

			%elv = 0;
			%enr = 0.0;
			%db = 38;
			if(isObject(%pl) && %pl.getDamagePercent() < 1.0)
			{
				%db = %pl.getDatablock();
				%elv = %pl.getEnergyLevel();
				%enr = mFloatLength(%elv / %db.maxEnergy, 2);
			}

			%EX = rgb2hex(coLerp(%EM, %EI, ((%enr - 0.5) * ((%EU * 2)+1)) + 0.5));

			%str = "<just:center>" @ %eFN @ "<color:" @ %EF @ ">" @ %es @ "<color:" @ %EX @ ">";
			for(%i = 0; %i < %elen; %i++)
			{
				if(%i == mCeil(%enr * %elen))
				{
					%str = %str @ "<color:" @ %EO @ ">";
				}

				if(%SP)
					%str = %str SPC %eb;
				else
					%str = %str @ %eb;
			}
			if(%SP)
				%str = %str SPC "<color:" @ %EF @ ">" @ %ee;
			else
				%str = %str @ "<color:" @ %EF @ ">" @ %ee;
			
			if(%NR)
			{
				if(%NP)
					%hs = %enr * 100 @ "%";
				else
					%hs = mFloatLength(%elv, 0) @ "/" @ %db.maxEnergy;
				
				%str = %str @ (%eNS ? " " : "<br>") @ "<color:" @ (%z $= "000000" ? %ex : %ez) @ ">" @ %eNF @ "<just:left>" @ %hs;
			}

			if(%EHT)
				%str = %str @ " mp";

			commandToClient(%cl, 'UpdateEnergyUI', %str);
		}
		else
			commandToClient(%cl, 'UpdateEnergyUI', "");
	}
	else
	{
		%t = %t @ "<br><just:center>" @ %cl.zuiExtraLine;
		%cl.bottomPrint(%t, 3, true);
	}
}

function zUpdateBUI(%cl)
{
	if(!%cl.zui)
		return;
	
	%tr = $zui_globalTarget;

	if(!isObject(%tr) || %tr == %cl.Player)
		%tr = %cl.zuiTarget;

	if(!isObject(%tr))
	{
		if(!%cl.zuiMod)
			%cl.zuiExtraLine = "";
		else
			commandToClient(%cl, 'UpdateBossHealthUI', "");
		
		return;
	}

	%tr.zuiTargeted = true; // targeted players will always restart the health loop on all clients to avoid too much desyncing

	%I = $zuisv_BBColorF;
	%M = $zuisv_BBColorE;
	%U = $zuisv_BBColorM;
	%len = getWord($zuisv_BBSymbol, 3);

	%s = getWord($zuisv_BBSymbol, 0);
	%s = strReplace(%s, "[x]", "");
	%b = getWord($zuisv_BBSymbol, 1);
	%e = getWord($zuisv_BBSymbol, 2);
	%e = strReplace(%e, "[x]", "");

	%F = getWord($zuisv_BBColor, 0);
	%O = getWord($zuisv_BBColor, 1);
	%Z = getWord($zuisv_BBColor, 2);

	%SP = $zuisv_BBSpace;
	%NR = $zuisv_BBNumber;
	%NS = $zuisv_BBNumberS;
	%NP = $zuisv_BBNumberP;
	%FN = $zuisv_BBFont;
	%NF = $zuisv_BBFontN;
	%TN = $zuisv_BBTargetN;
	%HT = $zuisv_BBTitle;

	%h = 0.0;

	%db = %tr.getDatablock();

	if(isObject(%tr))
	{
		%h = (%db.maxDamage - %tr.getDamageLevel()) / %db.maxDamage;
		%h = mFloatLength(%h, 2);
	}

	%X = rgb2hex(coLerp(%M, %I, ((%h - 0.5) * ((%U * 2)+1)) + 0.5));

	%t = "<just:center>" @ %FN @ "<color:" @ %F @ ">" @ %s @ "<color:" @ %X @ ">";
	for(%i = 0; %i < %len; %i++)
	{
		if(%i == mCeil(%h * %len))
		{
			%t = %t @ "<color:" @ %O @ ">";
		}

		if(%SP)
			%t = %t SPC %b;
		else
			%t = %t @ %b;
	}
	if(%SP)
		%t = %t SPC "<color:" @ %F @ ">" @ %e;
	else
		%t = %t @ "<color:" @ %F @ ">" @ %e;
	
	%j = %tr.Name;
	if(%j $= "" && %tr.DisplayName !$= "")
		%j = %tr.DisplayName;
	else if(%j $= "" && isObject(%tr.Client))
		%j = %tr.Client.getPlayerName();
	
	if(%NP)
		%hs = %h * 100 @ "%";
	else
		%hs = mFloatLength(%db.maxDamage - %tr.getDamageLevel(), 0) @ "/" @ %db.maxDamage;

	if(!%NS)
	{
		%t = %t @ %NF @ "<color:" @ (%z $= "000000" ? %x : %z) @ ">";
		
		if(%NR)
			%t = %t SPC "<just:left>" @ %hs;
		
		if(%TN)
			%t = %t @ "<br>" @ %j;
	}
	else
	{
		%t = %t @ "<br>" @ %NF @ "<color:" @ (%z $= "000000" ? %x : %z) @ ">";

		if(%TN)
			%t = %t @ %j;

		if(%NR)
		{
			if(%TN)
				%t = %t @ " - ";
			
			%t = %t @ %hs;
		}
	}

	if(%HT)
		%t = %t @ " hp";

	if(%cl.zuiMod)
		commandToClient(%cl, 'UpdateBossHealthUI', %t);
	else
	{
		if(%TN)
			%s = %j;
		
		if(%NR)
		{
			if(%TN)
				%s = %s @ " - ";
			
			if(%NP)
				%hs = %h * 100 @ "%";
			else
				%hs = mFloatLength(%db.maxDamage - %tr.getDamageLevel(), 0) @ "/" @ %db.maxDamage;
			
			%s = "<color:" @ (%z $= "000000" ? %x : %z) @ ">" @ %s @ %hs;

			if(%HT)
				%s = %s @ " hp";
		}

		%cl.zuiExtraLine = %s;
	}
}

registerOutputEvent(Bot, "SetGlobalTarget", "bool", 0);
registerOutputEvent(Player, "SetGlobalTarget", "bool", 0);

function Player::SetGlobalTarget(%pl, %val)
{
	if(%val)
		$zui_globalTarget = %pl;
	else if(!%val && $zui_globalTarget == %pl)
		$zui_globalTarget = "";
}

// other shit

function floatLerp(%from, %to, %at)
{
	%at = mClampF(%at, 0, 1.0);
	%to = mClampF(%to, 0, 1.0);
	%from = mClampF(%from, 0, 1.0);
	return mClampF(((%to - %from) * %at) + %from, 0, 1.0);
}

function coLerp(%from, %to, %at)
{
	%r = floatLerp(getWord(%from, 0), getWord(%to, 0), %at);
	%g = floatLerp(getWord(%from, 1), getWord(%to, 1), %at);
	%b = floatLerp(getWord(%from, 2), getWord(%to, 2), %at);

	return (%r SPC %g SPC %b);
}

function rgb2hex( %rgb )
{
	%r = comp2hex( 255 * getWord( %rgb, 0 ) );
	%g = comp2hex( 255 * getWord( %rgb, 1 ) );
	%b = comp2hex( 255 * getWord( %rgb, 2 ) );
 
	return %r @ %g @ %b;
}

function comp2hex( %comp )
{
	%left = mFloor( %comp / 16 );
	%comp = mFloor( %comp - %left * 16 );
	
	%left = getSubStr( "0123456789ABCDEF", %left, 1 );
	%comp = getSubStr( "0123456789ABCDEF", %comp, 1 );
	
	return %left @ %comp;
}
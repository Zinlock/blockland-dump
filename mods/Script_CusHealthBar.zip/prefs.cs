// NOTE: you should not edit this
// use this file as a reference for what values to edit in config/server/zui.cs
// you need to host at least once for the zui.cs file to show up
// this is just a bunch of default values

// btw the prefs are saved whenever a client is detected or when the server closes via quit()
// you can re-detect the client by doing /nohealthclient twice

// USER HEALTH BAR

$zuisv_HBColor = "FFFFFF 444444 FFFFFF"; // HEX: sides, empty ticks, number (000000 to use tick color)
$zuisv_HBColorF = "0.3 1.0 0.3"; // RGB: ticks, 100% hp
$zuisv_HBColorE = "1.0 0.3 0.1"; // RGB: ticks, 0% hp
$zuisv_HBColorM = 0.25; // FLOAT: when to start changing colors (not accurate)
$zuisv_HBFont = "<font:impact:30>"; // FONT: health bar
$zuisv_HBFontN = "<font:arial:14>"; // FONT: number
$zuisv_HBSymbol = "[x] . [x] 60"; // SYMBOLS: left side, ticks, right side, tick amount ([X] for no sides)
$zuisv_HBSpace = false; // BOOL: spaces between each sides/ticks (takes up a lot of space, quickly reaches the character limit)
$zuisv_HBNumber = true; // BOOL: add health as number after bar
$zuisv_HBNumberS = true; // BOOL: show health number next to bar // TODO: add a setting to move number and title above or to the left of the health bar
$zuisv_HBNumberP = true; // BOOL: show health as percent or as current/max
$zuisv_HBTitle = true; // BOOL: show "HP" next to bar

// USER ENERGY BAR

$zuisv_EBColor = "FFFFFF 444444 FFFFFF";
$zuisv_EBColorF = "0.0 0.5 1.0";
$zuisv_EBColorE = "0.8 0.0 1.0";
$zuisv_EBColorM = 0.25;
$zuisv_EBFont = "<font:impact:30>";
$zuisv_EBFontN = "<font:arial:14>";
$zuisv_EBSymbol = "[x] . [x] 60";
$zuisv_EBSpace = false;
$zuisv_EBNumber = true;
$zuisv_EBNumberS = true;
$zuisv_EBNumberP = true;
$zuisv_EBTitle = true;
$zuisv_EBInherit = true; // BOOL: use health bar appearance (or separate energy bar appearance, color will never be inherited)
$zuisv_EBEnable = true; // BOOL: always show energy bar

// BOSS HEALTH BAR

$zuisv_BBColor = "FFFFFF 444444 FFFFFF";
$zuisv_BBColorF = "1.0 1.0 0.3";
$zuisv_BBColorE = "1.0 0.2 0.1";
$zuisv_BBColorM = 0.25;
$zuisv_BBFont = "<font:impact:30>";
$zuisv_BBFontN = "<font:arial:16>";
$zuisv_BBSymbol = "[x] . [x] 100";
$zuisv_BBSpace = false;
$zuisv_BBNumber = true;
$zuisv_BBNumberP = false;
$zuisv_BBNumberS = true;
$zuisv_BBTitle = true;
$zuisv_BBTargetN = true; // BOOL: show boss target name

// glass prefs are annoying to make;;'
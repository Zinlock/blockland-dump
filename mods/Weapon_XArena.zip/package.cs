package XArenaPackage
{
	function Player::unBlockImageDismount(%pl) // put here for aebase compatibility
	{
		cancel(%pl.blockSchedule);

		Parent::unBlockImageDismount(%pl);
	}

	function Projectile::onAdd(%obj)
	{
		Parent::onAdd(%obj);

		%db = %obj.getdatablock();
		if(%db.isXWProjectile)
			%obj.directDamage = $XW_SlashDamage[%obj.ST_SlashID];
	}

	function Player::Damage(%pl, %src, %pos, %dmg, %type)
	{
		if((%type == $DamageType::Impact || %type == $DamageType::Fall) && %pl.fallImmune)
			return;

		Parent::Damage(%pl, %src, %pos, %dmg, %type);
	}

	function AIPlayer::hShoot(%pl, %slot, %trig)
	{
		if((!%pl.hIsEngaged || !%pl.hIsInLOS) && %trig)
			return Parent::hShoot(%pl, %slot, %trig);

		%img = %pl.getMountedImage(0);

		if(%slot == 0 && %trig && %img.isXWeaponImage)
		{
			%stat = %img.StatObj;
			%target = %pl.hFollowing;

			if(!isObject(%target))
				return Parent::hShoot(%pl, %slot, %trig);

			if(%stat.NumBotAttacks <= 0)
			{
				%img.onTrigger(%pl, 0, 1);
				%img.schedule(50, onTrigger, %pl, 0, 0);
			}
			else
			{
				%pl.hAvoidCloseRange = true;
				%pl.hTooCloseRange = 4;

				// are we already attacking?
				if(getSimTime() - %pl.xLastAttackStartTime < %pl.xLastAttackLength)
					return;

				// which attacks can we use?
				%atks = 0;
				%weight = 0;

				%dist = vectorDist(%pl.getPosition(), %target.getPosition());
				for(%i = 0; %i < %stat.NumBotAttacks; %i++)
				{
					if(getSimTime() - %pl.xLastAttackTime[%i] < %stat.BotAttackCooldown[%i] * 1000)
						continue;

					if(%dist < %stat.BotAttackMinRange[%i] || %dist > %stat.BotAttackMaxRange[%i])
						continue;

					%ready = true;

					for(%j = 0; %j < getWordCount(%stat.BotAttackList[%i]); %j++)
					{
						if(!%pl.checkCooldown(getWord(%stat.BotAttackList[%i], %j), true))
						{
							%ready = false;
							break;
						}
					}

					if(!%ready)
						continue;
					
					%weight += %stat.BotAttackWeight[%i];
					%atk[%atks] = %i;
					%atkWeight[%atks] = %stat.BotAttackWeight[%i];
					%atks++;
				}

				if(%atks > 0)
				{
					%pick = 0;
					%rand = getRandom() * %weight;
					%currWeight = 0;
					for(%i = 0; %i < %atks; %i++)
					{
						%currWeight += %atkWeight[%i];
						if(%rand > %currWeight)
							continue;

						%pick = %atk[%i];
						break;
					}

					%total = 0;
					%cts = getFieldCount(%stat.BotAttack[%pick]);

					// we have an attack, schedule it out
					for(%i = 0; %i < %cts; %i++)
					{
						%field = getField(%stat.BotAttack[%pick], %i);
						%trig = getWord(%field, 0);
						%trigTime = getWord(%field, 1);
						%trigDelay = getWord(%field, 2);

						if(%trigTime > 0)
						{
							%img.schedule(%total, onTrigger, %pl, %trig, 1);
							%img.schedule(%total + %trigTime, onTrigger, %pl, %trig, 0);
						}
						else
							%img.schedule(%total, onTrigger, %pl, %trig, -1);

						%total += %trigDelay;
					}

					%pl.xLastAttackTime[%pick] = getSimTime();
					%pl.xLastAttackStartTime = getSimTime();
					%pl.xLastAttackLength = %total;
					return;
				}

				// no attacks available, stay away
				%pl.hTooCloseRange = 16;
			}
		}
		else
			return Parent::hShoot(%pl, %slot, %trig);
	}

	function serverCmdUseTool(%cl, %slot)
	{
		if(isObject(%pl = %cl.Player) && %pl.blockImageDismount)
		{
			%pl.tempItemSlot = %slot;
			return;
		}

		Parent::serverCmdUseTool(%cl, %slot);
	}

	function serverCmdUnuseTool(%cl)
	{
		if(isObject(%pl = %cl.Player) && %pl.blockImageDismount)
		{
			%pl.tempItemSlot = -1;
			return;
		}

		Parent::serverCmdUnuseTool(%cl);
	}
};
activatePackage(XArenaPackage);
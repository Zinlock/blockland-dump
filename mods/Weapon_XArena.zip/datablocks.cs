// * Audio
	// * Swings
	datablock AudioProfile(XW_Swing1Sound) { filename = "./wav/swing1.wav"; description = AudioClose3D; preload = true; };
	datablock AudioProfile(XW_Swing1LowSound : XW_Swing1Sound) { filename = "./wav/swing1_lo.wav"; };
	datablock AudioProfile(XW_Swing1HighSound : XW_Swing1Sound) { filename = "./wav/swing1_hi.wav"; };
	
	datablock AudioProfile(XW_Swing2Sound : XW_Swing1Sound) { filename = "./wav/swing2.wav"; };
	datablock AudioProfile(XW_Swing2LowSound : XW_Swing1Sound) { filename = "./wav/swing2_lo.wav"; };
	datablock AudioProfile(XW_Swing2HighSound : XW_Swing1Sound) { filename = "./wav/swing2_hi.wav"; };
	
	datablock AudioProfile(XW_Swing3Sound : XW_Swing1Sound) { filename = "./wav/swing3.wav"; };
	datablock AudioProfile(XW_Swing4Sound : XW_Swing1Sound) { filename = "./wav/swing4.wav"; };
	
	datablock AudioProfile(XW_Thrust1Sound : XW_Swing1Sound) { filename = "./wav/thrust1.wav"; };
	
	// * Other
	datablock AudioProfile(XW_Special1Sound : XW_Swing1Sound) { filename = "./wav/special1.wav"; };
	datablock AudioProfile(XW_Special2Sound : XW_Swing1Sound) { filename = "./wav/special2.wav"; };

	datablock AudioProfile(XW_StunSound : XW_Swing1Sound) { filename = "./wav/stun.wav"; };

	datablock AudioProfile(XW_BlockFullSound : XW_Swing1Sound) { filename = "./wav/block_full.wav"; };
	datablock AudioProfile(XW_BlockHalfSound : XW_Swing1Sound) { filename = "./wav/block_half.wav"; };
	datablock AudioProfile(XW_BlockBreakSound : XW_Swing1Sound) { filename = "./wav/block_Break.wav"; };
	
	// * Hits
	datablock AudioProfile(XW_HitBat1Sound : XW_Swing1Sound) { filename = "./wav/hit_bat1.wav"; };

	datablock AudioProfile(XW_HitBlunt1Sound : XW_Swing1Sound) { filename = "./wav/hit_blunt1.wav"; };
	datablock AudioProfile(XW_HitBlunt2Sound : XW_Swing1Sound) { filename = "./wav/hit_blunt2.wav"; };

	datablock AudioProfile(XW_HitHeavy1Sound : XW_Swing1Sound) { filename = "./wav/hit_heavy1.wav"; };
	datablock AudioProfile(XW_HitHeavy2Sound : XW_Swing1Sound) { filename = "./wav/hit_heavy2.wav"; };
	datablock AudioProfile(XW_HitHeavy3Sound : XW_Swing1Sound) { filename = "./wav/hit_heavy3.wav"; };
	datablock AudioProfile(XW_HitHeavy4Sound : XW_Swing1Sound) { filename = "./wav/hit_heavy4.wav"; };

	datablock AudioProfile(XW_HitSlash1Sound : XW_Swing1Sound) { filename = "./wav/hit_slash1.wav"; };
	datablock AudioProfile(XW_HitStab1Sound : XW_Swing1Sound) { filename = "./wav/hit_stab1.wav"; };

	// * Critical Hits
	datablock AudioProfile(XW_CriticalHitSound : XW_Swing1Sound) { filename = "./wav/critical.wav"; };
	datablock AudioProfile(XW_CriticalTakenSound : XW_Swing1Sound) { filename = "./wav/critical_taken.wav"; };

// * Slash Shapes
	datablock StaticShapeData(XW_EmptySlash) { shapeFile = "base/data/shapes/empty.dts"; };
	datablock StaticShapeData(XW_BlueSlashTrail) { shapeFile = "./dts/trail_blue/trail.dts"; };
	datablock StaticShapeData(XW_GreenSlashTrail) { shapeFile = "./dts/trail_green/trail.dts"; };
	datablock StaticShapeData(XW_RedSlashTrail) { shapeFile = "./dts/trail_red/trail.dts"; };
	datablock StaticShapeData(XW_YellowSlashTrail) { shapeFile = "./dts/trail_yellow/trail.dts"; };
	datablock StaticShapeData(XW_PurpleSlashTrail) { shapeFile = "./dts/trail_purple/trail.dts"; };
	datablock StaticShapeData(XW_SimpleSlashTrail) { shapeFile = "./dts/trail_simple/trail.dts"; };

// * Generic Projectile
	datablock ProjectileData(XW_GenericProjectile)
	{
		projectileShapeName = "base/data/shapes/empty.dts";
		directDamage        = 50;
		directDamageType    = $DamageType::XW;
		radiusDamageType    = $DamageType::XW;

		impactImpulse       = 0;
		verticalImpulse     = 0;
		explosion           = "";
		bloodExplosion      = "";

		muzzleVelocity      = 50;
		velInheritFactor    = 0;

		armingDelay         = 0;
		lifetime            = 100;
		fadeDelay           = 99;
		bounceElasticity    = 0.5;
		bounceFriction      = 0.20;
		isBallistic         = false;

		hasLight    = false;
		lightRadius = 3.0;
		lightColor  = "0 0 0.5";

		isXWProjectile = true;
	};

	function XW_GenericProjectile::Damage(%db, %proj, %col, %fade, %pos, %normal)
	{
		if(!isObject(%col) || !isObject(%pl = %proj.sourceObject))
			return;

		%sid = %proj.ST_SlashID;
		if(%sid $= "")
			return;

		%stat = $XW_SlashObject[%sid];

		%preCallback = $XW_SlashPreCallback[%sid];
		if(%preCallback !$= "")
		{
			if(isObject(%stat) && isFunction(%stat.getName(), %preCallback))
				eval(%stat @ "." @ %preCallback @ "(" @ %pl @ ", " @ %col @ ", " @ %proj @ ");");
			else if(isFunction(%preCallback))
				call(%preCallback, %pl, %col, %proj);
		}

		%dmg = %db.directDamage;

		if(%proj.directDamage $= "")
			%proj.directDamage = $XW_SlashDamage[%proj.ST_SlashID];

		%db.directDamage = %proj.directDamage;

		Parent::Damage(%db, %proj, %col, %fade, %pos, %normal);

		%db.directDamage = %dmg;

		%postCallback = $XW_SlashPostCallback[%sid];
		if(%postCallback !$= "")
		{
			if(isObject(%stat) && isFunction(%stat.getName(), %postCallback))
				eval(%stat @ "." @ %postCallback @ "(" @ %pl @ ", " @ %col @ ", " @ %proj @ ");");
			else if(isFunction(%postCallback))
				call(%postCallback, %pl, %col, %proj);
		}
	}

// * Default Hit Effects
	datablock ParticleData(XW_GenericHitSparksParticle)
	{
		dragCoefficient    = 1.0;
		windCoefficient    = 0.0;
		gravityCoefficient = 0.4;

		inheritedVelFactor   = 0.0;
		constantAcceleration = 0.0;

		lifetimeMS         = 500;
		lifetimeVarianceMS = 300;

		spinSpeed      = 10.0;
		spinRandomMin  = -50.0;
		spinRandomMax  = 50.0;

		useInvAlpha    = false;
		animateTexture = false;

		textureName		= "base/data/particles/dot";

		colors[0] = "1 0 0.0 1";
		colors[1] = "0.9 0 0.0 0.9";
		colors[2] = "1 0.1 0.3 0.0";

		sizes[0] = 0.1;
		sizes[1] = 0.1;
		sizes[2] = 0.1;

		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};

	datablock ParticleEmitterData(XW_GenericHitSparksEmitter)
	{
		ejectionPeriodMS = 2;
		periodVarianceMS = 0;
		lifetimeMS       = 50;

		ejectionVelocity = 4;
		velocityVariance = 1.0;
		ejectionOffset   = 0.0;

		thetaMin         = 0;
		thetaMax         = 180;
		phiReferenceVel  = 0;
		phiVariance      = 360;

		overrideAdvance = false;

		particles = "XW_GenericHitSparksParticle";
	};

	datablock ParticleData(XW_GenericHitFlashParticle)
	{
		dragCoefficient    = 1.0;
		windCoefficient    = 0.0;
		gravityCoefficient = 0.1;

		inheritedVelFactor   = 0.0;
		constantAcceleration = 0.0;

		lifetimeMS         = 100;
		lifetimeVarianceMS = 50;

		spinSpeed      = 0.0;
		spinRandomMin  = 0.0;
		spinRandomMax  = 0.0;

		useInvAlpha    = false;
		animateTexture = false;

		textureName		= "./dts/blastCorona1";

		colors[0] = "1 0 0.0 1";
		colors[1] = "0.9 0 0.0 0.9";
		colors[2] = "1 1 1 0.0";

		sizes[0] = 0.6;
		sizes[1] = 2.0;
		sizes[2] = 4.0;

		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};

	datablock ParticleEmitterData(XW_GenericHitFlashEmitter)
	{
		ejectionPeriodMS = 5;
		periodVarianceMS = 0;
		lifetimeMS       = 30;

		ejectionVelocity = 0.0;
		velocityVariance = 0.0;
		ejectionOffset   = 0.0;

		thetaMin         = 0;
		thetaMax         = 180;
		phiReferenceVel  = 0;
		phiVariance      = 360;

		overrideAdvance = false;

		particles = "XW_GenericHitFlashParticle";
	};

	datablock ParticleData(XW_GenericHitFlash2Particle)
	{
		dragCoefficient    = 1.0;
		windCoefficient    = 0.0;
		gravityCoefficient = 0.1;

		inheritedVelFactor   = 0.0;
		constantAcceleration = 0.0;

		lifetimeMS         = 300;
		lifetimeVarianceMS = 100;

		spinSpeed      = 10.0;
		spinRandomMin  = -50.0;
		spinRandomMax  = 50.0;

		useInvAlpha    = false;
		animateTexture = false;

		textureName		= "./dts/blastFlash2";

		colors[0] = "1 0 0.0 1";
		colors[1] = "0.9 0 0.0 0.9";
		colors[2] = "1 0 0 0.0";

		sizes[0] = 1.0;
		sizes[1] = 2.0;
		sizes[2] = 8.0;

		times[0] = 0.0;
		times[1] = 0.1;
		times[2] = 1.0;
	};

	datablock ParticleEmitterData(XW_GenericHitFlash2Emitter)
	{
		ejectionPeriodMS = 15;
		periodVarianceMS = 0;
		lifetimeMS       = 30;

		ejectionVelocity = 0.5;
		velocityVariance = 0.5;
		ejectionOffset   = 0.0;

		thetaMin         = 0;
		thetaMax         = 180;
		phiReferenceVel  = 0;
		phiVariance      = 360;

		overrideAdvance = false;

		particles = "XW_GenericHitFlash2Particle";
	};

	datablock ExplosionData(XW_GenericHitFxExplosion)
	{
		lifeTimeMS = 150;

		emitter[0] = XW_GenericHitSparksEmitter;
		emitter[1] = XW_GenericHitFlashEmitter;
		emitter[2] = XW_GenericHitFlash2Emitter;
	};

	datablock ProjectileData(XW_GenericHitFxProjectile : XW_GenericProjectile)
	{
		directDamage = 0;

		explosion      = XW_GenericHitFxExplosion;
		bloodExplosion = XW_GenericHitFxExplosion;

		isXWProjectile = false;
	};

// * Critical Hit Effects
	datablock ParticleData(XW_CriticalHitSparksParticle : XW_GenericHitSparksParticle)
	{
		lifetimeMS         = 700;
		lifetimeVarianceMS = 400;

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.2 0.9";
		colors[2] = "1 1 0.5 0.0";
	};

	datablock ParticleEmitterData(XW_CriticalHitSparksEmitter : XW_GenericHitSparksEmitter)
	{
		particles = "XW_CriticalHitSparksParticle";
	};

	datablock ParticleData(XW_CriticalHitFlashParticle : XW_GenericHitFlashParticle)
	{
		lifetimeMS         = 400;
		lifetimeVarianceMS = 200;

		textureName		= "base/lighting/flare";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.2 0.9";
		colors[2] = "1 1 0.5 0.0";

		sizes[0] = 0.9;
		sizes[1] = 3.0;
		sizes[2] = 6.0;
	};

	datablock ParticleEmitterData(XW_CriticalHitFlashEmitter : XW_GenericHitFlashEmitter)
	{
		particles = "XW_CriticalHitFlashParticle";
	};

	datablock ParticleData(XW_CriticalHitFlash2Particle : XW_GenericHitFlashParticle)
	{
		lifetimeMS         = 600;
		lifetimeVarianceMS = 300;

		textureName		= "base/data/particles/thinRing";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.2 0.9";
		colors[2] = "1 1 0.5 0.0";

		sizes[0] = 0.9;
		sizes[1] = 1.0;
		sizes[2] = 3.5;
	};

	datablock ParticleEmitterData(XW_CriticalHitFlash2Emitter : XW_GenericHitFlashEmitter)
	{
		ejectionPeriodMS = 15;

		particles = "XW_CriticalHitFlash2Particle";
	};

	datablock ExplosionData(XW_CriticalHitFxExplosion)
	{
		lifeTimeMS = 150;

		shakeCamera = true;
		camShakeFreq = "1.0 1.0 1.0";
		camShakeAmp = "9.0 9.0 9.0";
		camShakeDuration = 0.5;
		camShakeRadius = 5.0;

		emitter[0] = XW_CriticalHitSparksEmitter;
		emitter[1] = XW_CriticalHitFlashEmitter;
		emitter[2] = XW_CriticalHitFlash2Emitter;
	};

	datablock ProjectileData(XW_CriticalHitFxProjectile : XW_GenericProjectile)
	{
		directDamage = 0;

		explosion      = XW_CriticalHitFxExplosion;
		bloodExplosion = XW_CriticalHitFxExplosion;

		isXWProjectile = false;
	};

// * Perfect Block Effects
	datablock ParticleData(XW_PerfectBlockSparksParticle : XW_GenericHitSparksParticle)
	{
		textureName = "base/data/particles/nut";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.0 0.9";
		colors[2] = "1 1 0 0.0";

		sizes[0] = 0.2;
		sizes[1] = 0.3;
		sizes[2] = 0.4;
	};

	datablock ParticleEmitterData(XW_PerfectBlockSparksEmitter : XW_GenericHitSparksEmitter)
	{
		ejectionPeriodMS = 2;
		ejectionVelocity = 7;
		particles = "XW_PerfectBlockSparksParticle";
	};

	datablock ParticleData(XW_PerfectBlockFlashParticle : XW_GenericHitFlashParticle)
	{
		lifetimeMS         = 300;
		lifetimeVarianceMS = 200;

		textureName = "base/data/particles/nut";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.0 0.9";
		colors[2] = "1 1 1 0.0";
	};

	datablock ParticleEmitterData(XW_PerfectBlockFlashEmitter : XW_GenericHitFlashEmitter)
	{
		ejectionPeriodMS = 15;

		particles = "XW_PerfectBlockFlashParticle";
	};

	datablock ParticleData(XW_PerfectBlockFlash2Particle : XW_GenericHitFlashParticle)
	{
		lifetimeMS         = 200;
		lifetimeVarianceMS = 100;

		textureName = "base/lighting/flare";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.0 0.9";
		colors[2] = "1 1 0.5 0.0";

		sizes[0] = 0.9;
		sizes[1] = 3.0;
		sizes[2] = 6.0;
	};

	datablock ParticleEmitterData(XW_PerfectBlockFlash2Emitter : XW_GenericHitFlashEmitter)
	{
		ejectionPeriodMS = 15;

		particles = "XW_PerfectBlockFlash2Particle";
	};

	datablock ExplosionData(XW_PerfectBlockFxExplosion)
	{
		lifeTimeMS = 150;

		shakeCamera = true;
		camShakeFreq = "1.0 1.0 1.0";
		camShakeAmp = "1.0 1.0 1.0";
		camShakeDuration = 0.5;
		camShakeRadius = 5.0;

		emitter[0] = XW_PerfectBlockSparksEmitter;
		emitter[1] = XW_PerfectBlockFlashEmitter;
		emitter[2] = XW_PerfectBlockFlash2Emitter;
	};

	datablock ProjectileData(XW_PerfectBlockFxProjectile : XW_GenericProjectile)
	{
		directDamage = 0;

		explosion      = XW_PerfectBlockFxExplosion;
		bloodExplosion = XW_PerfectBlockFxExplosion;

		isXWProjectile = false;
	};

// * Half Block Effects
	datablock ParticleData(XW_HalfBlockSparksParticle : XW_GenericHitSparksParticle)
	{
		textureName = "base/data/particles/nut";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.0 0.9";
		colors[2] = "1 1 0 0.0";

		sizes[0] = 0.1;
		sizes[1] = 0.2;
		sizes[2] = 0.3;
	};

	datablock ParticleEmitterData(XW_HalfBlockSparksEmitter : XW_GenericHitSparksEmitter)
	{
		ejectionPeriodMS = 4;
		ejectionVelocity = 5;

		particles = "XW_HalfBlockSparksParticle";
	};

	datablock ParticleData(XW_HalfBlockFlashParticle : XW_GenericHitFlashParticle)
	{
		lifetimeMS         = 100;
		lifetimeVarianceMS = 50;

		textureName = "base/data/particles/nut";

		colors[0] = "1 0.5 0.0 1";
		colors[1] = "0.9 0.5 0.0 0.9";
		colors[2] = "1 1 0.5 0.0";
	};

	datablock ParticleEmitterData(XW_HalfBlockFlashEmitter : XW_GenericHitFlashEmitter)
	{
		ejectionPeriodMS = 15;

		particles = "XW_HalfBlockFlashParticle";
	};

	datablock ExplosionData(XW_HalfBlockFxExplosion)
	{
		lifeTimeMS = 150;

		emitter[0] = XW_HalfBlockSparksEmitter;
		emitter[1] = XW_HalfBlockFlashEmitter;
	};

	datablock ProjectileData(XW_HalfBlockFxProjectile : XW_GenericProjectile)
	{
		directDamage = 0;

		explosion      = XW_HalfBlockFxExplosion;
		bloodExplosion = XW_HalfBlockFxExplosion;

		isXWProjectile = false;
	};

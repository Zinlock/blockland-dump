datablock PlayerData(XW_SwordAI : EmptyAI) { shapeFile = "./dts/crystalsword_image.dts"; isXWeaponBot = true; };

datablock ItemData(XW_SwordItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./dts/crystalsword_item.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "XA: Crystal Sword";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0.0 0.3 0.9 1";

	image = XW_SwordImage;
	canDrop = true;
};

datablock ShapeBaseImageData(XW_SwordImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = true;

	mountPoint = 0;
	eyeOffset = 0;

	className = "WeaponImage";

	XWeaponData = XW_SwordAI;

	hideNodes = "rHand rHook lHand lHook";
	twoHanded = true;

	item = XW_SwordItem;

	isXWeaponImage = true;

	armReady = true;

	colorShiftNodes = "sword";
	colorShiftColor = XW_SwordItem.colorShiftColor;

	stateName[0] = "Activate";
	stateTimeoutValue[0] = 0.4;
	stateTransitionOnTimeout[0] = "Ready";

	stateName[1] = "Ready";
	stateScript[1] = "onReady";
};

function XW_SwordImage::onMount(%db, %pl, %slot)
{
	%pl.mountXWeaponBot(%db);
	Parent::onMount(%db, %pl, %slot);
	%pl.XWLoop();
}

function XW_SwordImage::onUnMount(%db, %pl, %slot)
{
	Parent::onUnMount(%db, %pl, %slot);
	%pl.unMountXWeaponBot();
	%pl.preMountXWeaponBot(%db);
	%pl.XWBlockEnd();
}

if(isObject(XW_SwordStatObj)) XW_SwordStatObj.delete();

new ScriptObject(XW_SwordStatObj)
{
	class = "XW_StatObj";

// * Bots

	NumBotAttacks = 12;

	BotAttack[0] = "0 50 700" TAB "0 50 600";
	BotAttackMinRange[0] = 0;
	BotAttackMaxRange[0] = 5;
	BotAttackWeight[0] = 10;
	BotAttackCooldown[0] = 0;
	BotAttackList[0] = "";

	BotAttack[1] = "0 500 500";
	BotAttackMinRange[1] = 0;
	BotAttackMaxRange[1] = 5;
	BotAttackWeight[1] = 8;
	BotAttackCooldown[1] = 2;
	BotAttackList[1] = "";

	BotAttack[2] = "0 50 700" TAB "0 50 700" TAB "0 50 900" TAB "0 500 500";
	BotAttackMinRange[2] = 0;
	BotAttackMaxRange[2] = 8;
	BotAttackWeight[2] = 7;
	BotAttackCooldown[2] = 2;
	BotAttackList[2] = "";

	BotAttack[3] = "0 500 500" TAB "6 0 900" TAB "5 0 800";
	BotAttackMinRange[3] = 1;
	BotAttackMaxRange[3] = 6;
	BotAttackWeight[3] = 4;
	BotAttackCooldown[3] = 14;
	BotAttackList[3] = "Spear Spike Wave";

	BotAttack[4] = "5 0 1200" TAB "6 0 1000";
	BotAttackMinRange[4] = 4;
	BotAttackMaxRange[4] = 18;
	BotAttackWeight[4] = 3;
	BotAttackCooldown[4] = 20;
	BotAttackList[4] = "Wave Spike";

	BotAttack[5] = "5 0 1000" TAB "0 600 0";
	BotAttackMinRange[5] = 0;
	BotAttackMaxRange[5] = 4;
	BotAttackWeight[5] = 4;
	BotAttackCooldown[5] = 10;
	BotAttackList[5] = "Spike";

	BotAttack[6] = "5 0 1000";
	BotAttackMinRange[6] = 3;
	BotAttackMaxRange[6] = 18;
	BotAttackWeight[6] = 5;
	BotAttackCooldown[6] = 12;
	BotAttackList[6] = "Wave";

	BotAttack[7] = "4 1000 1000"; // block
	BotAttackMinRange[7] = 0;
	BotAttackMaxRange[7] = 8;
	BotAttackWeight[7] = 4;
	BotAttackCooldown[7] = 0;
	BotAttackList[7] = "";

	BotAttack[8] = "4 200 900" TAB "0 50 1000" TAB "4 1000 1000"; // block atk block
	BotAttackMinRange[8] = 0;
	BotAttackMaxRange[8] = 8;
	BotAttackWeight[8] = 2;
	BotAttackCooldown[8] = 2;
	BotAttackList[8] = "";

	BotAttack[9] = "4 300 900" TAB "0 50 600"; // block atk
	BotAttackMinRange[9] = 0;
	BotAttackMaxRange[9] = 8;
	BotAttackWeight[9] = 2;
	BotAttackCooldown[9] = 2;
	BotAttackList[9] = "";

	BotAttack[10] = "0 50 900" TAB "4 1000 1000"; // atk block
	BotAttackMinRange[10] = 0;
	BotAttackMaxRange[10] = 8;
	BotAttackWeight[10] = 2;
	BotAttackCooldown[10] = 2;
	BotAttackList[10] = "";

	BotAttack[11] = "0 50 900" TAB "4 400 1200" TAB "0 50 600" TAB "0 50 600"; // atk block atk
	BotAttackMinRange[11] = 0;
	BotAttackMaxRange[11] = 8;
	BotAttackWeight[11] = 2;
	BotAttackCooldown[11] = 2;
	BotAttackList[11] = "";

// * Stats
	SwingDamage = 18;
	SwingDirectImpulse = 7;
	SwingVerticalImpulse = 5;

	UpperDamage = 20;
	UpperDirectImpulse = 4;
	UpperVerticalImpulse = 15;

	SpearDamage = 24;
	SpearCritDamage = 32;
	SpearDirectImpulse = 14;
	SpearVerticalImpulse = 8;
	SpearCooldown = 2;

	WaveDamage = 18;
	WaveSpeed = 15;
	WaveDirectImpulse = 15;
	WaveVerticalImpulse = 5;
	WaveCooldown = 7;

	SpikeDamage = 40;
	SpikeShockDamage = 15;
	SpikeShockImpulse = 15;
	SpikeShockVerticalImpulse = 15;
	SpikeDirectImpulse = 5;
	SpikeVerticalImpulse = -15;
	SpikeCooldown = 9;

	AttackList = "Spear Hold LMB" TAB "Block Hold RMB" TAB "Wave E" TAB "Spike R";

// * Idle
	stateName[0] = "draw";
	stateThread[0] = "equip";
	stateTimeout[0] = 0.5;
	stateTransitionOnTimeout[0] = "idle";

	stateName[1] = "idle";
	stateThread[1] = "";
	stateScript[1] = "onIdle";
	stateTransitionOnTriggerPush[1, 0] = "mainAltCheck";
	stateTransitionOnTriggerDown[1, 4] = "BlockCheck";
	stateTransitionOnTriggerPush[1, 5] = "WaveCheck";
	stateTransitionOnTriggerPush[1, 6] = "SpikeCheck";

// * Swings
	stateName[2] = "swingL";
	stateThread[2] = "SwingL";
	stateScript[2] = "onSwingL";
	stateScriptDelay[2] = 0.15;
	stateSound[2] = XW_Swing1HighSound;
	stateSoundDelay[2] = 0.1;
	stateTimeout[2] = 0.4;
	stateTransitionOnTimeout[2] = "swingAltCheck";

	stateName[4] = "swingAltCheck";
	stateTimeout[4] = 0.4;
	stateTransitionOnTriggerPush[4, 0] = "swingR";
	stateTransitionOnTimeout[4] = "idle";

	stateName[3] = "swingR";
	stateThread[3] = "SwingR";
	stateScript[3] = "onSwingR";
	stateScriptDelay[3] = 0.15;
	stateSound[3] = XW_Swing1Sound;
	stateSoundDelay[3] = 0.1;
	stateTimeout[3] = 0.4;
	stateTransitionOnTimeout[3] = "swingAltCheck2";

	stateName[5] = "swingAltCheck2";
	stateTimeout[5] = 0.4;
	stateTransitionOnTriggerPush[5, 0] = "Upper";
	stateTransitionOnTimeout[5] = "idle";

	stateName[6] = "Upper";
	stateThread[6] = "upper";
	stateScript[6] = "onUpper";
	stateSound[6] = XW_Swing2LowSound;
	stateSoundDelay[6] = 0.06;
	stateTimeout[6] = 0.6;
	stateTransitionOnTimeout[6] = "idle";

	stateName[18] = "mainAltCheck";
	stateTimeout[18] = 0.2;
	stateTransitionOnTriggerUp[18, 0] = "swingL";
	stateTransitionOnTimeout[18] = "SpearCheck";

// * Spear
	stateName[7] = "SpearCheck";
	stateScript[7] = "onSpearCheck";
	stateTimeout[7] = 0.1;
	stateTransitionOnTimeout[7] = "idle";
	stateTransitionOnEvent[7, 0] = "Spear";

	stateName[8] = "Spear";
	stateThread[8] = "spear";
	stateScript[8] = "onSpear";
	stateSound[8] = XW_Swing2Sound;
	stateSoundDelay[8] = 0.1;
	stateTimeout[8] = 0.8;
	stateTransitionOnTimeout[8] = "idle";

// * Wave
	stateName[9] = "WaveCheck";
	stateScript[9] = "onWaveCheck";
	stateTimeout[9] = 0.1;
	stateTransitionOnTimeout[9] = "idle";
	stateTransitionOnEvent[9, 0] = "WaveCharge";

	stateName[10] = "WaveCharge";
	stateThread[10] = "wavecharge";
	stateScript[10] = "onWaveCharge";
	stateTimeout[10] = 0.3;
	stateTransitionOnTimeout[10] = "Wave";

	stateName[11] = "Wave";
	stateThread[11] = "wave";
	stateScript[11] = "onWave";
	stateSound[11] = XW_Swing4Sound;
	stateSoundDelay[11] = 0.06;
	stateTimeout[11] = 0.4;
	stateTransitionOnTimeout[11] = "idle";
	stateTransitionOnEvent[11, 0] = "idle";

// * Spike
	stateName[12] = "SpikeCheck";
	stateScript[12] = "onSpikeCheck";
	stateTimeout[12] = 0.1;
	stateTransitionOnTimeout[12] = "idle";
	stateTransitionOnEvent[12, 0] = "Spike";

	stateName[13] = "Spike";
	stateThread[13] = "spike";
	stateScript[13] = "onSpike";
	stateSound[13] = XW_Thrust1Sound;
	stateSoundDelay[13] = 0.06;
	stateTimeout[13] = 0.8;
	stateTransitionOnTimeout[13] = "idle";

// * Block
	stateName[20] = "BlockCheck";
	stateScript[20] = "onBlockCheck";
	stateTimeout[20] = 0.1;
	stateTransitionOnTimeout[20] = "idle";
	stateTransitionOnEvent[20, 0] = "BlockStart";

	stateName[15] = "BlockStart";
	stateThread[15] = "blockStart";
	stateScript[15] = "onBlockStart";
	stateTimeout[15] = 0.3;
	stateTransitionOnTimeout[15] = "Block";
	
	stateName[16] = "Block";
	stateTransitionOnTriggerUp[16, 4] = "BlockEnd";

	stateName[17] = "BlockEnd";
	stateThread[17] = "blockEnd";
	stateScript[17] = "onBlockEnd";
	stateTimeout[17] = 0.3;
	stateTransitionOnTimeout[17] = "idle";

	stateName[19] = "Stunned";
	stateThread[19] = "parry";
	// stateScript[19] = "onStunned";
	stateTimeout[19] = 0.75;
	stateTransitionOnTimeout[19] = "idle";
};

XW_SwordImage.StatObj = XW_SwordStatObj;
XW_SwordStatObj.SourceImg = XW_SwordImage;

// * Left Slash
ST_registerSlash("XWSwordLeft", "XW_SimpleSlashTrail Slash 350", "-0.5 -0.5 0", "0 1 0 -70", "4 8 8", "", "XW_GenericProjectile Cylinder -160 -20");
XW_SetSlashData("XWSwordLeft", XW_SwordStatObj, XW_SwordStatObj.SwingDamage, "onSwingHit", "");

// * Right Slash
ST_registerSlash("XWSwordRight", "XW_SimpleSlashTrail Slash 350", "-0.5 -0.5 0", "0 1 0 90", "4 8 8", "", "XW_GenericProjectile Cylinder -160 -20");
XW_SetSlashData("XWSwordRight", XW_SwordStatObj, XW_SwordStatObj.SwingDamage, "onSwingHit", "");

// * Upper Slash
ST_registerSlash("XWSwordUpper", "XW_SimpleSlashTrail SlashFast 250", "0 -0.5 0", "0 1 0 180", "6 8 8", "", "XW_GenericProjectile Cylinder -135 -45 1");
XW_SetSlashData("XWSwordUpper", XW_SwordStatObj, XW_SwordStatObj.UpperDamage, "onUpperHit", "");

// * Spear Slash
ST_registerSlash("XWSwordSpear", "XW_BlueSlashTrail SlashFastest 200", "-0.5 -0.5 0", "0 1 0 0", "3 10 3", "", "XW_GenericProjectile Cylinder -135 -45 1");
XW_SetSlashData("XWSwordSpear", XW_SwordStatObj, XW_SwordStatObj.SpearDamage, "onSpearHit", "");

// * Wave Slash
ST_registerSlash("XWSwordWave", "XW_BlueSlashTrail SlashFast 250", "-0.5 -0.5 -0.5", "0 1 0 0", "9 9 9", "", "XW_GenericProjectile Cylinder -180 0 2");
XW_SetSlashData("XWSwordWave", XW_SwordStatObj, XW_SwordStatObj.WaveDamage, "onWaveHit", "");

ST_registerSlash("XWSwordWave1", "XW_BlueSlashTrail SlashFast 250", "-0.5 1.5 -0.5", "0 1 0 0", "9 9 9", "", "XW_GenericProjectile Cylinder -180 0 2");
XW_SetSlashData("XWSwordWave1", XW_SwordStatObj, XW_SwordStatObj.WaveDamage, "onWaveHit", "");

ST_registerSlash("XWSwordWave2", "XW_BlueSlashTrail SlashFast 250", "-0.5 3.5 -0.5", "0 1 0 0", "9 9 9", "", "XW_GenericProjectile Cylinder -180 0 2");
XW_SetSlashData("XWSwordWave2", XW_SwordStatObj, XW_SwordStatObj.WaveDamage, "onWaveHit", "");

ST_registerSlash("XWSwordWave3", "XW_BlueSlashTrail SlashFast 250", "-0.5 5.5 -0.5", "0 1 0 0", "9 9 9", "", "XW_GenericProjectile Cylinder -180 0 2");
XW_SetSlashData("XWSwordWave3", XW_SwordStatObj, XW_SwordStatObj.WaveDamage, "onWaveHit", "");

// * Spike Slash
ST_registerSlash("XWSwordSpike", "XW_BlueSlashTrail SlashFast 250", "-0.5 -0.5 0", "0 1 0 0", "8 8 8", "", "XW_GenericProjectile Cylinder -35 35");
XW_SetSlashData("XWSwordSpike", XW_SwordStatObj, XW_SwordStatObj.SpikeDamage, "onSpikeHit", "");

ST_registerSlash("XWSwordSpikeAlt", "XW_EmptySlash root 200", "-0.5 -0.5 0", "0 0 1 90", "14 14 14", "", "XW_GenericProjectile Sphere 7 -180 0");
XW_SetSlashData("XWSwordSpikeAlt", XW_SwordStatObj, XW_SwordStatObj.SpikeShockDamage, "onSpikeAltHit", "");

function XW_SwordStatObj::onIdle(%stat, %pl, %bot)
{
	// %pl.playThread(0, plant);
	// serverPlay3D(Block_PlantBrick_Sound, %pl.getHackPosition());
}

function XW_SwordStatObj::onSwingL(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.ST_CreateSlash("XWSwordLeft", 0);
}

function XW_SwordStatObj::onSwingR(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.ST_CreateSlash("XWSwordRight", 0);
}

function XW_SwordStatObj::onSwingHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.addVelocity(vectorAdd(vectorScale(%dir, %stat.SwingDirectImpulse), "0 0 " @ %stat.SwingVerticalImpulse));

	serverPlay3D(XW_HitSlash1Sound, %proj.getPosition());
}

function XW_SwordStatObj::onUpper(%stat, %pl, %bot)
{
	%pl.playThread(0, jump);
	%pl.ST_CreateSlash("XWSwordUpper", 0);
}

function XW_SwordStatObj::onUpperHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.UpperDirectImpulse), "0 0 " @ %stat.UpperVerticalImpulse));

	serverPlay3D(XW_HitStab1Sound, %proj.getPosition());
	serverPlay3D(XW_HitHeavy1Sound, %proj.getPosition());
}

function XW_SwordStatObj::onSpearCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Spear"))
		%stat.eventTrigger(%pl, 0);
}

function XW_SwordStatObj::onSpear(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.playThread(2, plant);
	%pl.ST_CreateSlash("XWSwordSpear", 0);
	%pl.triggerCooldown("Spear", %stat.SpearCooldown);
}

function XW_SwordStatObj::onSpearHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%vel = %col.getVelocity();
	%dot = vectorDot(vectorScale(vectorNormalize(%vel), -1), %pl.getLookVector());

	if(vectorLen(%vel) > 10 && %dot > 0.5)
	{
		%proj.directDamage = %stat.SpearCritDamage;
		%col.XWCritFx(%pl, %proj);
	}
	else
		%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.addVelocity(vectorAdd(vectorScale(%dir, %stat.SpearDirectImpulse), "0 0 " @ %stat.SpearVerticalImpulse));

	serverPlay3D(XW_HitStab1Sound, %proj.getPosition());
}

function XW_SwordStatObj::onWaveCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Wave"))
		%stat.eventTrigger(%pl, 0);
}

function XW_SwordStatObj::onWaveCharge(%stat, %pl, %bot)
{
	%pl.playThread(0, jump);
	%pl.playThread(2, jump);
	%pl.setVelocity(vectorAdd(vectorScale(%pl.getLookVector(), %stat.WaveSpeed), "0 0 10"));
	%pl.triggerCooldown("Wave", %stat.WaveCooldown);
	%pl.blockImageDismount(300);
}

function XW_SwordStatObj::onWave(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.playThread(2, plant);
	%pl.ST_CreateSlash("XWSwordWave", 0);
	%pl.schedule(200, ST_CreateSlash, "XWSwordWave1", 0);
	%pl.schedule(400, ST_CreateSlash, "XWSwordWave2", 0);
	%pl.schedule(600, ST_CreateSlash, "XWSwordWave3", 0);
}

function XW_SwordStatObj::onWaveHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, ""))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.WaveDirectImpulse), "0 0 " @ %stat.WaveVerticalImpulse));

	serverPlay3D(XW_HitSlash1Sound, %proj.getPosition());
}

function XW_SwordStatObj::onSpikeCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Spike"))
		%stat.eventTrigger(%pl, 0);
}

function XW_SwordStatObj::onSpike(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.playThread(2, plant);
	%pl.ST_CreateSlash("XWSwordSpike", 0);
	%pl.ST_CreateSlash("XWSwordSpikeAlt", 0);
	%pl.setVelocity(vectorScale(%pl.getVelocity(), 0.25));
	%pl.triggerCooldown("Spike", %stat.SpikeCooldown);

	serverPlay3D(XW_Special2Sound, %pl.getHackPosition());
}

function XW_SwordStatObj::onSpikeHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWCritFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.SpikeDirectImpulse), "0 0 " @ %stat.SpikeVerticalImpulse));
	
	serverPlay3D(XW_HitStab1Sound, %proj.getPosition());
	serverPlay3D(XW_HitHeavy1Sound, %proj.getPosition());
}

function XW_SwordStatObj::onSpikeAltHit(%stat, %pl, %col, %proj)
{
	%dir = vectorNormalize(vectorSub(%col.getHackPosition(), %pl.getHackPosition()));
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.SpikeShockImpulse), "0 0 " @ %stat.SpikeShockVerticalImpulse));

	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);
}

function XW_SwordStatObj::onBlockCheck(%stat, %pl, %bot)
{
	if(%pl.XWCanBlock())
		%stat.eventTrigger(%pl, 0);
}

function XW_SwordStatObj::onBlockStart(%stat, %pl, %bot)
{
	%pl.XWBlockStart("Stunned", "BlockEnd");
	%pl.playThread(0, plant);
	serverPlay3D(Block_PlantBrick_Sound, %pl.getHackPosition());
}

function XW_SwordStatObj::onBlockEnd(%stat, %pl, %bot)
{
	%pl.XWBlockEnd();
}
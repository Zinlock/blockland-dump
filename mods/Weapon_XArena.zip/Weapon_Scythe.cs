datablock PlayerData(XW_ScytheAI : EmptyAI) { shapeFile = "./dts/scythe_image.dts"; isXWeaponBot = true; };

datablock ItemData(XW_ScytheItem)
{
	category = "Weapon";
	className = "Weapon";

	shapeFile = "./dts/scythe_item.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	uiName = "XA: Scythe";
	iconName = "";
	doColorShift = true;
	colorShiftColor = "0.9 0.0 0.3 1";

	image = XW_ScytheImage;
	canDrop = true;
};

datablock ShapeBaseImageData(XW_ScytheImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = true;

	mountPoint = 0;
	eyeOffset = 0;

	className = "WeaponImage";

	XWeaponData = XW_ScytheAI;

	hideNodes = "rHand rHook";
	twoHanded = false;

	item = XW_ScytheItem;

	isXWeaponImage = true;

	armReady = true;

	colorShiftNodes = "scythe";
	colorShiftColor = XW_ScytheItem.colorShiftColor;

	stateName[0] = "Activate";
	stateTimeoutValue[0] = 0.4;
	stateTransitionOnTimeout[0] = "Ready";

	stateName[1] = "Ready";
	stateScript[1] = "onReady";
};

function XW_ScytheImage::onMount(%db, %pl, %slot)
{
	%pl.mountXWeaponBot(%db);
	Parent::onMount(%db, %pl, %slot);
	%pl.XWLoop();
}

function XW_ScytheImage::onUnMount(%db, %pl, %slot)
{
	Parent::onUnMount(%db, %pl, %slot);
	%pl.unMountXWeaponBot();
	%pl.preMountXWeaponBot(%db);
	%pl.XWBlockEnd();
}

if(isObject(XW_ScytheStatObj)) XW_ScytheStatObj.delete();

new ScriptObject(XW_ScytheStatObj)
{
	class = "XW_StatObj";

// * Bots

	NumBotAttacks = 12;

	// [trigger idx] [end time] [delay]
	// triggers 5 and 6 are use and light which can not be held and don't need a specific end time set
	// delay should always be >= end time
	// weight controls how often an attack should be used
	// attack list indicates which cooldowns need to be ready for the attack to be considered
	BotAttack[0] = "0 50 600" TAB "0 50 600";
	BotAttackMinRange[0] = 0;
	BotAttackMaxRange[0] = 6;
	BotAttackWeight[0] = 10;
	BotAttackCooldown[0] = 0;
	BotAttackList[0] = "";

	BotAttack[1] = "0 50 600" TAB "0 50 600" TAB "0 50 900" TAB "0 500 500";
	BotAttackMinRange[1] = 0;
	BotAttackMaxRange[1] = 6;
	BotAttackWeight[1] = 7;
	BotAttackCooldown[1] = 2;
	BotAttackList[1] = "";

	BotAttack[2] = "0 500 500";
	BotAttackMinRange[2] = 0;
	BotAttackMaxRange[2] = 5;
	BotAttackWeight[2] = 6;
	BotAttackCooldown[2] = 2;
	BotAttackList[2] = "Spike";

	BotAttack[3] = "6 0 1300" TAB "5 0 700" TAB "0 600 500";
	BotAttackMinRange[3] = 4;
	BotAttackMaxRange[3] = 18;
	BotAttackWeight[3] = 4;
	BotAttackCooldown[3] = 12;
	BotAttackList[3] = "Leap Upper";

	BotAttack[4] = "5 0 700" TAB "6 0 1300";
	BotAttackMinRange[4] = 1;
	BotAttackMaxRange[4] = 18;
	BotAttackWeight[4] = 4;
	BotAttackCooldown[4] = 12;
	BotAttackList[4] = "Upper Leap";

	BotAttack[5] = "6 0 1300" TAB "0 600 500";
	BotAttackMinRange[5] = 4;
	BotAttackMaxRange[5] = 18;
	BotAttackWeight[5] = 6;
	BotAttackCooldown[5] = 10;
	BotAttackList[5] = "Leap";

	BotAttack[6] = "5 0 1000" TAB "0 600 500";
	BotAttackMinRange[6] = 1;
	BotAttackMaxRange[6] = 4;
	BotAttackWeight[6] = 3;
	BotAttackCooldown[6] = 6;
	BotAttackList[6] = "Upper";

	BotAttack[7] = "4 1000 1000"; // block
	BotAttackMinRange[7] = 0;
	BotAttackMaxRange[7] = 8;
	BotAttackWeight[7] = 4;
	BotAttackCooldown[7] = 2;
	BotAttackList[7] = "";

	BotAttack[8] = "4 300 900" TAB "0 50 800" TAB "4 1000 1000"; // block atk block
	BotAttackMinRange[8] = 0;
	BotAttackMaxRange[8] = 8;
	BotAttackWeight[8] = 2;
	BotAttackCooldown[8] = 2;
	BotAttackList[8] = "";

	BotAttack[9] = "4 300 900" TAB "0 50 800"; // block atk
	BotAttackMinRange[9] = 0;
	BotAttackMaxRange[9] = 8;
	BotAttackWeight[9] = 2;
	BotAttackCooldown[9] = 2;
	BotAttackList[9] = "";

	BotAttack[10] = "0 50 900" TAB "4 1000 1000"; // atk block
	BotAttackMinRange[10] = 0;
	BotAttackMaxRange[10] = 8;
	BotAttackWeight[10] = 2;
	BotAttackCooldown[10] = 2;
	BotAttackList[10] = "";

	BotAttack[11] = "0 50 800" TAB "4 600 1200" TAB "0 50 600" TAB "0 50 800"; // atk block atk
	BotAttackMinRange[11] = 0;
	BotAttackMaxRange[11] = 8;
	BotAttackWeight[11] = 2;
	BotAttackCooldown[11] = 2;
	BotAttackList[11] = "";

// * Stats
	SwingDamage = 16;
	SwingDirectImpulse = 5;
	SwingVerticalImpulse = 5;

	BumpDamage = 10;
	BumpDirectImpulse = 12;
	BumpVerticalImpulse = 10;

	SpikeDamage = 21;
	SpikeCritDamage = 35;
	SpikeDirectImpulse = 10;
	SpikeVerticalImpulse = -15;
	SpikeCooldown = 1.5;

	UpperDamage = 35;
	UpperDirectImpulse = 2;
	UpperVerticalImpulse = 25;
	UpperCooldown = 6;

	LeapDamage = 40;
	LeapCritDamage = 60;
	LeapCritDistance = 0.75;
	LeapSpeed = 35;
	LeapDirectImpulse = 15;
	LeapVerticalImpulse = 15;
	LeapCooldown = 7;

	// first word is attack name, rest is label. max 4
	AttackList = "Spike Hold LMB" TAB "Block Hold RMB" TAB "Upper E" TAB "Leap R";

// * Idle
	stateName[0] = "draw";
	stateThread[0] = "equip";
	stateTimeout[0] = 0.5;
	stateTransitionOnTimeout[0] = "idle";

	stateName[1] = "idle";
	stateThread[1] = "";
	stateScript[1] = "onIdle";
	stateTransitionOnTriggerPush[1, 0] = "mainAltCheck";
	stateTransitionOnTriggerDown[1, 4] = "BlockCheck";
	stateTransitionOnTriggerPush[1, 5] = "UpperCheck";
	stateTransitionOnTriggerPush[1, 6] = "LeapCheck";

// * Swings
	stateName[2] = "swingL";
	stateThread[2] = "SwingL";
	stateScript[2] = "onSwingL";
	stateScriptDelay[2] = 0.1;
	stateSound[2] = XW_Swing1Sound;
	stateSoundDelay[2] = 0.06;
	stateTimeout[2] = 0.3;
	stateTransitionOnTimeout[2] = "swingAltCheck";

	stateName[4] = "swingAltCheck";
	stateTimeout[4] = 0.4;
	stateTransitionOnTriggerPush[4, 0] = "swingR";
	stateTransitionOnTimeout[4] = "idle";

	stateName[3] = "swingR";
	stateThread[3] = "SwingR";
	stateScript[3] = "onSwingR";
	stateScriptDelay[3] = 0.1;
	stateSound[3] = XW_Swing1LowSound;
	stateSoundDelay[3] = 0.06;
	stateTimeout[3] = 0.3;
	stateTransitionOnTimeout[3] = "swingAltCheck2";

	stateName[5] = "swingAltCheck2";
	stateTimeout[5] = 0.4;
	stateTransitionOnTriggerPush[5, 0] = "bump";
	stateTransitionOnTimeout[5] = "idle";

	stateName[6] = "bump";
	stateThread[6] = "bump";
	stateScript[6] = "onBump";
	stateSound[6] = XW_Swing2LowSound;
	stateSoundDelay[6] = 0.06;
	stateTimeout[6] = 0.4;
	stateTransitionOnTimeout[6] = "idle";

	stateName[18] = "mainAltCheck";
	stateTimeout[18] = 0.2;
	stateTransitionOnTriggerUp[18, 0] = "swingL";
	stateTransitionOnTimeout[18] = "SpikeCheck";

// * Spike
	stateName[7] = "SpikeCheck";
	stateScript[7] = "onSpikeCheck";
	stateTimeout[7] = 0.1;
	stateTransitionOnTimeout[7] = "idle";
	stateTransitionOnEvent[7, 0] = "Spike";

	stateName[8] = "Spike";
	stateThread[8] = "swingD";
	stateScript[8] = "onSpike";
	stateSound[8] = XW_Swing2HighSound;
	stateSoundDelay[8] = 0.1;
	stateTimeout[8] = 0.6;
	stateTransitionOnTimeout[8] = "idle";
	stateTransitionOnEvent[8, 0] = "idle";

// * Upper
	stateName[9] = "UpperCheck";
	stateScript[9] = "onUpperCheck";
	stateTimeout[9] = 0.1;
	stateTransitionOnTimeout[9] = "idle";
	stateTransitionOnEvent[9, 0] = "Upper";

	stateName[10] = "Upper";
	stateThread[10] = "upper";
	stateScript[10] = "onUpper";
	stateSound[10] = XW_Special1Sound;
	stateSoundDelay[10] = 0.06;
	stateTimeout[10] = 0.6;
	stateTransitionOnTimeout[10] = "idle";

// * Leap
	stateName[11] = "LeapCheck";
	stateScript[11] = "onLeapCheck";
	stateTimeout[11] = 0.1;
	stateTransitionOnTimeout[11] = "idle";
	stateTransitionOnEvent[11, 0] = "LeapCharge";
	
	stateName[12] = "LeapCharge";
	stateThread[12] = "charge";
	stateScript[12] = "onLeapCharge";
	stateSound[12] = XW_Special1Sound;
	stateTimeout[12] = 0.3;
	stateTransitionOnTimeout[12] = "Leap";

	stateName[13] = "Leap";
	stateThread[13] = "leap";
	stateScript[13] = "onLeap";
	stateSound[13] = XW_Swing2HighSound;
	stateSoundSlot[13] = 1;
	stateSoundDelay[13] = 0.06;
	stateTimeout[13] = 0.8;
	stateTransitionOnTimeout[13] = "idle";

// * Block
	stateName[20] = "BlockCheck";
	stateScript[20] = "onBlockCheck";
	stateTimeout[20] = 0.1;
	stateTransitionOnTimeout[20] = "idle";
	stateTransitionOnEvent[20, 0] = "BlockStart";

	stateName[15] = "BlockStart";
	stateThread[15] = "blockStart";
	stateScript[15] = "onBlockStart";
	stateTimeout[15] = 0.3;
	stateTransitionOnTimeout[15] = "Block";
	
	stateName[16] = "Block";
	stateTransitionOnTriggerUp[16, 4] = "BlockEnd";

	stateName[17] = "BlockEnd";
	stateThread[17] = "blockEnd";
	stateScript[17] = "onBlockEnd";
	stateTimeout[17] = 0.3;
	stateTransitionOnTimeout[17] = "idle";

	stateName[19] = "Stunned";
	stateThread[19] = "parry";
	// stateScript[19] = "onStunned";
	stateTimeout[19] = 0.75;
	stateTransitionOnTimeout[19] = "idle";
};

XW_ScytheImage.StatObj = XW_ScytheStatObj;
XW_ScytheStatObj.SourceImg = XW_ScytheImage;

// * Left Slash
ST_registerSlash("XWScytheLeft", "XW_SimpleSlashTrail SlashFast 250", "-0.5 -0.5 0", "0 1 0 -90", "4 8 8", "", "XW_GenericProjectile Cylinder -160 -20");
XW_SetSlashData("XWScytheLeft", XW_ScytheStatObj, XW_ScytheStatObj.SwingDamage, "onSwingHit", "");

// * Right Slash
ST_registerSlash("XWScytheRight", "XW_SimpleSlashTrail SlashFast 250", "-0.5 -0.5 0", "0 1 0 90", "4 8 8", "", "XW_GenericProjectile Cylinder -160 -20");
XW_SetSlashData("XWScytheRight", XW_ScytheStatObj, XW_ScytheStatObj.SwingDamage, "onSwingHit", "");

// * Bump Slash
ST_registerSlash("XWScytheBump", "XW_SimpleSlashTrail SlashFastest 200", "-0.5 -0.5 0", "0 1 0 0", "6 9 2", "", "XW_GenericProjectile Cylinder -135 -45 1");
XW_SetSlashData("XWScytheBump", XW_ScytheStatObj, XW_ScytheStatObj.BumpDamage, "onBumpHit", "");

// * Spike Slash
ST_registerSlash("XWScytheSpike", "XW_RedSlashTrail SlashFast 250", "0 -0.5 0", "0 1 0 0", "8 8 8", "", "XW_GenericProjectile Cylinder -160 -20 1");
XW_SetSlashData("XWScytheSpike", XW_ScytheStatObj, XW_ScytheStatObj.SpikeDamage, "onSpikeHit", "");

// * Upper Slash
ST_registerSlash("XWScytheUpper", "XW_RedSlashTrail SlashFast 250", "-0.5 -0.5 -0.5", "0 1 0 180", "9 9 9", "", "XW_GenericProjectile Cylinder -200 -20 2");
XW_SetSlashData("XWScytheUpper", XW_ScytheStatObj, XW_ScytheStatObj.UpperDamage, "onUpperHit", "");

// * Leap Slash
ST_registerSlash("XWScytheLeap", "XW_RedSlashTrail SlashFast 250", "-0.5 -0.5 0", "0 1 0 -90", "9 9 9", "", "XW_GenericProjectile Cylinder -180 0 1.5");
XW_SetSlashData("XWScytheLeap", XW_ScytheStatObj, XW_ScytheStatObj.LeapDamage, "onLeapHit", "");

function XW_ScytheStatObj::onIdle(%stat, %pl, %bot)
{

}

function XW_ScytheStatObj::onSwingL(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.ST_CreateSlash("XWScytheLeft", 0);
}

function XW_ScytheStatObj::onSwingR(%stat, %pl, %bot)
{
	%pl.playThread(0, plant);
	%pl.ST_CreateSlash("XWScytheRight", 0);
}

function XW_ScytheStatObj::onSwingHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.addVelocity(vectorAdd(vectorScale(%dir, %stat.SwingDirectImpulse), "0 0 " @ %stat.SwingVerticalImpulse));

	serverPlay3D(XW_HitSlash1Sound, %proj.getPosition());
}

function XW_ScytheStatObj::onBump(%stat, %pl, %bot)
{
	%pl.ST_CreateSlash("XWScytheBump", 0);
}

function XW_ScytheStatObj::onBumpHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.BumpDirectImpulse), "0 0 " @ %stat.BumpVerticalImpulse));

	serverPlay3D(XW_HitSlash1Sound, %proj.getPosition());
}

function XW_ScytheStatObj::onSpikeCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Spike"))
		%stat.eventTrigger(%pl, 0);
}

function XW_ScytheStatObj::onSpike(%stat, %pl, %bot)
{
	%pl.playThread(0, jump);
	%pl.schedule(100, ST_CreateSlash, "XWScytheSpike", 0);
	%pl.schedule(200, playThread, 0, plant);
	%pl.schedule(200, playThread, 2, plant);
	%pl.triggerCooldown("Spike", %stat.SpikeCooldown);
}

function XW_ScytheStatObj::onSpikeHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	if(getWord(%pl.getVelocity(), 2) < -6)
	{
		%proj.directDamage = %stat.DownSwingCritDamage;
		%col.XWCritFx(%pl, %proj);
	}
	else
		%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.addVelocity(vectorAdd(vectorScale(%dir, %stat.DownSwingDirectImpulse), "0 0 " @ %stat.DownSwingVerticalImpulse));

	serverPlay3D(XW_HitStab1Sound, %proj.getPosition());
}

function XW_ScytheStatObj::onUpperCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Upper"))
		%stat.eventTrigger(%pl, 0);
}

function XW_ScytheStatObj::onUpper(%stat, %pl, %bot)
{
	%pl.playThread(0, jump);
	%pl.playThread(2, jump);
	%pl.ST_CreateSlash("XWScytheUpper", 0);
	%pl.setVelocity("0 0 " @ %stat.UpperVerticalImpulse);
	%pl.triggerCooldown("Upper", %stat.UpperCooldown);
}

function XW_ScytheStatObj::onUpperHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.UpperDirectImpulse), "0 0 " @ %stat.UpperVerticalImpulse));

	serverPlay3D(XW_HitHeavy1Sound, %proj.getPosition());
}

function XW_ScytheStatObj::onLeapCheck(%stat, %pl, %bot)
{
	if(%pl.checkCooldown("Leap"))
		%stat.eventTrigger(%pl, 0);
}

function XW_ScytheStatObj::onLeapCharge(%stat, %pl, %bot)
{
	%pl.fallImmune = true;
	%pl.playThread(0, jump);
	%pl.playThread(2, jump);
	%pl.setVelocity(vectorAdd(vectorScale(%pl.getLookVector(), %stat.LeapSpeed), "0 0 10"));
	%pl.triggerCooldown("Leap", %stat.LeapCooldown);
	%pl.blockImageDismount(300);
}

function XW_ScytheStatObj::onLeap(%stat, %pl, %bot)
{
	%pl.fallImmune = false;
	%pl.playThread(0, plant);
	%pl.playThread(2, plant);
	%pl.ST_CreateSlash("XWScytheLeap", 0);
	%pl.setVelocity(vectorScale(%pl.getVelocity(), 0.25));
}

function XW_ScytheStatObj::onLeapHit(%stat, %pl, %col, %proj)
{
	if(%pl.XWBlockCheck(%col, %stat, %proj, "Stunned"))
		return;

	if(%proj.ST_SlashDistance >= %stat.LeapCritDistance)
	{
		%proj.directDamage = %stat.LeapCritDamage;
		%col.XWCritFx(%pl, %proj);
	}
	else
		%col.XWHitFx(%pl, %proj);

	%dir = %pl.getLookVector();
	%col.setVelocity(vectorAdd(vectorScale(%dir, %stat.LeapDirectImpulse), "0 0 " @ %stat.LeapVerticalImpulse));

	serverPlay3D(XW_HitSlash1Sound, %proj.getPosition());
	serverPlay3D(XW_HitHeavy1Sound, %proj.getPosition());
}

function XW_ScytheStatObj::onBlockCheck(%stat, %pl, %bot)
{
	if(%pl.XWCanBlock())
		%stat.eventTrigger(%pl, 0);
}

function XW_ScytheStatObj::onBlockStart(%stat, %pl, %bot)
{
	%pl.XWBlockStart("Stunned", "BlockEnd");
	%pl.playThread(0, plant);
	serverPlay3D(Block_PlantBrick_Sound, %pl.getHackPosition());
}

function XW_ScytheStatObj::onBlockEnd(%stat, %pl, %bot)
{
	%pl.XWBlockEnd();
}
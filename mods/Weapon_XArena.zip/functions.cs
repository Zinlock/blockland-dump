// * Cooldowns

function Player::triggerCooldown(%pl, %name, %time)
{
	%pl.cooldownStart[%name, %pl.XWeaponBot.sourceImage] = getSimTime();
	%pl.cooldown[%name, %pl.XWeaponBot.sourceImage] = getSimTime() + (%time * 1000);
}

function Player::checkCooldown(%pl, %name, %silent)
{
	if(getSimTime() < %pl.cooldown[%name, %pl.XWeaponBot.sourceImage])
	{
		if(!%silent && isObject(%cl = %pl.Client) && %cl.IsA("GameConnection"))
			%cl.centerPrint("<font:arial bold:18><color:FF7744>" @ %name @ " is on cooldown!<br><font:arial:16>" @ mFloatLength((%pl.cooldown[%name, %pl.XWeaponBot.sourceImage] - getSimTime()) / 1000, 1) @ "s left", 1);

		return false;
	}
	else return true;
}

// * Impacts

function Player::XWCritFx(%pl, %src, %proj)
{
	if(isObject(%cl = %pl.Client))
		%cl.play2D(XW_CriticalTakenSound);

	if(isObject(%src) && (isObject(%cc = %src.Client) || (%cc = %src).IsA("GameConnection")))
		%cc.play2D(XW_CriticalHitSound);

	serverPlay3D(XW_CriticalHitSound, %pl.getHackPosition());

	%p = new Projectile(xwfx)
	{
		dataBlock = XW_CriticalHitFxProjectile;
		initialPosition = %proj.getPosition();
	};

	MissionCleanup.add(%p);
	%p.explode();
}

function Player::XWHitFx(%pl, %src, %proj)
{
	%p = new Projectile(xwfx)
	{
		dataBlock = XW_GenericHitFxProjectile;
		initialPosition = %proj.getPosition();
	};

	MissionCleanup.add(%p);
	%p.explode();
}

// * Blocking

$xwPerfectBlockTime = 0.3;        // parry window length (secs)
$xwMaxBlockEnergy = 100;          // max block energy
$xwBlockEnergyRegen = 8;          // energy per second
$xwBlockEnergyStartUsage = 20;    // energy used when first blocking
$xwBlockEnergyUsage = 10;         // energy used per second when holding block
$xwHalfBlockEnergyUsage = 20;     // energy used when hit after missing the parry window
$xwHalfBlockProtection = 0.5;     // damage reduction (%) from blocking
$xwPerfectBlockEnergyUsage = -25; // energy used when hit during the parry window (negative regens energy)
$xwPerfectBlockProtection = 1.0;  // damage reduction (%) from parrying

function Player::XWCanBlock(%pl, %silent)
{
	if(%pl.xwBlocking)
		return %pl.xwBlockEnergy > 0 || (getSimTime() - %pl.xwBlockTime < $xwPerfectBlockTime * 1000);
	else
	{
		%canBlock = %pl.xwBlockEnergy > $xwBlockEnergyStartUsage;
		if(!%silent && !%canBlock && isObject(%cl = %pl.Client) && %cl.IsA("GameConnection"))
			%cl.centerPrint("<font:arial bold:18><color:FF7744>Not enough energy to block!", 1);

		return %canBlock;
	}
}

function Player::XWBlockStart(%pl, %breakState, %emptyState)
{
	if(%pl.xwBlocking)
		return;

	%pl.xwBlocking = true;
	%pl.xwBlockTime = getSimTime();
	%pl.xwBlockBreakState = %breakState;
	%pl.xwBlockEmptyState = %emptyState;

	%pl.xwBlockEnergy -= $xwBlockEnergyStartUsage;

	if(isObject(%cl = %pl.Client) && %cl.IsA("GameConnection"))
	{
		commandToClient(%cl, 'SetVignette', false, "0 0.5 1.0 0.5");
		%cl.xwbs = schedule($xwPerfectBlockTime * 1000, %cl, commandToClient, %cl, 'SetVignette', false, "0 0.5 0.7 0.3");
	}
}

function Player::XWBlockEnd(%pl)
{
	if(!%pl.xwBlocking)
		return;

	%pl.xwBlocking = false;
	%pl.xwBlockBreakState = "";
	%pl.xwBlockEmptyState = "";

	if(isObject(%cl = %pl.Client) && %cl.IsA("GameConnection"))
	{
		cancel(%cl.xwbs);
		commandToClient(%cl, 'SetVignette', $EnvGuiServer::VignetteMultiply, $EnvGuiServer::VignetteColor);
	}
}

function Player::XWIsPerfectBlocking(%pl)
{
	return %pl.xwBlocking && (getSimTime() - %pl.xwBlockTime < $xwPerfectBlockTime * 1000);
}

function Player::XWPerfectBlockFx(%pl, %from)
{
	serverPlay3D(XW_BlockFullSound, %pl.getHackPosition());
	%pl.playThread(2, plant);
	%from.playThread(2, jump);

	%p = new Projectile(xwfx)
	{
		dataBlock = XW_PerfectBlockFxProjectile;
		initialPosition = vectorAdd(%pl.getEyePoint(), vectorScale(%pl.getLookVector(), 1.5));
	};

	MissionCleanup.add(%p);
	%p.explode();
}

function Player::XWBlockFx(%pl, %from)
{
	serverPlay3D(XW_BlockHalfSound, %pl.getHackPosition());
	%pl.playThread(2, plant);
	%from.playThread(2, plant);

	%p = new Projectile(xwfx)
	{
		dataBlock = XW_HalfBlockFxProjectile;
		initialPosition = vectorAdd(%pl.getEyePoint(), vectorScale(%pl.getLookVector(), 1.5));
	};

	MissionCleanup.add(%p);
	%p.explode();
}

function Player::XWBlockCheck(%pl, %col, %stat, %proj, %state)
{
	if(vectorDot(%col.getLookVector(), vectorNormalize(vectorSub(%pl.getPosition(), %col.getPosition()))) < 0)
		return false;

	if(%col.XWIsPerfectBlocking())
	{
		%proj.directDamage *= 1 - $xwPerfectBlockProtection;
		%col.XWPerfectBlockFx(%pl);

		%col.xwBlockEnergy -= $xwPerfectBlockEnergyUsage;
		%col.xwBlockHitTime = getSimTime();

		if(!%col.XWCanBlock(true) || %col.xwBlockEnergy < $xwBlockEnergyStartUsage)
			%col.XWBlockBreak();

		if(%state !$= "")
			%stat.setState(%pl, %state);

		return true;
	}

	if(%col.xwBlocking)
	{
		%proj.directDamage *= 1 - $xwHalfBlockProtection;
		%col.XWBlockFx(%pl);

		%col.xwBlockEnergy -= $xwHalfBlockEnergyUsage;
		%col.xwBlockHitTime = getSimTime();

		if(!%col.XWCanBlock(true) || %col.xwBlockEnergy < $xwBlockEnergyStartUsage)
			%col.XWBlockBreak();
	}

	return false;
}

function Player::XWBlockBreak(%pl)
{
	if(!%pl.xwBlocking || !isObject(%stat2 = %pl.XWeaponBot.sourceImage.StatObj) || %pl.xwBlockBreakState $= "")
		return;

	serverPlay3D(XW_BlockBreakSound, %pl.getHackPosition());
	%stat2.setState(%pl, %pl.xwBlockBreakState);
	%pl.XWBlockEnd();
}

function Player::XWBlockEmpty(%pl)
{
	if(!%pl.xwBlocking || !isObject(%stat2 = %pl.XWeaponBot.sourceImage.StatObj) || %pl.xwBlockEmptyState $= "")
		return;

	serverPlay3D(XW_StunSound, %pl.getHackPosition());
	%stat2.setState(%pl, %pl.xwBlockEmptyState);
	%pl.XWBlockEnd();
}

function Player::XWLoop(%pl)
{
	cancel(%pl.xwl);

	%img = %pl.getMountedImage(0);

	if(!isObject(%img) || !%img.isXWeaponImage)
		return;

	%stat = %img.StatObj;

	if(%pl.xwBlockEnergy $= "")
		%pl.xwBlockEnergy = $xwMaxBlockEnergy;

	%delta = ((getSimTime() - %pl.lastxwl) / 1000);

	if(%pl.xwBlocking)
		%pl.xwBlockEnergy -= %delta * $xwBlockEnergyUsage;
	else
		%pl.xwBlockEnergy += %delta * $xwBlockEnergyRegen;

	if(%pl.xwBlocking && !%pl.XWCanBlock(true))
		%pl.XWBlockEmpty();

	if(%pl.xwBlockEnergy > $xwMaxBlockEnergy)
		%pl.xwBlockEnergy = $xwMaxBlockEnergy;
	else if(%pl.xwBlockEnergy < 0)
		%pl.xwBlockEnergy = 0;

	if(isObject(%cl = %pl.Client) && %cl.IsA("GameConnection"))
	{
		%str = "<font:impact:24><color:FFFFFF>";

		%color = "4477FF";

		if(%pl.XWIsPerfectBlocking())
			%color = "44FFFF";
		else if(%pl.xwBlockEnergy < $xwBlockEnergyStartUsage)
			%color = "FF7744";

		%bar = "<spush><font:impact:30>" @ getBar(".", 50, %color, "777777", %pl.xwBlockEnergy / $xwMaxBlockEnergy) @ "<spop>";

		if(!%pl.xwBlocking)
		{
			%barShown = false;

			if(%pl.xwBlockEnergy >= $xwMaxBlockEnergy)
				%barShown = true;

			for(%i = 0; %i < 4; %i++)
			{
				%atk = trim(getField(%stat.AttackList, %i));

				if(%atk $= "")
					continue;

				%name = firstWord(%atk);
				%label = "<spush><font:impact:18><color:AAAAAA>" @ restWords(%atk) @ "<spop>";

				%cd = 0;
				%timer = "";
				%pre = "";
				%post = "";

				if(getSimTime() < %pl.cooldown[%name, %img])
				{
					%cd = mFloatLength((%pl.cooldown[%name, %img] - getSimTime()) / 1000, 1);
					%timer = %cd @ "s";
					%pre = "<spush><color:FF7744>";
					%post = "<spop>";
				}

				if(%i % 2 == 1)
					%st2 = "<just:right>" @ %pre @ %timer SPC %label SPC %name @ %post;
				else
					%st2 = "<just:left>" @ %pre @ %name SPC %label SPC %timer @ %post;

				if(%i == 1)
					%st2 = %st2 @ "<br>";
				else if(%i == 2 && !%barShown)
				{
					%barShown = true;
					%st2 = %st2 @ "<just:center>" @ %bar;
				}

				%str = %str @ %st2;
			}

			if(!%barShown)
				%str = %str @ "<br><just:center>" @ %bar;
		}
		else
			%str = %str @ "<just:center>BLOCKING<br>" @ %bar;

		%cl.longBottomPrint(%str, 1, 1);
	}

	%pl.lastxwl = getSimTime();
	%pl.xwl = %pl.schedule(100, XWLoop);
}
if(ForceRequiredAddOn("Support_XStateSys") == $Error::AddOn_NotFound)
{
	error("Weapon_XArena Error: Required Add-On Support_XStateSys not found");
	return;
}

if(ForceRequiredAddOn("Support_Slash_Trails") == $Error::AddOn_NotFound)
{
	error("Weapon_XArena Error: Required Add-On Support_Slash_Trails not found");
	return;
}

if(ForceRequiredAddOn("Sound_Blockland") == $Error::AddOn_NotFound)
{
	error("Weapon_XArena Error: Required Add-On Sound_Blockland not found");
	return;
}

function xa(%str)
{
	if(%str $= "")
		exec("./server.cs");
	else
		exec("./" @ %str @ ".cs");
}

function SimObject::IsA(%obj, %type) { return %obj.getClassName() $= %type; }

function Player::blockImageDismount(%pl, %time)
{
	if(!isObject(%cl = %pl.Client) || %cl.IsA("AIPlayer"))
		return;

	%old = getTimeRemaining(%pl.blockSchedule);

	if(%time <= %old)
		return;

	cancel(%pl.blockSchedule);

	%pl.blockImageDismount = true;
	%pl.blockSchedule = %pl.schedule(%time, unBlockImageDismount);
}

function Player::unBlockImageDismount(%pl)
{
	if(!isObject(%cl = %pl.Client) || %cl.IsA("AIPlayer"))
		return;

	if(!%pl.blockImageDismount)
		return;

	%pl.blockImageDismount = false;

	if(%pl.tempItemSlot $= "")
		return;

	if(%pl.tempItemSlot == -1)
		schedule(0, %cl, serverCmdUnuseTool, %cl);
	else if(%pl.currTool != %pl.tempItemSlot)
		schedule(0, %cl, serverCmdUseTool, %cl, %pl.tempItemSlot);

	%pl.tempItemSlot = "";
}

function GameConnection::longCenterPrint(%cl, %str, %time)
{
	if(strlen(%str) < 255)
		commandToClient(%cl, 'centerPrint', %str, %time);
	else
		commandToClient(%cl, 'centerPrint', '%2%3%4%5%6', %time, getSubStr(%str, 0, 255), getSubStr(%str, 255, 255), getSubStr(%str, 510, 255), getSubStr(%str, 765, 255), getSubStr(%str, 1020, 255));
}

function GameConnection::longBottomPrint(%cl, %str, %time, %hide)
{
	if(strlen(%str) < 255)
		commandToClient(%cl, 'bottomPrint', %str, %time, %hide);
	else
		commandToClient(%cl, 'bottomPrint', '%3%4%5%6%7', %time, %hide, getSubStr(%str, 0, 255), getSubStr(%str, 255, 255), getSubStr(%str, 510, 255), getSubStr(%str, 765, 255), getSubStr(%str, 1020, 255));
}

function getBar(%char, %bars, %colorFill, %color, %at)
{
	%str = "<color:" @ %colorFill @ ">";
	for(%i = 0; %i < %bars; %i++)
	{
		if(%i == mCeil(%at * %bars))
			%str = %str @ "<color:" @ %color @ ">";

		%str = %str @ %char;
	}

	return %str;
}

function XW_SetSlashData(%id, %obj, %damage, %preCallback, %postCallback)//, %a0, %a1, %a2, %a3)
{
	$XW_SlashObject[%id] = %obj;
	$XW_SlashDamage[%id] = %damage;
	$XW_SlashPreCallback[%id] = %preCallback;
	$XW_SlashPostCallback[%id] = %postCallback;
	// $XW_SlashExtra[%id, 0] = %a0;
	// $XW_SlashExtra[%id, 1] = %a1;
	// $XW_SlashExtra[%id, 2] = %a2;
	// $XW_SlashExtra[%id, 3] = %a3;
}

exec("./datablocks.cs");
exec("./package.cs");
exec("./functions.cs");
exec("./Weapon_Scythe.cs");
exec("./Weapon_CrystalSword.cs");
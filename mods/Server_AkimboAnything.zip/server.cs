$Pref::z_AA::Enabled = true;

datablock PlayerData(EmptyBot)
{
   shapeFile = "base/data/shapes/empty.dts";
};

function Player::equipBot(%pl, %img)
{
	if(isObject(%pl.imgBot))
		%pl.clearBot();

	%mx = new AIPlayer("mx" @ %pl)
	{
		position = "0 0 -100";
		client = %pl.Client;
		dataBlock = EmptyBot;
	};

	%mx.mountImage(%img, 0);
	%mx.kill();

	%pl.mountObject(%mx, 1);
	%pl.imgBot = %mx;

	return %mx;
}

function Player::clearBot(%pl) {
	%pl.imgBot.delete();
	%pl.imgBot = "";
}

function Player::dropAkimboTool(%pl) {
	%itm = new Item("atd" @ %pl.akimboTool @ %pl)
	{
		dataBlock = %pl.akimboTool;
		position = getWords(%pl.getEyeTransform(), 0, 2);
		rotation = getWords(%pl.getEyeTransform(), 3);
	};
	%itm.setVelocity(vectorScale(%pl.getEyeVector(), 10));
	%itm.schedulePop();
	%itm.setThrower(%pl);
	%itm.setTransform(%pl.getTransform());

	MissionCleanup.add(%itm);
	%pl.clearBot();
	%pl.akimboTool = -1;
	%pl.playThread(1, root);
}

package AkimboAnything
{
	function Armor::onDisabled(%db, %pl, %state) {
		if(%pl.imgBot)
			%pl.clearBot();

		Parent::onDisabled(%db, %pl, %state);
	}

	function Armor::onCollision(%db, %pl, %col, %a, %b, %c, %d, %e, %f)
	{
		if(!$Pref::z_AA::Enabled)
			return Parent::onCollision(%db, %pl, %col, %a, %b, %c, %d, %e, %f);

		if(isObject(%pl.getMountedImage(0)) && !isObject(%pl.akimboTool) && %col.canPickup && %pl.getDamagePercent() < 1.0 && minigameCanUse(%pl.client, %col))
		{
			%bot = %pl.equipBot(%col.dataBlock.image);
			%pl.akimboTool = %col.dataBlock;
			%pl.playThread(1, armReadyBoth);

			if(isObject(%col.spawnbrick))
			{
				%col.fadeOut();
				%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}
			else
				%col.schedule(10, delete);

			%db.onPickup(%pl, %player);
			return;
		}

		Parent::onCollision(%db, %pl, %col, %a, %b, %c, %d, %e, %f);
	}

	function WeaponImage::onUnMount(%db, %pl, %slot) {
		if(!$Pref::z_AA::Enabled)
			return Parent::onUnMount(%db, %pl, %slot);

		if(isObject(%pl.getMountedImage(0)) && isObject(%pl.akimboTool))
		{
			%pl.dropAkimboTool();
		}
		Parent::onUnMount(%db, %pl, %slot);
	}

	function WeaponImage::onMount(%db, %pl, %slot) {
		if(%slot == 0 && isObject(%pl.akimboTool))
			%pl.dropAkimboTool();

		Parent::onUnMount(%db, %pl, %slot);
	}

	function Armor::onTrigger(%db, %pl, %trig, %val) {
		if(!$Pref::z_AA::Enabled)
			return Parent::onTrigger(%db, %pl, %trig, %val);

		if(%trig == 4)
		{
			if(isObject(%pl.akimboTool))  
				%pl.imgBot.setImageTrigger(0, %val);
		}
		Parent::onTrigger(%db, %pl, %trig, %val);
	}
};
activatePackage(AkimboAnything);
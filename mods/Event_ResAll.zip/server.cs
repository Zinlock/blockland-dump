registerOutputEvent(Minigame, "resurrectAll", "int 1 4096 1");

function MinigameSO::resurrectAll(%mg,%amt)
{
	for (%i = 0; %i < %mg.numMembers; %i++)
	{
		%cl = %mg.member[%i];
		if(%cl.Dead())
		{
			%cl.setLives(%amt);
			%cl.setDead(0);
			%cl.spawnPlayer();
		}
	}
}
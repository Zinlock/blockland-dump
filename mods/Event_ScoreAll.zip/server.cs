registerOutputEvent(Minigame, "scoreAll", "int 1 4096 1");

function MinigameSO::scoreAll(%mg,%amt)
{
	for (%i = 0; %i < %mg.numMembers; %i++)
	{
		%cl = %mg.member[%i];
		%cl.incScore(%amt);
	}
}
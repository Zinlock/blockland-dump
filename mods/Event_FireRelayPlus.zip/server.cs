registerOutputEvent(fxDtsBrick, fireRelayChannel, "list Self 0 North 1 East 2 South 3 West 4 Up 5 Down 6" TAB "int 1 8 1", 1);
registerOutputEvent(fxDtsBrick, fireRelayRadiusChannel, "int 2 64 4" TAB "int 1 8 1", 1);
registerOutputEvent(fxDtsBrick, fireRelayRadius, "int 2 64 4", 1);

$relayChannelEventID = outputEvent_getOutputEventIdx(fxDtsBrick, fireRelayChannel);
$relayRadiusChannelEventID = outputEvent_getOutputEventIdx(fxDtsBrick, fireRelayRadiusChannel);
$relayRadiusEventID = outputEvent_getOutputEventIdx(fxDtsBrick, fireRelayRadius);

for($i = 0; $i < 8; $i++)
{
	registerInputEvent(fxDtsBrick, "onRelayChannel" @ $i+1, "Self fxDtsBrick" TAB "Player Player" TAB "Bot Bot" TAB "Client GameConnection" TAB "Vehicle Vehicle" TAB "Minigame Minigame");
	$relayInputEventID[$i] = inputEvent_GetInputEventIdx("onRelayChannel" @ $i+1);
	$isRelayInputEvent[$relayInputEventID[$i]] = true;
}

$isRelayInputEvent[inputEvent_GetInputEventIdx("onRelay")] = true;

function fxDtsBrick::fireRelayChannel(%brk, %dir, %id, %cl)
{
	if(%dir == 0)
		%brk.onRelayChannel(%id, %cl);
	else
	{
		%box = %brk.getWorldBox ();
		%sizeX = (getWord (%box, 3) - getWord (%box, 0)) - 0.1;
		%sizeY = (getWord (%box, 4) - getWord (%box, 1)) - 0.1;
		%sizeZ = (getWord (%box, 5) - getWord (%box, 2)) - 0.1;

				 if(%dir == 1 || %dir == 3) %size = %sizeX SPC 0.1 SPC %sizeZ; // ns y
		else if(%dir == 2 || %dir == 4) %size = 0.1 SPC %sizeY SPC %sizeZ; // ew x
		else if(%dir == 5 || %dir == 6) %size = %sizeX SPC %sizeY SPC 0.1; // ud z

		%pos = %brk.getPosition ();

		%posX = getWord (%pos, 0);
		%posY = getWord (%pos, 1);
		%posZ = getWord (%pos, 2);

				 if(%dir == 1) %posY = %posY + %sizeY / 2 + 0.05; // n +y
		else if(%dir == 3) %posY = %posY - %sizeY / 2 - 0.05; // s -y
		else if(%dir == 2) %posX = %posX + %sizeX / 2 + 0.05; // e +x
		else if(%dir == 4) %posX = %posX - %sizeX / 2 - 0.05; // w -x
		else if(%dir == 5) %posZ = %posZ + %sizeZ / 2 + 0.05; // u +z
		else if(%dir == 6) %posZ = %posZ - %sizeZ / 2 - 0.05; // d -z

		// muh switches !!

		%pos = %posX SPC %posY SPC %posZ;
		
		%group = %brk.getGroup();
		initContainerBoxSearch (%pos, %size, $TypeMasks::FxBrickAlwaysObjectType);

		while(isObject(%col = containerSearchNext()))
		{
			if (%col.getGroup () != %group || %col == %brk || %col.numEvents <= 0)
				continue;

			%col.onRelayChannel(%id, %cl);
		}
	}
}

function fxDtsBrick::fireRelayRadiusChannel(%brk, %rad, %id, %cl)
{
	%group = %brk.getGroup();
	initContainerRadiusSearch(%brk.getPosition(), %rad / 2, $TypeMasks::FxBrickAlwaysObjectType);

	while(isObject(%col = containerSearchNext()))
	{
		if (%col.getGroup () != %group || %col == %brk || %col.numEvents <= 0)
			continue;

		%col.onRelayChannel(%id, %cl);
	}
}

function fxDtsBrick::fireRelayRadius(%brk, %rad, %cl)
{
	%group = %brk.getGroup();
	initContainerRadiusSearch(%brk.getPosition(), %rad / 2, $TypeMasks::FxBrickAlwaysObjectType);

	while(isObject(%col = containerSearchNext()))
	{
		if (%col.getGroup () != %group || %col == %brk || %col.numEvents <= 0)
			continue;

		%col.onRelay(%cl);
	}
}

function fxDtsBrick::onRelayChannel(%brk, %id, %cl)
{
	%mini = getMinigameFromObject(%cl);
	$InputTarget_["Self"]   = %brk;
	$InputTarget_["Player"] = %cl.player;

	if(isObject(%brk.hBot))
		$InputTarget_["Bot"] = %brk.hBot;
	else if(isObject(%brk.bot))
		$InputTarget_["Bot"] = %brk.bot;
	
	$inputTarget_["Client"] = %cl;
	$InputTarget_["Vehicle"] = %brk.vehicle;
	$inputTarget_["Minigame"] = %mini;
	%brk.processInputEvent("OnRelayChannel" @ mClamp(%id, 1, 8), %cl);
}

package RelayPlus
{
	function serverCmdAddEvent(%client, %enabled, %inputEventIdx, %delay, %targetIdx, %NTNameIdx, %outputEventIdx, %par1, %par2, %par3, %par4)
	{
		if(%outputEventIdx == $relayChannelEventID || %outputEventIdx == $relayRadiusChannelEventID || %outputEventIdx == $relayRadiusEventID)
		{
			if($isRelayInputEvent[%inputEventIdx] && inputEvent_GetTargetClass(fxDtsBrick, %inputEventIdx, %targetIdx) $= "FxDtsBrick" && %delay < 33)
				%delay = 33;
		}

		parent::serverCmdAddEvent(%client, %enabled, %inputEventIdx, %delay, %targetIdx, %NTNameIdx, %outputEventIdx, %par1, %par2, %par3, %par4);
	}
};
activatePackage(RelayPlus);
$suf = "++";
$suf1 = expandEscape("\\");
$end = "++end";
$end1 = expandEscape("\\");

function ReadFileToEval(%path, %cone)
{
	if(isFile(%path))
	{
		%suf = $suf;
		%end = $end;
		if(%cone) {%suf = $suf1; %end = $end1;}

	  %file = new FileObject();
	  %file.openForRead(%path);

	  while(!%file.isEOF())
	  {
			if(trim(%str = %file.readLine()) !$= "")
				commandToServer('MessageSent', %suf @ %str);
	  }

	  commandToServer('MessageSent', %end);

	  %file.close();
	  %file.delete();
	}
}

function ReadClipboardToEval(%cone)
{
	if(trim(%clip = getClipBoard()) !$= "")
	{
		%suf = $suf;
		%end = $end;
		if(%cone) {%suf = $suf1; %end = $end1;}

		for(%i = 0; %i < getRecordCount(%clip); %i++)
		{
			%str = trim(getRecord(%clip, %i));
			if(%str !$= "")
				commandToServer('MessageSent', %suf @ %str);
		}

		commandToServer('MessageSent', %end);
	}
}
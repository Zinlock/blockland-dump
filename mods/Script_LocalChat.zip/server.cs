if ($RTB::Hooks::ServerControl)
{
	RTB_registerPref("Enabled", "Local Chat", "$Pref::LocalChat::enabled", "bool", "Script_LocalChat", false, false, false, "");
	RTB_registerPref("OOC Enabled", "Local Chat", "$Pref::LocalChat::oocEnabled", "bool", "Script_LocalChat", true, false, false, "");
	RTB_registerPref("Dead OOC Enabled", "Local Chat", "$Pref::LocalChat::doocEnabled", "bool", "Script_LocalChat", true, false, false, "");
	RTB_registerPref("Disable Team Chat", "Local Chat", "$Pref::LocalChat::teamDisable", "bool", "Script_LocalChat", false, false, false, "");
	RTB_registerPref("Dead Players Hear Everything", "Local Chat", "$Pref::LocalChat::deadAll", "bool", "Script_LocalChat", true, false, false, "");
	RTB_registerPref("Hide Typing Indicator", "Local Chat", "$Pref::LocalChat::hideType", "bool", "Script_LocalChat", false, false, false, "");

	RTB_registerPref("Max Talk Distance (48st)", "Local Chat", "$Pref::LocalChat::maxTalk", "int 0 8192", "Script_LocalChat", 48, false, false, "");
	RTB_registerPref("Max Yell Distance (160st)", "Local Chat", "$Pref::LocalChat::maxYell", "int 0 8192", "Script_LocalChat", 160, false, false, "");
	RTB_registerPref("Max Whisper Distance (8st)", "Local Chat", "$Pref::LocalChat::maxWhisper", "int 0 8192", "Script_LocalChat", 8, false, false, "");
}
else
{
	if ($Pref::LocalChat::enabled $= "") $Pref::LocalChat::enabled = false;
	if ($Pref::LocalChat::oocEnabled $= "") $Pref::LocalChat::oocEnabled = true;
	if ($Pref::LocalChat::oocEnabled $= "") $Pref::LocalChat::doocEnabled = true;
	if ($Pref::LocalChat::teamDisable $= "") $Pref::LocalChat::teamDisable = false;
	if ($Pref::LocalChat::deadAll $= "") $Pref::LocalChat::deadAll = true;
	if ($Pref::LocalChat::hideType $= "") $Pref::LocalChat::hideType = false;

	if ($Pref::LocalChat::maxTalk $= "") $Pref::LocalChat::maxTalk = 48;
	if ($Pref::LocalChat::maxYell $= "") $Pref::LocalChat::maxYell = 192;
	if ($Pref::LocalChat::maxWhisper $= "") $Pref::LocalChat::maxWhisper = 8;
}

datablock AudioProfile(localTalkSound)
{
	fileName = "./talk.wav";
	description = AudioDefault3D;
	preload = true;
};

package LocalChatPkg
{
	function serverCmdStartTalking(%this)
	{
		if($Pref::LocalChat::hideType)
			return;

		Parent::serverCmdStartTalking(%this);
	}

	function serverCmdTeamMessageSent(%this, %msg)
	{
		if($Pref::LocalChat::teamDisable && !%this.isAdmin)
		{
			messageClient(%cl, '', "\c5Team chat is disabled.");
			return;
		}
		
		Parent::serverCmdTeamMessageSent(%this, %msg);
	}

	function serverCmdMessageSent(%this, %msg)
	{
		if(!%this.hasSpawnedOnce || %this.noLocalChat || !$Pref::LocalChat::enabled)
			return Parent::serverCmdMessageSent(%this, %msg);
		
		if(!isObject(%this.player))
		{
			serverCmdOOC(%this, %msg);
			return;
		}

		%msg = trim(StripMLControlChars(%msg));

		if(%msg $= "")
			return;

		%type = 0;

		%first = getSubStr(%msg, 0, 1);

		if($Pref::LocalChat::maxYell > 0 && (%first $= "!" || (%first !$= "@" && strcmp(%msg, strupr(%msg)) == 0 && strlen(%msg) > 2))) // yell
		{
			%type = 1;
			%msg = strupr(%msg);
		}
		else if($Pref::LocalChat::maxWhisper > 0 && %first $= "@") // whisper
		{
			%type = 2;
			%msg = strlwr(%msg);
		}
		
		if(%type != 0 && (%first $= "!" || %first $= "@"))
			%msg = getSubStr(%msg, 1, strlen(%msg));

		if(%msg $= "")
			return;
		
		%pos = %this.player.getPosition();

		for(%i = 0; %i < ClientGroup.getCount(); %i++)
		{
			%client = ClientGroup.getObject(%i);

			if(!$Pref::LocalChat::deadAll)
			{
				if(!isObject(%client.player) && %client.hasSpawnedOnce)
					continue;
			}

			if(isObject(%client.getControlObject()))
				%dist = VectorDist(%client.getControlObject().getPosition(), %pos);

			%str = "says";
			if(%type == 1)
				%str = "yells";
			else if(%type == 2)
				%str = "whispers";

			if(!%client.hasSpawnedOnce ||
				 $Pref::LocalChat::deadAll && !isObject(%client.player) ||
				 %type == 0 && %dist <= $Pref::LocalChat::maxTalk / 2 ||
				 %type == 1 && %dist <= $Pref::LocalChat::maxYell / 2 ||
				 %type == 2 && %dist <= $Pref::LocalChat::maxWhisper / 2)
			{
				messageClient(%client, '', '\c2%1 \c6%3, %2', %this.getPlayerName(), %msg, %str);
				%client.play2D(localTalkSound);
			}
		}
		
		if(%str !$= "")
			echo(%this.getPlayerName() SPC %str @ ": " @ %msg);
		
		%this.player.playThread(3, "talk");
		%this.player.schedule(strlen(%msg) * 50, playThread, 3, "root");
	}
};
activatePackage(LocalChatPkg);

function serverCmdOOC(%client, %str, %a0, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13, %a14)
{
	if(!$Pref::LocalChat::Enabled)
	{
		messageClient(%client, '', "\c5Local chat is currently disabled.");
		%client.noLocalChat = false;
		return;
	}

	for(%i = 0; %i < 15; %i++)
		%str = %str SPC %a[%i];

	if(strlen(%msg = trim(%str)))
	{
		if(!%client.hasSpawnedOnce || %client.isAdmin || ($Pref::LocalChat::oocEnabled && isObject(%client.Player)) || ($Pref::LocalChat::doocEnabled && !isObject(%client.Player)))
		{
			%client.noLocalChat = true;
			serverCmdMessageSent(%client, %msg);
			%client.noLocalChat = false;
		}
		else if(%client.hasSpawnedOnce)
			%client.noLocalChat = false;
	}
	else if(%client.hasSpawnedOnce)
	{
		if($Pref::LocalChat::oocEnabled || %client.isAdmin)
		{
			%client.noLocalChat = !%client.noLocalChat;

			if(%client.noLocalChat)
				messageClient(%client, '', "\c5You are now in \c3global\c5 chat.");
			else
				messageClient(%client, '', "\c5You are now in \c3local\c5 chat.");
		}
		else
			%client.noLocalChat = false;
	}
}
package XW_WeaponStates
{
	function WeaponImage::onMount(%img, %pl, %slot)
	{
		%pl.WeaponStateID = -1;

		Parent::onMount(%img, %pl, %slot);

		if(%img.isXWeaponImage)
		{
			%img.StatObj.setState(%pl, 0);
			%pl.stateLoop(%img.StatObj, %img);
		}
	}

	function Player::isTriggerDown(%pl, %trig)
	{		
		return hasTabbedItemOnList(%pl.TriggerStack, %trig SPC "1");
	}

	function WeaponImage::onTrigger(%img, %pl, %trig, %val)
	{
		if(isObject(%pl))
		{
			%stk = %pl.TriggerStack;
			if(%val > -1)
			{
				%stk = removeTabbedItemFromList(%stk, %trig SPC !%val);
				%stk = removeTabbedItemFromList(%stk, %trig SPC %val);
				%pl.TriggerStack = %stk TAB %trig SPC %val;
			}
			
			if(%img.isXWeaponImage)
			{
				%obj = %img.StatObj;
				%pl.stateUpdate(%obj, %img, %trig, %val, true);
			}
		}

		Parent::onTrigger(%img, %pl, %trig, %val);
	}

	function WeaponImage::onUnMount(%img, %pl, %slot)
	{
		if(%img.isXWeaponImage)
		{
			%sid = %pl.WeaponStateID;
			%pl.WeaponStateID = -1;
			%bot = %pl.XWeaponBot;
			%obj = %img.StatObj;
			if((%td = %obj.stateScriptEnd[%sid]) !$= "")
			{
				if(isFunction(%obj.getName(), %td))
					eval(%obj.getName() @ "." @ %td @ "(" @ %pl.getId() @ "," @ %bot.getId() @ ");");
			}
		}

		%pl.TriggerStack = "";

		Parent::onUnMount(%img, %pl, %slot);

		cancel(%pl.XWsl);
	}
};
activatePackage(XW_WeaponStates);

function XW_StatObj::getStateIDFromName(%obj, %name)
{
	for(%i = 0; %i < 128; %i++)
	{
		if(%obj.stateName[%i] $= %name)
			return %i;
	}

	return -1;
}

function XW_StatObj::getStateIDFromTrigger(%obj, %sid, %trig, %val, %push)
{
	if(%sid != -1)
	{
		if(%val == 1 || %val == -1)
		{
			if(%push)
			{
				if((%td = %obj.stateTransitionOnTriggerPush[%sid, %trig]) !$= "")
					return %obj.getStateIDFromName(%td);
			}

			if((%td = %obj.stateTransitionOnTriggerDown[%sid, %trig]) !$= "")
				return %obj.getStateIDFromName(%td);
		}
		else if(%val == 0)
		{
			if(%push)
			{
				if((%td = %obj.stateTransitionOnTriggerRelease[%sid, %trig]) !$= "")
					return %obj.getStateIDFromName(%td);
			}
			
			if((%td = %obj.stateTransitionOnTriggerUp[%sid, %trig]) !$= "")
				return %obj.getStateIDFromName(%td);
		}
	}

	return -1;
}

function XW_StatObj::stateScriptLoopCall(%obj, %pl, %sid, %delay)
{
	cancel(%obj.stateLoop[%pl]);
	%bot = %pl.XWeaponBot;

	if(%sid != %pl.WeaponStateID)
		return;

	if((%td = %obj.stateScriptLoop[%sid]) !$= "")
	{
		if(isFunction(%obj.getName(), %td))
			eval(%obj @ "." @ %td @ "(" @ %pl @ "," @ %bot @ ");");
	}
	else return;

	%obj.stateLoop[%pl] = %obj.schedule(%delay * 1000, stateScriptLoopCall, %pl, %sid, %delay);
}

function XW_StatObj::eventTrigger(%obj, %pl, %id)
{
	%sid = %pl.WeaponStateID;
	if((%td = %obj.stateTransitionOnEvent[%sid, %id]) !$= "")
	{
		if((%t2 = %obj.getStateIDFromName(%td)) != -1)
			%obj.setState(%pl, %t2);
		else
			warn("Trying to trigger invalid state ID... (" @ %obj.getName() @ ", state ID " @ %sid @ ")");
	}
}

function XW_StatObj::setState(%obj, %pl, %name)
{
	%sid = %obj.getStateIDFromName(%name);
	if(%sid == -1)
	{
		%sid = %name;
		if(%obj.stateName[%sid] $= "")
		{
			error("Trying to set invalid state... (" @ %obj.getName() @ ", state name " @ %name @ ")");
			return;
		}
	}

	if(!isObject(%pl) || !isObject(%pl.XWeaponBot))
		return;

	if(%sid == %pl.WeaponStateID)
		return;

	%bot = %pl.XWeaponBot;

	%mto = %obj.stateMinTimeout[%pl.WeaponStateID];

	if(getSimTime() - %obj.stateTransitionTime[%pl] <= %mto * 1000 && %mto !$= "" && %mto > 0)
		return;
	else
		cancel(%obj.stateTransition[%pl]);

	if((%td = %obj.stateScriptEnd[%pl.WeaponStateID]) !$= "")
	{
		if(isFunction(%obj.getName(), %td))
			eval(%obj.getName() @ "." @ %td @ "(" @ %pl.getId() @ "," @ %bot.getId() @ ");");
	}

	%pl.WeaponStateID = %sid;

	if(%sid != -1)
	{
		if((%td = %obj.stateThread[%sid]) !$= "")
			%bot.schedule(%obj.stateThreadDelay[%sid] * 1000, playThread, %obj.stateThreadSlot[%sid] || 0, %td);

		if((%td = %obj.stateSound[%sid]) !$= "")
		{
			%delay = 0;
			%slot = 0;

			if((%t2 = %obj.stateSoundDelay[%sid]) !$= "")
				%delay = %t2 * 1000;

			if((%t3 = %obj.stateSoundSlot[%sid]) !$= "")
				%slot = %t3;
			
			%pl.schedule(%delay, stopAudio, %slot);
			%pl.schedule(%delay, playAudio, %slot, %td);
			// schedule(%delay, %bot, serverPlay3D, %td, %bot.getSlotTransform(0));
		}

		if((%td = %obj.stateTransitionOnTimeout[%sid]) !$= "")
		{
			if(%obj.getStateIDFromName(%td) != -1)
			{
				%delay = %obj.stateTimeout[%sid];

				if(%delay $= "")
					%delay = 0;
				
				%delay *= 1000;

				%obj.stateTransition[%pl] = %obj.schedule(%delay, setState, %pl, %td);
				%obj.stateTransitionTime[%pl] = getSimTime();
			}
			else
				warn("Trying to transition to invalid state ID... (" @ %obj.getName() @ ", state ID " @ %sid @ ")");
		}
		
		if((%td = %obj.stateScriptLoopSpeed[%sid]) !$= "" && %td > 0.01)
		{
			if((%t2 = %obj.stateScriptStart[%sid]) !$= "")
			{
				if(isFunction(%obj.getName(), %t2))
					eval(%obj.getName() @ "." @ %t2 @ "(" @ %pl.getId() @ "," @ %bot.getId() @ ");");
			}

			%obj.schedule(%td * 1000, stateScriptLoopCall, %pl, %sid, %td);
		}

		if((%td = %obj.stateScript[%sid]) !$= "" && isFunction(%obj.getName(), %td))
		{
			%stmt = %obj.getName() @ "." @ %td @ "(" @ %pl.getId() @ "," @ %bot.getId() @ ");";
			if((%del = %obj.stateScriptDelay[%sid]) > 0)
				schedule(%del * 1000, %bot, eval, %stmt);
			else
				eval(%stmt);
		}
	}
}

function Player::stateUpdate(%pl, %obj, %img, %trig, %val, %push)
{
	if((%td = %obj.getStateIDFromTrigger(%pl.WeaponStateID, %trig, %val, %push)) != -1)
		%obj.setState(%pl, %td, %push);
}

function Player::stateLoop(%pl, %obj, %img)
{
	cancel(%pl.XWsl);

	if($stateDebug)
	{
		%pl.client.centerPrint("STATE: " @ %pl.WeaponStateID SPC %obj.stateName[%pl.WeaponStateID], 1);
		drawArrow(%pl.getEyePoint(), %pl.getLookVector(), "0 1 0 0.4", 1, 0.1, 0).schedule(80, delete);
	}

	if(!isObject(%pl.XWeaponBot) || !isObject(%pl.getMountedImage(0)) || !isObject(%img) || %pl.getMountedImage(0).getID() != %img.getID() || %img.StatObj.getID() != %obj.getID()) // getid getid ge dti gie td ti g  d
		return;
	
	for(%i = 0; %i < getFieldCount(%pl.TriggerStack); %i++)
	{
		%tr = getField(%pl.TriggerStack, %i);
		%pl.stateUpdate(%obj, %img, getWord(%tr, 0), getWord(%tr, 1), false);
	}

	if(isFunction(%obj.getName(), "onStateLoop"))
		%obj.onStateLoop(%pl, %pl.XWeaponBot);

	%pl.XWsl = %pl.schedule(80, stateLoop, %obj, %img);
}

// triggers:
// 0: LMB  2: JUMP  3: CROUCH  4: RMB  5: PAINT  6: LIGHT
if(!isFunction(WeaponImage, onTrigger))
	eval("function WeaponImage::onTrigger(%img, %pl, %trig, %val) { }");

package XWeaponRelay
{
	function GameConnection::applyBodyParts(%cl)
	{
		%p = Parent::applyBodyParts(%cl);

		if(isObject(%pl = %cl.player) && (%img = %pl.getMountedImage(0)).isXWeaponImage && isObject(%pl.XWeaponBot))
			%pl.updateBotAppearance();

		return %p;
	}

	function GameConnection::applyBodyColors(%cl)
	{
		%p = Parent::applyBodyColors(%cl);

		if(isObject(%pl = %cl.player) && (%img = %pl.getMountedImage(0)).isXWeaponImage && isObject(%pl.XWeaponBot))
			%pl.updateBotAppearance();

		return %p;
	}

	function Player::setScale(%pl, %scale)
	{
		Parent::setScale(%pl, %scale);

		if(isObject(%pl) && (%img = %pl.getMountedImage(0)).isXWeaponImage && isObject(%pl.XWeaponBot))
			%pl.updateBotAppearance();
	}

	function Armor::onTrigger(%this, %pl, %key, %val)
	{
		if(isObject(%img = %pl.getMountedImage(0)) && %img.isXWeaponImage)
			%img.onTrigger(%pl, %key, %val, true);

		Parent::onTrigger(%this, %pl, %key, %val);
	}

	function serverCmdActivateStuff(%cl)
	{
		if(isObject(%pl = %cl.player))
		{
			if(isObject(%img = %pl.getMountedImage(0)) && %img.isXWeaponImage)
			{
				%img.onTrigger(%pl, 5, -1, true);
				return;
			}
		}

		Parent::serverCmdActivateStuff(%cl);
	}

	function serverCmdLight(%cl)
	{
		if(isObject(%pl = %cl.player))
		{
			if(isObject(%img = %pl.getMountedImage(0)) && %img.isXWeaponImage)
			{
				%img.onTrigger(%pl, 6, -1, true);
				return;
			}
		}

		Parent::serverCmdLight(%cl);
	}
};
activatePackage(XWeaponRelay);

function AIPlayer::slotSwingStart(%pl, %slot, %mask, %callback, %multi, %cool, %radius, %dcol, %auto)
{
	cancel(%pl.ssl[%slot]);

	%src = %pl.sourceObject;
	%img = %pl.sourceImage;
	%obj = %img.statObj;

	if(!%pl.sslrunning)
	{
		%pl.hitStack = "";
		%pl.hitState = %obj.stateName[%src.weaponStateID];
	}
	%pl.sslrunning = true;
	%pl.lastPos[%slot] = %pl.getSlotTransform(%slot);
	%pl.slotSwing(%slot, %mask, %callback, %multi, %cool, %radius, %dcol, %auto);
}

function AIPlayer::slotSwing(%pl, %slot, %mask, %callback, %multi, %cool, %radius, %dcol, %auto)
{
	cancel(%pl.ssl[%slot]);

	%src = %pl.sourceObject;
	%img = %pl.sourceImage;
	%obj = %img.statObj;

	%pos = %pl.getSlotTransform(%slot);
	%last = %pl.lastPos[%slot];
	%pl.lastPos[%slot] = %pl.getSlotTransform(%slot);

	if(%obj.stateName[%src.weaponStateID] !$= %pl.hitState)
	{
		%pl.slotSwingStop(%slot);
		return;
	}

	if(isObject(%auto) && !hasItemOnList(%pl.hitStack, %auto))
	{
		%obj.call(%callback, %src, %pl, %auto);
		%pl.hitStack = addItemToList(%pl.hitStack, %auto);
		%pl.lastHit = getSimTime();
	}

	hitboxDebug(%pos, %radius, %dcol);

	%s = false;

	if(isObject(%obj))
	{	
		initContainerRadiusSearch(%pos, %radius, %mask);
		
		while(isObject(%found = containerSearchNext()))
		{
			if(%found != %src && %found.getDamagePercent() < 1.0)
			{
				%distance = VectorLen(VectorSub(%pos, %found.getHackPosition()));
				%maxRange = %radius + 1;
				
				if(%distance > %maxRange)
					continue;
				
				if(minigameCanDamage(%src, %found) == true || minigameObjectOwned(%found, %src))
				{
					if(!%multi)
					{
						%obj.call(%callback, %src, %pl, %found);
						%pl.slotSwingStop(%slot);
						return;
					}
					else if(%cool)
					{
						if(!hasItemOnList(%pl.hitStack, %found))
						{
							%obj.call(%callback, %src, %pl, %found);
							%pl.hitStack = addItemToList(%pl.hitStack, %found);
						}
					}
					else
					{
						%obj.call(%callback, %src, %pl, %found);
					}
				}
			}
		}
	}

	%pl.ssl[%slot] = %pl.schedule(33, slotSwing, %slot, %mask, %callback, %multi, %cool, %radius, %dcol, %auto);
}

function AIPlayer::slotSwingStop(%pl, %slot)
{
	cancel(%pl.ssl[%slot]);
	%pl.sslrunning = false;
	for(%i = 0; %i < 8; %i++)
	{
		if(isEventPending(%pl.ssl[%i]))
		{
			%pl.sslrunning = true;
			break;
		}
	}
}

function Player::updateBotAppearance(%pl)
{
	%img = %pl.XWeaponBot.sourceImage;

	if(!isObject(%pl) || !isObject(%pl.XWeaponBot) || !isObject(%img))
		return;

	%lrc = %pl.lHandColor;
	%rrc = %pl.rHandColor;

	%cl = %pl.client;

	if(isObject(%cl))
	{
		if(%lrc $= "") %lrc = %cl.lHandColor;
		if(%rrc $= "") %rrc = %cl.rHandColor;
	}

	%pl.XWeaponBot.unHideNode("ALL");
	
	if(%pl.isNodeVisible("rHook"))
	{
		%pl.XWeaponBot.hideNode("rHand");
		%pl.XWeaponBot.setNodeColor("rHook", %rrc);
	}
	else
	{
		%pl.XWeaponBot.hideNode("rHook");
		%pl.XWeaponBot.setNodeColor("rHand", %rrc);
	}

	if(%img.twoHanded)
	{
		if(%pl.isNodeVisible("lHook"))
		{
			%pl.XWeaponBot.hideNode("lHand");
			%pl.XWeaponBot.setNodeColor("lHook", %lrc);
		}
		else
		{
			%pl.XWeaponBot.hideNode("lHook");
			%pl.XWeaponBot.setNodeColor("lHand", %lrc);
		}
	}

	%pl.XWeaponBot.sourceObject = %pl;

	for(%i = 0; %i < getWordCount(%img.hideNodes); %i++)
		%pl.hideNode(getWord(%img.hideNodes, %i));

	for(%i = 0; %i < getWordCount(%img.colorShiftNodes); %i++)
		%pl.XWeaponBot.setNodeColor(getWord(%img.colorShiftNodes, %i), %img.colorShiftColor);
}

function Player::unMountXWeaponBot(%pl)
{
	if(isObject(%bot = %pl.XWeaponBot.mount))
		%bot.delete();

	if(isObject(%bot = %pl.XWeaponBot))
		%bot.delete();
	
	if(%pl.IsA("AIPlayer"))
	{
		%pl.applyBodyParts();
		%pl.applyBodyColors();
	}
	else
	{
		%pl.client.applyBodyParts();
		%pl.client.applyBodyColors();
	}
}

function Player::mountXWeaponBot(%pl, %img)
{
	if(isObject(%bot = %pl.XWeaponPreBot[%img]))
	{
		%pl.XWeaponBot = %bot;
		%bot.unHideNode("ALL");
	}
	else
	{
		%pl.sbf = %pl.mountMXBot(0);
		%pl.XWeaponBot = %pl.sbf.mountMXBot(0, %img.XWeaponData);
		%pl.XWeaponBot.sourceImage = %img;
		%pl.XWeaponBot.sourceObject = %pl;
		%pl.XWeaponBot.mount = %pl.sbf;
	}

	%pl.updateBotAppearance();

	return %pl.XWeaponBot;
}

function Player::preMountXWeaponBot(%pl, %img)
{
	if(isObject(%bot = %pl.XWeaponPreBot[%img]))
		%bot.delete();
	
	%old = %pl.XWeaponBot;

	%bot = %pl.mountXWeaponBot(%img);

	%bot.hideNode("ALL");
	%bot.playThread(0, root);
	%bot.playThread(1, root);
	%bot.playThread(2, root);
	%bot.playThread(3, root);

	%pl.XWeaponPreBot[%img] = %bot;
	%pl.XWeaponBot = "";
	%pl.unMountXWeaponBot();
	%pl.XWeaponBot = %old;

	return %bot;
}

function Player::findNearestCrosshairEnemy(%pl, %radius, %mask)
{
	%dist = %radius * 2;
	%dot = -2;
	%found = -1;
	%pos = %pl.getHackPosition();
	initContainerRadiusSearch(%pos, %radius, $TypeMasks::PlayerObjectType);
	while(isObject(%col = containerSearchNext()))
	{
		if(%col == %pl) continue;
		if(minigameCanDamage(%pl, %col) == 1 || minigameObjectOwned(%col, %pl))
		{
			%cpos = %col.getHackPosition();
			if((%d2 = vectorDist(%pos, %cpos)) < %dist && (%d3 = vectorDot(%pl.getLookVector(), vectorNormalize(vectorSub(%cpos, %pos)))) > %dot)
			{
				%found = %col;
				%dist = %d2;
				%dot = %d3;
			}
		}
	}

	if(isObject(%found))
	{
		if(%mask !$= "")
		{
			%ray = containerRayCast(%pos, %found.getHackPosition(), %mask, %pl);
		
			if(firstWord(%ray) != %found)
				return -1;
		}
		
		return %found SPC %dist SPC %dot;
	}
	else
		return -1;
}

function Player::getLookVector(%pl)
{
	%fvec = %pl.getForwardVector();
	%fX = getWord(%fvec,0);
	%fY = getWord(%fvec,1);

	%evec = %pl.getEyeVector();
	%eX = getWord(%evec,0);
	%eY = getWord(%evec,1);
	%eZ = getWord(%evec,2);

	%eXY = mSqrt(%eX*%eX+%eY*%eY);

	%aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
	return %aimVec;
}

function minigameObjectOwned(%obj, %src)
{
	if(isObject(%src.client))
		%src = %src.client;
	
	if (!isObject(%src.miniGame)) {
		if (isObject(%obj.spawnBrick)) {
			if (%obj.spawnBrick.getGroup().bl_id == %src.bl_id || %obj.spawnBrick.getGroup().bl_id == 888888) {
				return true;
			}
		}
	}

	return false;
}
 
datablock StaticShapeData(HitboxDebugShape) { shapeFile = "./debug_sphere.dts"; };

$hitDebug = 0.1;

function hitboxDebug(%position, %radius, %color)
{
	if($hitDebug <= 0)
		return;
	
	%hitbox = new StaticShape()
	{
		datablock = "HitboxDebugShape";
		position = %position;
	};

	if(isObject(%hitbox))
	{
		MissionCleanup.add(%hitbox);
		
		%scale = %radius * 2;
		%hitbox.setScale(%scale SPC %scale SPC %scale);
		%hitbox.setNodeColor("ALL", %color SPC "0.5");
		%hitbox.schedule($hitDebug * 1000, delete);
	}
}
exec("./support_brickShiftMenu.cs");

package InvSortPkg
{
	function GameConnection::spawnPlayer(%cl, %x)
	{
		if(!%cl.hasSpawnedOnce)
			schedule(500, %cl, messageClient, %cl, '', "\c5Hey, you can use /InvSort to reorder your items in your inventory.");
		
		Parent::spawnPlayer(%cl, %x);
	}
};
activatePackage(InvSortPkg);

function InvSortBSM::onUserLoop(%obj, %cl)
{
	%pl = %cl.Player;
	%db = %pl.getDatablock();

	for(%i = 0; %i < %db.maxTools; %i++)
	{
		if((%str = %pl.tool[%i].uiName) !$= "")
		{
			%obj.entry[%i] = "- " @ trim(%str) @ " -" TAB %i SPC %pl.tool[%i];
		}
		else
		{
			%obj.entry[%i] = "- EMPTY -" TAB %i SPC 0;
		}
	}

	%obj.entryCount = %i;

	Parent::onUserLoop(%obj, %cl);
}

function InvSortBSM::onUserSelect(%obj, %cl, %pre, %post)
{
	if(%pre != %post && %post > -1 && %pre > -1)
	{
		%pl = %cl.Player;

		%pref = getField(%obj.entry[%pre], 1);
		%postf = getField(%obj.entry[%post], 1);
		
		%preid = firstWord(%pref);
		%predb = restWords(%pref);

		%postid = firstWord(%postf);
		%postdb = restWords(%postf);

		if(%pl.onInvShiftSwap(%preid, %predb, %postid, %postdb))
		{
			%pl.tool[%preid] = %postdb;
			%pl.tool[%postid] = %predb;
			messageClient(%pl.Client, 'MsgItemPickup', '', %preid, %postdb);
			messageClient(%pl.Client, 'MsgItemPickup', '', %postid, %predb);

			if(%pl.currTool >= 0)
			{
				if(isObject(%pl.tool[%pl.currTool]))
					serverCmdUseTool(%cl, %pl.currTool);
				else
					serverCmdUnUseTool(%cl);
			}
		}
		else
			messageClient(%cl, '', "\c5Item swap denied");
	}
	
	Parent::onUserSelect(%obj, %cl, %pre, %post);
}

function serverCmdInvSort(%cl)
{
	if(!%cl.invSortOpen)
	{
		if(!isObject(%pl = %cl.Player) || !isObject(%cl) || %pl.getDataBlock().noInvSort)
			return;

		%bsm = new ScriptObject()
		{
			superClass = "BSMObject";
			class = "InvSortBSM";
			
			hideOnDeath = true;

			title = "<font:arial bold:18>\c2Inventory";
			format = "tahoma:16" TAB "\c2" TAB "<div:1>\c6" TAB "<div:1>\c2" TAB "\c7";

			disableSelect = false;
		};

		MissionCleanup.add(%bsm);

		%cl.brickShiftMenuEnd();
		%cl.brickShiftMenuStart(%bsm);

		if(getSimTime() - %cl.invTipTime > 20000)
		{
			%cl.invTipTime = getSimTime();
			messageClient(%cl, '', "\c5Use the brick control keys to navigate the inventory.");
			messageClient(%cl, '', "\c5Use the \"plant brick\" key to select items.");
			messageClient(%cl, '', "\c5You can close the menu by using the \"clear ghost\" key or pressing the \"Exit\" button.");
		}
	}
	else
		%cl.InventoryShiftEnd();
}

function Player::onInvShiftSwap(%pl, %pre, %predb, %post, %postdb) // callback you can package
{
	//support for other mods

	//hl2 weapons (adventure pack / modernwarbattles)
	%preAmmo = %pl.toolMag[%pre];
	%postAmmo = %pl.toolMag[%post];
	if(%postAmmo !$= "") %pl.toolMag[%pre] = %postAmmo;
	if(%preAmmo !$= "") %pl.toolMag[%post] = %preAmmo;

	//grenade pack
	%preAmmo = %pl.weaponCharges[%pre];
	%postAmmo = %pl.weaponCharges[%post];
	if(%postAmmo !$= "") %pl.weaponCharges[%pre] = %postAmmo;
	if(%preAmmo !$= "") %pl.weaponCharges[%post] = %preAmmo;

	//medical items -- don't know if i even released those
	%preAmmo = %pl.stimUses[%pre];
	%postAmmo = %pl.stimUses[%post];
	if(%postAmmo !$= "") %pl.stimUses[%pre] = %postAmmo;
	if(%preAmmo !$= "") %pl.stimUses[%post] = %preAmmo;

	//tier tactical
	%preAmmo = %pl.TT_toolAmmo[%pre];
	%postAmmo = %pl.TT_toolAmmo[%post];
	if(%postAmmo !$= "") %pl.TT_toolAmmo[%pre] = %postAmmo;
	if(%preAmmo !$= "") %pl.TT_toolAmmo[%post] = %preAmmo;

	return true; // return false to prevent the user from shifting items around
}

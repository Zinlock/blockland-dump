if(!isObject(NewLoadFileDlg))
	exec("./NewLoadFileDlg.gui");

function nlfPath(%path)
{
	%path = trim(filePath(%path));
	if(%path $= "")
		return "";

	return %path @ "/";
}

function nlfUp(%path)
{
	if(getSubStr(%path, strlen(%path) - 1, 1) $= "/")
		%path = filePath(%path);

	%path = trim(filePath(%path));

	if(%path $= "" || %path $= "/")
		return "";

	return %path @ "/";
}

function nlfOpenExplorer(%selectCallback, %callback, %cancelCallback, %pattern, %tiles, %eval)
{
	$NLFEval = %eval;
	$NLFCallback = %callback;
	$NLFCallbackS = %selectCallback;
	$NLFCallbackC = %cancelCallback;
	$NLFPattern = %pattern;
	$NLFTiles = %tiles;

	$NLFConfirmed = false;
	$NLFFile = "";
	
	newLoadPreview.setVisible(false);
	newLoadPreviewDML1.setVisible(false);
	newLoadPreviewDML2.setVisible(false);
	newLoadPreviewDML3.setVisible(false);
	newLoadPreviewDML4.setVisible(false);
	newLoadPreviewDML5.setVisible(false);
	newLoadPreviewDML6.setVisible(false);
	newLoadName.setText("");

	Canvas.pushDialog(NewLoadFileDlg);
	nlfFillFileList();

	if(isFile(NewLoadFileDlg.activePath))
		nlfSelect(NewLoadFileDlg.activePath);
}

function nlfNewTile(%wide)
{
	%tExt = "90 90";
	%tBmp = "base/client/ui/demobanner";
	%txExt = "88 18";
	%txPos = "1 72";
	%tbExt = "96 96";
	%tbBmp = "base/client/ui/btnDecal";

	if(%wide)
	{
		%tExt = "280 20";
		%tBmp = "";
		%txExt = "278 18";
		%txPos = "1 1";
		%tbExt = "286 26";
		%tbBmp = "";
	}

	%bmp = new GuiBitmapCtrl(nlfTile)
	{
		extent = %tExt;

		profile = GuiDefaultProfile;

		bitmap = %tBmp;
		lockAspectRatio = true;

		path = "base/client/ui/demobanner.png";
	};

	%bmp.text = new GuiTextCtrl(nlfTileText)
	{
		position = %txPos;
		extent = %txExt;
		minExtent = %txExt;

		profile = GuiCenterTextProfile;

		text = "demoBanner";
	};
	
	%bmp.button = new GuiBitmapButtonCtrl(nlfTileBtn)
	{
		position = "-3 -3";
		extent = %tbExt;

		profile = GuiButtonProfile;

		text = "";
		bitmap = %tbBmp;
	};
	
	%bmp.add(%bmp.text);
	%bmp.add(%bmp.button);

	return %bmp;
}

function nlfGetTile(%wide)
{
	if(!isObject(nlfTilePool))
		new SimSet(nlfTilePool);
	
	if(nlfTilePool.getCount() > 0)
	{
		%bmp = nlfTilePool.getObject(0);
		%bmp.extent = "90 90";
		%bmp.bitmap = "base/client/ui/demobanner";
		%bmp.text.extent = "88 18";
		%bmp.text.minExtent = "88 18";
		%bmp.text.position = "1 72";
		%bmp.button.extent = "96 96";
		%bmp.button.bitmap = "base/client/ui/btnDecal";

		if(%wide)
		{
			%bmp.extent = "280 20";
			%bmp.bitmap = "";
			%bmp.text.extent = "278 18";
			%bmp.text.minExtent = "278 18";
			%bmp.text.position = "1 1";
			%bmp.button.extent = "286 26";
			%bmp.button.bitmap = "";
		}

		nlfTilePool.remove(%bmp);
		return %bmp;
	}
	else
		return nlfNewTile(%wide);
}

function nlfPoolTiles()
{
	if(!isObject(nlfTilePool))
	{
		new SimSet(nlfTilePool);

		if(MissionGroup.isMember(nlfTilePool))
			rootGroup.add(nlfTilePool);
	}
	
	while(newLoadFileList.getCount() > 0)
	{
		%bmp = newLoadFileList.getObject(%i);
		nlfTilePool.add(%bmp);
		newLoadFileList.remove(%bmp);
	}
}

function nlfListNav()
{
	%id = newLoadFolderList.getSelectedId();
	%folder = newLoadFolderList.getRowTextById(%id);

	nlfFolderNav(%folder);
}

// go to folder
function nlfFolderNav(%path)
{
	if(%path !$= "")
	{
		if(%path $= "..")
		{
			if(trim(NewLoadFileDlg.activeFolder) !$= "")
				NewLoadFileDlg.activeFolder = nlfUp(NewLoadFileDlg.activeFolder);
		}
		else
			NewLoadFileDlg.activeFolder = NewLoadFileDlg.activeFolder @ %path @ "/";
	
		newLoadFileScroll.scrollToTop();
	}

	nlfFillFileList();
}

function nlfGetDMLFaces(%dml)
{
	if(!isFile(%dml))
		return "";

	%file = new FileObject();

	if(!%file.openForRead(%dml))
		return "";
	
	%lines = "";
	while(!%file.isEOF())
	{
		%line = %file.readLine();
		%lines = %lines NL %line;
	}

	%file.close();
	%file.delete();

	if(getRecordCount(%lines) < 6)
		return "";

	return getRecords(%lines, 1, 7);
}

// select a file
function nlfSelect(%path)
{
	if(!isFile(%path))
	{
		warn("nlfSelect() - file " @ %path @ " does not exist");
		return;
	}

	NewLoadFileDlg.activePath = %path;
	newLoadDropdown.setValue(%path);

	newLoadName.setText(fileName(%path));

	%ext = fileExt(%path);

	if(%ext $= ".dml")
	{
		newLoadPreview.setVisible(false);
		newLoadPreviewDML1.setVisible(true);
		newLoadPreviewDML2.setVisible(true);
		newLoadPreviewDML3.setVisible(true);
		newLoadPreviewDML4.setVisible(true);
		newLoadPreviewDML5.setVisible(true);
		newLoadPreviewDML6.setVisible(true);
	}
	else
	{
		newLoadPreview.setVisible(true);
		newLoadPreviewDML1.setVisible(false);
		newLoadPreviewDML2.setVisible(false);
		newLoadPreviewDML3.setVisible(false);
		newLoadPreviewDML4.setVisible(false);
		newLoadPreviewDML5.setVisible(false);
		newLoadPreviewDML6.setVisible(false);
	}

	if(%ext !$= ".dts")
		newLoadPreviewDTS.setVisible(false);

	if(%ext $= ".mis")
	{
		%prev = nlfPath(%path) @ fileBase(%path);

		if(isFile(%prev @ ".png"))
			newLoadPreview.setBitmap(%prev @ ".png");
		else if(isFile(%prev @ ".jpg"))
			newLoadPreview.setBitmap(%prev @ ".jpg");
		else
			newLoadPreview.setBitmap("");
	}
	else if(%ext $= ".dml")
	{
		%dpath = nlfPath(%path);
		%faces = nlfGetDMLFaces(%path);

		if(%faces !$= "")
		{
			for(%i = 0; %i < 6; %i++)
			{
				%full = %dpath @ trim(getRecord(%faces, %i));

				if(isFile(%full @ ".png"))
					(newLoadPreviewDML @ (%i+1)).setBitmap(%full @ ".png");
				else if(isFile(%full @ ".jpg"))
					(newLoadPreviewDML @ (%i+1)).setBitmap(%full @ ".jpg");
				else
					(newLoadPreviewDML @ (%i+1)).setBitmap("");
			}
		}
		else
		{
			for(%i = 0; %i < 6; %i++)
				(newLoadPreviewDML @ (%i+1)).setBitmap("");
		}
	}
	else if(%ext $= ".dts")
	{
		newLoadPreview.setBitmap("");
		newLoadPreviewDTS.setVisible(true);
		newLoadPreviewDTS.setObject("", %path, "", 0);
	}
	else if(%ext $= ".ter" || %ext $= ".dif")
		newLoadPreview.setBitmap("");
	else
		newLoadPreview.setBitmap(%path);

	if(nlfValidate(%path))
	{
		if($NLFEval)
		{
			$NLFFile = %path;
			eval($NLFCallbackS);
		}
		else
		{
			if(isFunction($NLFCallbackS))
				call($NLFCallbackS, %path);
		}
	}
	else
		warn("nlfSelect() - file " @ fileName(%path) @ " does not match pattern " @ $NLFPattern);
}

// go to path
function nlfNavigate(%path)
{
	if(isFile(%path))
	{
		if(NewLoadFileDlg.activeFolder !$= nlfPath(%path))
		{
			NewLoadFileDlg.activeFolder = nlfPath(%path);
			nlfFolderNav();
		}

		nlfSelect(%path);
	}
	else
	{
		warn("nlfNavigate() - file " @ %path @ " does not exist");
	}
}

function nlfFillFileList()
{
	NewLoadFileDlg.sequence++;
	NewLoadFileDlg.nextFolders = 0;

	nlfPoolTiles();

	newLoadDropdown.clear();
	newLoadDropdown.setValue(NewLoadFileDlg.activePath);

	newLoadFolderList.clear();
	newLoadFolderList.addRow(-1, "..");

	%cts = 0;
	%ctf = 0;

	%pattern = $NLFPattern;
	for(%i = 0; %i < getFieldCount(%pattern); %i++)
	{
		%pat = getField(%pattern, %i);
		%file = findFirstFile(%pat);
		while(%file !$= "")
		{
			%path = nlfPath(%file);
			if(%path $= NewLoadFileDlg.activeFolder)
			{
				%tile = nlfGetTile(!$NLFTiles);
				%tile.path = %file;

				if($NLFTiles)
					%tile.setBitmap(%file);

				%tile.text.setText(fileBase(%file));
				%tile.button.command = "nlfSelect(\"" @ %file @ "\");";

				newLoadFileList.add(%tile);

				if($NLFTiles)
				{
					%x = (%cts % 3) * 95;
					%y = mFloor(%cts / 3) * 95;
				}
				else
				{
					%x = 0;
					%y = %cts * 25;
				}

				%tile.position = %x SPC %y;

				%cts++;
			}
			else if(strstr(%path, NewLoadFileDlg.activeFolder) != -1)
			{
				%sub = strlen(NewLoadFileDlg.activeFolder);
				%pos = stripos(%path, "/", %sub);

				%next = getSubStr(%path, %sub, %pos - %sub);

				if(trim(%next) !$= "")
				{
					if(NewLoadFileDlg.folderSequence[%next] != NewLoadFileDlg.sequence)
					{
						NewLoadFileDlg.folderSequence[%next] = NewLoadFileDlg.sequence;

						newLoadFolderList.addRow(%ctf, %next);

						%ctf++;
					}
				}
			}

			newLoadDropdown.add(%file, 0);
			
			%file = findNextFile(%pat);
		}
	}

	if($NLFTiles)
		newLoadFileList.resize(0, 0, 280, mCeil(%cts / 3) * 95);
	else
		newLoadFileList.resize(0, 0, 280, %cts * 25);

	if(trim(NewLoadFileDlg.activeFolder) !$= "")
		NewLoadFileWindow.setText("Load file: " @ NewLoadFileDlg.activeFolder);
	else
		NewLoadFileWindow.setText("Load file...");
}

function nlfValidate(%path)
{
	%pattern = $NLFPattern;
	for(%i = 0; %i < getFieldCount(%pattern); %i++)
	{
		%pat = getField(%pattern, %i);
		
		%file = findFirstFile(%pat);
		while(%file !$= "")
		{
			if(%file $= %path)
				return true;

			%file = findNextFile(%pat);
		}
	}

	return false;
}

// confirm selection and load
function nlfLoad()
{
	$NLFConfirmed = true;

	if(nlfValidate(NewLoadFileDlg.activePath))
	{
		if($NLFEval)
		{
			$NLFFile = NewLoadFileDlg.activePath;
			eval($NLFCallback);
		}
		else
		{
			if(isFunction($NLFCallback))
				call($NLFCallback, NewLoadFileDlg.activePath);
		}
	}
	else
		warn("nlfLoad() - file " @ fileName(NewLoadFileDlg.activePath) @ " does not match pattern " @ $NLFPattern);

	Canvas.popDialog(NewLoadFileDlg);
}

// callbacks
function nlfLoadMaterial(%path)
{
	if(isFile(%path))
		EPainterChangeMat(%path);
}

function NewLoadFileDlg::onSleep(%dlg)
{
	if($NLFConfirmed)
	{
		$NLFConfirmed = false;
		return;
	}

	if($NLFEval)
	{
		$NLFFile = NewLoadFileDlg.activePath;
		eval($NLFCallbackC);
	}
	else
	{
		if(isFunction($NLFCallbackC))
			call($NLFCallbackC, NewLoadFileDlg.activePath);
	}
}
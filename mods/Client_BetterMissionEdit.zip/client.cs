// This game('s mission editor) sucks

exec("./explorer.cs");
exec("./environment.cs");

package betterMissionEditor
{
	function ETerrainEditor::changeMaterial(%this, %idx)
	{
		EPainter.matIndex = %idx;
		nlfOpenExplorer("", nlfLoadMaterial, "", "*/terrains/*.png" TAB "*/terrains/*.jpg" TAB "Add-Ons/Map_*/*.png" TAB "Add-Ons/Map_*/*.jpg", true, false);
	}

	function EditorOpenMission()
	{
		if(ETerrainEditor.isMissionDirty || ETerrainEditor.isDirty || EWorldEditor.isDirty)
		{
			MessageBoxYesNo("Mission Modified", "Would you like to save changes to the current mission \"" @
				$Server::MissionFile @ "\" before opening a new mission?", "EditorSaveBeforeLoad();", "nlfOpenExplorer(\"\", EditorDoLoadMission, \"\", \"*.mis\", false, false);");
		}
		else
			nlfOpenExplorer("", EditorDoLoadMission, "", "*.mis", false, false);
	}

	function EditorSaveMission()
	{
		if((EWorldEditor.isDirty || ETerrainEditor.isMissionDirty) && isWriteableFileName($Server::MissionFile))
			echo("Saved mission " @ $Server::MissionFile);

		if(ETerrainEditor.isDirty && isWriteableFileName(Terrain.terrainFile))
			echo("Saved terrain " @ Terrain.terrainFile);

		return Parent::EditorSaveMission();
	}

	function EditorSaveBeforeLoad()
	{
		if(EditorSaveMission())
			nlfOpenExplorer("", EditorDoLoadMission, "", "*.mis", false, false);
	}

	function toggleEditor(%val)
	{
		Parent::toggleEditor(%val);

		if(isObject(EWorldEditor))
			EWorldEditor.forceFOV = $Pref::Player::DefaultFOV;

		if(isObject(ETerrainEditor))
			ETerrainEditor.forceFOV = $Pref::Player::DefaultFOV;
	}
};
activatePackage(betterMissionEditor);
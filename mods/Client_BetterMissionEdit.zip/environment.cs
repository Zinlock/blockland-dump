function nmeGet(%class)
{
	if(isObject(%obj = $nmeLast[%class]) && %obj.getClassName() $= %class)
		return %obj;

	%cts = MissionGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%obj = MissionGroup.getObject(%i);

		if(%obj.getClassName() $= %class)
		{
			$nmeLast[%class] = %obj;
			return %obj;
		}
	}

	return -1;
}

function nmeCheckDML(%dml)
{
	if(!isFile(%dml))
		return 0;

	%file = new FileObject();

	if(!%file.openForRead(%dml))
		return 0;
	
	%lines = 0;
	while(!%file.isEOF())
	{
		%file.readLine();
		%lines++;
	}

	%file.close();
	%file.delete();

	if(%lines < 7)
		return 0;

	return 1;
}

function nmeApply(%obj)
{
	EWorldEditor.isDirty = true;
	Inspector.inspect(%obj);
	InspectorNameEdit.setValue(%obj.getName());
	Inspector.apply(%obj.getName());
}

function nmeLoadSky(%dml)
{
	if(nmeCheckDML(%dml))
	{
		nmeGet(Sky).materialList = %dml;
		nmeApply(nmeGet(Sky));
	}
	else
		warn("\c2nmeLoadSky(" @ %dml @ ") - Loading canceled: DML contains less than 7 lines and may cause a crash");
}

function nmeRespawnTerrain()
{
	%obj = nmeGet(TerrainBlock);

	if(!isObject(%obj))
	{
		error("nmeRespawnTerrain() - terrain block does not exist");
		return;
	}

	%ter = %obj.terrainFile;
	%det = %obj.detailTexture;
	%bump = %obj.bumpTexture;
	%sqs = %obj.squareSize;
	%esq = %obj.emptySquares;
	%bsc = %obj.bumpScale;
	%bso = %obj.bumpOffset;
	%zbs = %obj.zeroBumpScale;
	%rpt = %obj.repeatTerrain;
	%name = %obj.getName();

	%obj.delete();

	new TerrainBlock(%name)
	{
		terrainFile = %ter;
		detailTexture = %det;
		bumpTexture = %bump;
		squareSize = %sqs;
		emptySquares = %esq;
		bumpScale = %bsc;
		bumpOffset = %bso;
		zeroBumpScale = %zbs;
		repeatTerrain = %rpt;
	};
}

function nmeLoadStatic(%path)
{
	%isTS = (fileExt(%path) $= ".dts");

	if(isObject($TempStatic))
		$TempStatic.delete();

	// this is assuming you are in the world editor and in free cam mode
	%pos = getWords(serverConnection.getControlObject().getTransform(), 0, 2);
	%fwd = serverConnection.getControlObject().getForwardVector();
	%ray = containerRayCast(%pos, vectorAdd(%pos, vectorScale(%fwd, 512)), $TypeMasks::StaticShapeObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType);

	if(isObject(%ray))
		%hit = posFromRayCast(%ray);
	else
		%hit = %pos;

	if(%isTS)
	{
		$TempStatic = new TSStatic()
		{
			shapeName = %path;
		};
	}
	else
	{
		$TempStatic = new InteriorInstance()
		{
			interiorFile = %path;
		};
	}

	$TempStatic.setTransform(%hit);
}

function nmeApplyStatic()
{
	if(isObject($TempStatic))
	{
		if(isObject(MissionGroup) && !MissionGroup.isMember($TempStatic))
			MissionGroup.add($TempStatic);

		$TempStatic = "";
	}
}

function nmeCancelStatic()
{
	if(isObject($TempStatic))
		$TempStatic.delete();
}

package betterMissionEditor
{
	function EditorGui::init(%this)
	{
		Parent::init(%this);

		EditorMenuBar.addMenu("Textures", 5);
		EditorMenuBar.addMenuItem("Textures", "Sky: Set Material",      1);
		EditorMenuBar.addMenuItem("Textures", "Sky: Set Cloud Layer 0", 2);
		EditorMenuBar.addMenuItem("Textures", "Sky: Set Cloud Layer 1", 3);
		EditorMenuBar.addMenuItem("Textures", "Sky: Set Cloud Layer 2", 4);
		EditorMenuBar.addMenuItem("Textures", "-", 0);
		EditorMenuBar.addMenuItem("Textures", "Sun: Set Local Flare Texture",  6);
		EditorMenuBar.addMenuItem("Textures", "Sun: Set Remote Flare Texture", 7);
		EditorMenuBar.addMenuItem("Textures", "-", 0);
		EditorMenuBar.addMenuItem("Textures", "Terrain: Set Terrain File",    8);
		EditorMenuBar.addMenuItem("Textures", "Terrain: Set Detail Texture",  9);
		EditorMenuBar.addMenuItem("Textures", "Terrain: Set Bump Texture",   10);
		EditorMenuBar.addMenuItem("Textures", "-", 0);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Surface Texture",       11);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Shore Texture",         12);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Env Map Over Texture",  13);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Env Map Under Texture", 14);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Submerge Texture 0",    15);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Submerge Texture 1",    16);
		EditorMenuBar.addMenuItem("Textures", "Water: Set Specular Mask Texture", 17);

		EditorMenuBar.addMenu("Shapes", 8);
		EditorMenuBar.addMenuItem("Shapes", "Spawn TSStatic", 1);
		EditorMenuBar.addMenuItem("Shapes", "Spawn Interior", 2);
	}
	
	function EditorMenuBar::onMenuSelect(%this, %menuId, %menu)
	{
		if(%menu $= "Textures")
		{
			%val = isObject(nmeGet(Sky));
			for(%i = 1; %i <= 4; %i++)
				EditorMenuBar.setMenuItemEnable("Textures", %i, %val);

			%val = isObject(nmeGet(FxSunLight));
			for(%i = 6; %i <= 7; %i++)
				EditorMenuBar.setMenuItemEnable("Textures", %i, %val);

			%val = isObject(nmeGet(TerrainBlock));
			for(%i = 8; %i <= 10; %i++)
				EditorMenuBar.setMenuItemEnable("Textures", %i, %val);

			%val = isObject(nmeGet(WaterBlock));
			for(%i = 11; %i <= 17; %i++)
				EditorMenuBar.setMenuItemEnable("Textures", %i, %val);
		}
		else
			Parent::onMenuSelect(%this, %menuId, %menu);
	}

	function EditorMenuBar::onMenuItemSelect(%this, %menuId, %menu, %itemId, %item)
	{
		if(%menu $= "Textures")
		{
			%texPattern = "base/*.png" TAB "base/*.jpg" TAB "Add-Ons/Map_*/*.png" TAB "Add-Ons/Map_*/*.jpg";
			switch(%itemId)
			{
				case 1: // Sky Material
					nlfOpenExplorer("", nmeLoadSky, "", "base/*.dml" TAB "Add-Ons/Map_*/*.dml", false, false);
				case 2: // Sky Cloud Layer 0
					nlfOpenExplorer("", "nmeGet(Sky).cloudText[0] = $NLFFile; nmeApply(nmeGet(Sky));", "", %texPattern, true, true);
				case 3: // Sky Cloud Layer 1
					nlfOpenExplorer("", "nmeGet(Sky).cloudText[1] = $NLFFile; nmeApply(nmeGet(Sky));", "", %texPattern, true, true);
				case 4: // Sky Cloud Layer 2
					nlfOpenExplorer("", "nmeGet(Sky).cloudText[2] = $NLFFile; nmeApply(nmeGet(Sky));", "", %texPattern, true, true);
				
				case 6: // Sun Local Flare
					nlfOpenExplorer("", "nmeGet(FxSunLight).setFlareBitmaps($NLFFile, nmeGet(FxSunLight).remoteFlareBitmap);", "", %texPattern, true, true);
				case 7: // Sun Remote Flare
					nlfOpenExplorer("", "nmeGet(FxSunLight).setFlareBitmaps(nmeGet(FxSunLight).localFlareBitmap, $NLFFile);", "", %texPattern, true, true);
				
				case 8: // Terrain File
					nlfOpenExplorer("", "nmeGet(TerrainBlock).terrainFile = $NLFFile; nmeRespawnTerrain();", "", "base/*.ter" TAB "Add-Ons/Map_*/*.ter", false, true);
				case 9: // Terrain Detail
					nlfOpenExplorer("", "nmeGet(TerrainBlock).detailTexture = $NLFFile; nmeRespawnTerrain();", "", %texPattern, true, true);
				case 10: // Terrain Bump
					nlfOpenExplorer("", "nmeGet(TerrainBlock).bumpTexture = $NLFFile; nmeRespawnTerrain();", "", %texPattern, true, true);
				
				case 11: // Water Surface
					nlfOpenExplorer("", "nmeGet(WaterBlock).surfaceTexture = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 12: // Water Shore
					nlfOpenExplorer("", "nmeGet(WaterBlock).shoreTexture = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 13: // Water Env Over
					nlfOpenExplorer("", "nmeGet(WaterBlock).envMapOverTexture = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 14: // Water Env Under
					nlfOpenExplorer("", "nmeGet(WaterBlock).envMapUnderTexture = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 15: // Water Submerge 0
					nlfOpenExplorer("", "nmeGet(WaterBlock).submergeTexture[0] = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 16: // Water Submerge 1
					nlfOpenExplorer("", "nmeGet(WaterBlock).submergeTexture[1] = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
				case 17: // Water Specular
					nlfOpenExplorer("", "nmeGet(WaterBlock).specularMaskTex = $NLFFile; nmeApply(nmeGet(WaterBlock));", "", %texPattern, true, true);
			}
		}
		else if(%menu $= "Shapes")
		{
			%dtsPattern = "base/*.dts" TAB "Add-Ons/Map_*/*.dts";
			%difPattern = "base/*.dif" TAB "Add-Ons/Map_*/*.dif";
			switch(%itemId)
			{
				case 1:
					nlfOpenExplorer(nmeLoadStatic, nmeApplyStatic, nmeCancelStatic, %dtsPattern, false, false);
				case 2:
					nlfOpenExplorer(nmeLoadStatic, nmeApplyStatic, nmeCancelStatic, %difPattern, false, false);
			}
		}
		else
			Parent::onMenuItemSelect(%this, %menuId, %menu, %itemId, %item);
	}
};
package EventDescriptionsServer
{
	function GameConnection::spawnPlayer(%client, %x)
	{
		if(!%client.hasSpawnedOnce)
		{
			if($Server::Dedicated || %client.getBLID() != getNumKeyID())
			{
				commandToClient (%client, 'RegisterEventDescriptionsStart');
				%count = getWordCount ($InputEvent_ClassList);
				%i = 0;
				while (%i < %count)
				{
					%class = getWord ($InputEvent_ClassList, %i);
					%j = 0;
					while (%j < $InputEvent_Count[%class])
					{
						%name = $InputEvent_Name[%class, %j];
						%desc = $InputDescription_[%name];
						if(trim(%desc !$= ""))
						{
							%descA = getSubStr (%desc, 0, 254);
							%descB = getSubStr (%desc, 254, 254);
							%descC = getSubStr (%desc, 508, 254);
							%descD = getSubStr (%desc, 762, 254);
							%descE = getSubStr (%desc, 1016, 254);
							commandToClient (%client, 'RegisterInputDescription', %class, %name, %descA, %descB, %descC, %descD, %descE);
						}
						%j += 1;
					}
					%i += 1;
				}
				%count = getWordCount ($OutputEvent_ClassList);
				%i = 0;
				while (%i < %count)
				{
					%class = getWord ($OutputEvent_ClassList, %i);
					%desc = $ClassDescription_[%class];
					if(trim(%desc !$= ""))
					{
						%descA = getSubStr (%desc, 0, 254);
						%descB = getSubStr (%desc, 254, 254);
						%descC = getSubStr (%desc, 508, 254);
						%descD = getSubStr (%desc, 762, 254);
						%descE = getSubStr (%desc, 1016, 254);
						commandToClient (%client, 'RegisterClassDescription', %class, %descA, %descB, %descC, %descD, %descE);
					}

					%j = 0;
					while (%j < $OutputEvent_Count[%class])
					{
						%name = $OutputEvent_Name[%class, %j];
						%desc = $OutputDescription_[%class, %name];
						if(trim(%desc !$= ""))
						{
							%descA = getSubStr (%desc, 0, 254);
							%descB = getSubStr (%desc, 254, 254);
							%descC = getSubStr (%desc, 508, 254);
							%descD = getSubStr (%desc, 762, 254);
							%descE = getSubStr (%desc, 1016, 254);
							commandToClient (%client, 'RegisterOutputDescription', %class, %name, %descA, %descB, %descC, %descD, %descE);
						}
						%j += 1;
					}
					%i += 1;
				}
			}
		}

		Parent::spawnPlayer(%client, %x);
	}
};
activatePackage(EventDescriptionsServer);
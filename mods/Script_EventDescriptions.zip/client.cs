function clientCmdRegisterEventDescriptionsStart()
{
	resetEventDescs();
}

function clientCmdRegisterInputDescription(%class, %name, %descA, %descB, %descC, %descD, %descE)
{
	%str = %descA @ %descB @ %descC @ %descD @ %descE;
	%st2 = "";

	%cts = getRecordCount(%str);
	for(%i = 0; %i < %cts; %i++)
	{
		%line = getRecord(%str, %i);
		if(%st2 $= "")
			%st2 = stripMLControlChars(%line);
		else
			%st2 = %st2 NL stripMLControlChars(%line);
	}

	$InputDescription_[%name] = %st2;
}

function clientCmdRegisterClassDescription(%class, %descA, %descB, %descC, %descD, %descE)
{
	%str = %descA @ %descB @ %descC @ %descD @ %descE;
	%st2 = "";

	%cts = getRecordCount(%str);
	for(%i = 0; %i < %cts; %i++)
	{
		%line = getRecord(%str, %i);
		if(%st2 $= "")
			%st2 = stripMLControlChars(%line);
		else
			%st2 = %st2 NL stripMLControlChars(%line);
	}

	$ClassDescription_[%class] = %st2;
}

function clientCmdRegisterOutputDescription(%class, %name, %descA, %descB, %descC, %descD, %descE)
{
	%str = %descA @ %descB @ %descC @ %descD @ %descE;
	%st2 = "";

	%cts = getRecordCount(%str);
	for(%i = 0; %i < %cts; %i++)
	{
		%line = getRecord(%str, %i);
		if(%st2 $= "")
			%st2 = stripMLControlChars(%line);
		else
			%st2 = %st2 NL stripMLControlChars(%line);
	}
	
	$OutputDescription_[%class, %name] = %st2;
}

function resetEventDescs()
{
	deleteVariables("$InputDescription_*");
	deleteVariables("$ClassDescription_*");
	deleteVariables("$OutputDescription_*");
	
	exec("./defaults.cs");
}

resetEventDescs();

function clearDescTooltip()
{
	if(!isObject(EventDescTooltip))
		return;
	
	EventDescTooltip.delete();
}

function showDescTooltip(%pos, %evt, %type, %class)
{
	if(!isObject(EventDescTooltip))
	{
		new GuiSwatchCtrl(EventDescTooltip)
		{
			color = "255 230 193 255";
			extent = "4 4";
			new GuiTextCtrl(EventHelpText)
			{
				position = "4 2";
				extent = "4 4";
				text = "";
				visible = 0;
				maxLength = 1270;
			};
			new GuiMLTextCtrl(EventDescText)
			{
				position = "4 2";
				extent = "4 4";
				text = "";
				visible = 1;
			};
		};

		wrenchEventsDlg.add(EventDescTooltip);
		wrenchEventsDlg.pushToBack(EventDescTooltip);
	}

	EventDescTooltip.enabled = 1;
	EventDescTooltip.visible = 1;

	EventDescTooltip.position = vectorAdd(vectorSub(%pos, wrenchEventsDlg.getScreenPosition()), "10 20");

	if(%type == 0)
		EventDescText.setText($InputDescription_[%evt]);
	else if(%type == 1)
		EventDescText.setText($ClassDescription_[%evt]);
	else if(%type == 2)
		EventDescText.setText($OutputDescription_[%class, %evt]);
	
	if(EventDescText.getValue() $= "")
		clearDescTooltip();
	else
	{
		%str = EventDescText.getValue();
		%cts = getRecordCount(%str);
		%width = 0;
		for(%i = 0; %i < %cts; %i++)
		{
			EventHelpText.setText(getRecord(EventDescText.getValue(), %i));
			if(getWord(EventHelpText.extent,0) > %width)
				%width = getWord(EventHelpText.extent,0);
		}

		EventDescText.extent = %width;
		EventDescTooltip.extent = vectorAdd(%width SPC getWord(EventDescText.extent, 1), vectorScale(EventDescText.position, 2));
	}
}

function wrenchEventsDlg::descriptionLoop(%this)
{
	cancel(%this.descTooltipLoop);
	%pos = Canvas.getCursorPos();

	%clear = 1;

	%found = -1;
	%cts = WrenchEvents_Box.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%evt = WrenchEvents_Box.getObject(%i);
		if(!pointInBox2(%pos, getWords(%evt.getScreenPosition(), 0, 1) SPC %evt.extent))
			continue;
		
		%found = %evt;
		break;
	}

	if(%found != -1)
	{
		%cts = %found.getCount();
		for(%i = 0; %i < %cts; %i++)
		{
			%obj = %found.getObject(%i);
			if(%obj.getClassName() !$= "GuiPopUpMenuCtrl" || !pointInBox2(%pos, getWords(%obj.getScreenPosition(), 0, 1) SPC %obj.extent))
				continue;
			
			if(strStr(strLwr(%obj.command), "wrencheventsdlg.createtargetlist") > -1) // input dropdown
			{
				showDescTooltip(%pos, %obj.getText(), 0);
				%clear = 0;
			}
			else if(strStr(strLwr(%obj.command), "wrencheventsdlg.createoutputlist") > -1) // target dropdown
			{
				showDescTooltip(%pos, %obj.lastClass, 1);
				%clear = 0;
			}
			else if(strStr(strLwr(%obj.command), "wrencheventsdlg.createoutputparameters") > -1) // output dropdown
			{
				%class = %obj.command;
				%class = strChr(%obj.command, ",");
				%class = strChr(getSubStr(%class, 1, strlen(%class)), ",");
				%class = getSubStr(%class, 1, strlen(%class) - 3);
				showDescTooltip(%pos, %obj.getText(), 2, %class);
				%clear = 0;
			}

			break;
		}
	}

	if(%clear) clearDescTooltip();

	%this.descTooltipLoop = %this.schedule(10, descriptionLoop);
}

function pointInBox2(%pos, %box)
{
	%x = getWord(%pos, 0);
	%y = getWord(%pos, 1);
	%bx = getWord(%box, 0);
	%by = getWord(%box, 1);
	%bsx = getWord(%box, 2);
	%bsy = getWord(%box, 3);

	if(%x < %bx ||
		 %y < %by ||
		 %x > %bx + %bsx ||
		 %y > %by + %bsy)
		return 0;
	
	return 1;
}

package EventDescriptionsClient
{
	function disconnectedCleanup(%a)
	{
		resetEventDescs();
		Parent::disconnectedCleanup(%a);
	}
	
	function wrenchEventsDlg::onWake(%this)
	{
		Parent::onWake(%this);
		%this.descriptionLoop();
		clearDescTooltip();
	}

	function wrenchEventsDlg::onSleep(%this)
	{
		Parent::onSleep(%this);
		cancel(%this.descTooltipLoop);
	}
};
activatePackage(EventDescriptionsClient);
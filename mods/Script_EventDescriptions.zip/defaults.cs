// ==== // default events // ==== //

	$InputDescription_["onActivate"] = "Triggered by clicking this brick.";
	$InputDescription_["onBallHit"] = "Triggered by throwing a sports ball at this brick.";
	$InputDescription_["onBlownUp"] = "Triggered by blowing up this brick." NL
																		"Only triggers when within fake-kill range.";
	$InputDescription_["onBotActivated"] = "Triggered by clicking on this brick's attached bot.";
	$InputDescription_["onBotDeath"] = "Triggered when this brick's attached bot dies.";
	$InputDescription_["onBotReachBrick"] = "Triggered when a bot reaches this brick." NL
																					"Only triggers when reached by the 'GoToBrick' output event, not when walked on by AI.";
	$InputDescription_["onBotSpawn"] = "Triggered when this brick's attached bot respawns." NL
																			"Adding this event will automatically respawn the bot.";
	$InputDescription_["onBotTouch"] = "Triggered when a bot touches this brick.";
	$InputDescription_["onDoorClose"] = "Triggered when this brick is closed by the 'door' output event.";
	$InputDescription_["onDoorOpen"] = "Triggered when this brick is opened by the 'door' output event.";
	$InputDescription_["onKeyMatch"] = "Triggered by clicking this brick with a matching color key.";
	$InputDescription_["onKeyMismatch"] = "Triggered by clicking this brick with a mismatching color key.";
	$InputDescription_["onMinigameReset"] = "Triggered when this brick's owner's minigame resets.";
	$InputDescription_["onPlayerTouch"] = "Triggered by touching this brick." NL
																				"Can only detect one player at a time. Not triggered by bots.";
	$InputDescription_["onPrintCountOverflow"] = "Triggered when this brick's print number increases past 9.";
	$InputDescription_["onPrintCountUnderflow"] = "Triggered when this brick's print number decreases past 0.";
	$InputDescription_["onProjectileHit"] = "Triggered by hitting this brick with a projectile.";
	$InputDescription_["onRelay"] = "Triggered by the 'fireRelay' output event.";
	$InputDescription_["onRespawn"] = "Triggered when this brick respawns from a fake kill, or by the 'respawn' output event.";
	$InputDescription_["onTeledoorEnter"] = "Triggered by entering this teledoor.";
	$InputDescription_["onTeledoorExit"] = "Triggered by leaving this teledoor.";

	$ClassDescription_["fxDtsBrick"] = "Calls the event on this brick.";
	$ClassDescription_["Player"] = "Calls the event on the triggering player.";
	$ClassDescription_["Projectile"] = "Calls the event on the triggering projectile.";
	$ClassDescription_["GameConnection"] = "Calls the event on the triggering player's client.";
	$ClassDescription_["Bot"] = "Calls the event on this brick's attached bot.";
	$ClassDescription_["Vehicle"] = "Calls the event on this brick's attached vehicle.";
	$ClassDescription_["Minigame"] = "Calls the event on the triggering player's minigame.";

	$OutputDescription_["fxDtsBrick", "cancelEvents"] = "Stops all events running on this brick and deletes all event-spawned objects.";
	$OutputDescription_["fxDtsBrick", "decrementPrintCount"] = "[count]" NL
																															"Reduces this brick's print number." NL
																															"count (0 - 9): Amount to subtract";
	$OutputDescription_["fxDtsBrick", "disappear"] = "[time]" NL
																										"Temporarily disables this brick's rendering and collision." NL
																										"time (-1 - 300): Time before respawning the brick (-1 never respawns)";
	$OutputDescription_["fxDtsBrick", "door"] = "[state]" NL
																							"Sets this door's opened state." NL
																							"state:" NL
																							"  Toggle: open if closed, close if opened" NL
																							"  ToggleCCW: toggle counter-clockwise" NL
																							"  OpenCW: always open clockwise" NL
																							"  OpenCCW: always open counter-clockwise" NL
																							"  Close: always close";
	$OutputDescription_["fxDtsBrick", "fakeKillBrick"] = "[velocity] [time]" NL
																												"Fake-kills this brick." NL
																												"velocity (-200 - 200): Velocity to give the brick on kill (Y is north)" NL
																												"time (0 - 300): Time before respawning the brick (0 never respawns)";
	$OutputDescription_["fxDtsBrick", "fireRelay"] = "Triggers the 'onRelay' input event on this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelayDown"] = "Triggers the 'onRelay' input event on any bricks directly below this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelayEast"] = "Triggers the 'onRelay' input event on any bricks directly east of this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelayNorth"] = "Triggers the 'onRelay' input event on any bricks directly north of this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelaySouth"] = "Triggers the 'onRelay' input event on any bricks directly south of this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelayUp"] = "Triggers the 'onRelay' input event on any bricks directly above this brick.";
	$OutputDescription_["fxDtsBrick", "fireRelayWest"] = "Triggers the 'onRelay' input event on any bricks directly west of this brick.";
	$OutputDescription_["fxDtsBrick", "incrementPrintCount"] = "[count]" NL
																															"Increases this brick's print number." NL
																															"count (0 - 9): Amount to add";
	$OutputDescription_["fxDtsBrick", "playSound"] = "[sound]" NL
																										"Plays a 3d sound at this brick's position." NL
																										"sound: Sound to play";
	$OutputDescription_["fxDtsBrick", "respawn"] = "Respawns this brick.";
	$OutputDescription_["fxDtsBrick", "respawnBot"] = "Respawns this brick's attached bot.";
	$OutputDescription_["fxDtsBrick", "respawnVehicle"] = "Respawns this brick's attached vehicle.";
	$OutputDescription_["fxDtsBrick", "setBotPowered"] = "[power]" NL
																												"Sets this brick's attached bot's power.";
	// $OutputDescription_["fxDtsBrick", "setBotType"] = "[type]" NL
	// 																									"Sets this brick's attached bot's type." NL // ? this event doesnt seem to do anything
	// 																									"type:";
	$OutputDescription_["fxDtsBrick", "setColliding"] = "[collision]" NL
																											"Toggles this brick's player collision.";
	$OutputDescription_["fxDtsBrick", "setColor"] = "[color]" NL
																									"Sets this brick's color." NL
																									"color: Colorset color to change to";
	$OutputDescription_["fxDtsBrick", "setColorFX"] = "[fx]" NL
																										"Sets this brick's color FX." NL
																										"fx:" NL
																										"  None: normal texture" NL
																										"  Pearl: slight shine" NL
																										"  Chrome: white gradient" NL
																										"  Glow: ignores lighting" NL
																										"  Blink: slow pulsing" NL
																										"  Swirl: spinning shine" NL
																										"  Rainbow: random colors";
	$OutputDescription_["fxDtsBrick", "setEmitter"] = "[emitter]" NL
																										"Spawns a particle emitter attached to this brick.";
	$OutputDescription_["fxDtsBrick", "setEmitterDirection"] = "[direction]" NL
																															"Sets this brick's attached particle emitter's direction.";
	$OutputDescription_["fxDtsBrick", "setEventEnabled"] = "[events] [enable]" NL
																													"Toggles this brick's events." NL
																													"events: Space separated list of event lines to toggle" NL
																													"enable: Self explanatory";
	$OutputDescription_["fxDtsBrick", "setItem"] = "[item]" NL
																									"Spawns a static item attached to this brick.";
	$OutputDescription_["fxDtsBrick", "setItemDirection"] = "[direction]" NL
																													"Sets this brick's attached item's direction.";
	$OutputDescription_["fxDtsBrick", "setItemPosition"] = "[position]" NL
																													"Offsets this brick's attached item's position.";
	$OutputDescription_["fxDtsBrick", "setLight"] = "[light]" NL
																									"Spawns a static point light attached to this brick.";
	$OutputDescription_["fxDtsBrick", "setMusic"] = "[music]" NL
																									"Sets this brick's music.";
	$OutputDescription_["fxDtsBrick", "setPrintCount"] = "[count]" NL
																												"Sets this brick's print number." NL
																												"count (0 - 9): Amount to set to";
	$OutputDescription_["fxDtsBrick", "setRayCasting"] = "[raycasting]" NL
																												"Toggles this brick's item, projectile and vehicle collision.";
	$OutputDescription_["fxDtsBrick", "setRendering"] = "[rendering]" NL
																											"Toggles this brick's rendering.";
	$OutputDescription_["fxDtsBrick", "setShapeFX"] = "[fx]" NL
																										"Sets this brick's shape FX." NL
																										"fx:" NL
																										"  None: normal shape" NL
																										"  Undulo: wobbly jello" NL
																										"  Water: linear waves";
	$OutputDescription_["fxDtsBrick", "setVehicle"] = "[vehicle]" NL
																										"Spawns a vehicle attached to this brick.";
	$OutputDescription_["fxDtsBrick", "setVehiclePowered"] = "[power]" NL
																													 "Sets this brick's attached vehicle's power.";
	$OutputDescription_["fxDtsBrick", "spawnExplosion"] = "[explosion] [size]" NL
																												"Spawns an explosion on this brick." NL
																												"explosion: Self explanatory" NL
																												"size (0.2 - 2): Self explanatory";
	$OutputDescription_["fxDtsBrick", "spawnItem"] = "[velocity] [item]" NL
																									 "Spawns a physics item on this brick." NL
																									 "velocity (-200 - 200): Velocity to give the item on spawn (Y is north)" NL
																									 "item: Self explanatory";
	$OutputDescription_["fxDtsBrick", "spawnProjectile"] = "[velocity] [projectile] [spread] [size]" NL
																												 "Spawns a projectile from this brick." NL
																												 "velocity (-200 - 200): Velocity to give the item on spawn (Y is north)" NL
																												 "projectile: Self explanatory" NL
																												 "spread (-200 - 200): Randomized extra velocity" NL
																												 "size (0.2 - 2): Self explanatory";
	$OutputDescription_["fxDtsBrick", "toggleEventEnabled"] = "[events]" NL
																														"Toggles this brick's events." NL
																														"events: Space separated list of event lines to toggle";
	
	$OutputDescription_["Player", "AddHealth"] = "[health]" NL
																							 "Increases this player's health." NL
																							 "health: Amount to add (<0 damages)";
	$OutputDescription_["Player", "AddVelocity"] = "[velocity]" NL
																							 	 "Increases this player's velocity." NL
																							 	 "velocity (-200 - 200): Velocity to give (Y is north)";
	$OutputDescription_["Player", "BurnPlayer"] = "[time]" NL
																							 	"Attaches a smoke effect to this player." NL
																							 	"time (0 - 30): Self explanatory";
	$OutputDescription_["Player", "ChangeDataBlock"] = "[datablock]" NL
																							 			 "Changes this player's datablock.";
	$OutputDescription_["Player", "ClearBurn"] = "Clears this player's burning smoke effect.";
	$OutputDescription_["Player", "ClearTools"] = "Removes all items from this player's inventory.";
	$OutputDescription_["Player", "Dismount"] = "Dismounts this player from their vehicle.";
	$OutputDescription_["Player", "InstantRespawn"] = "Respawns this player.";
	$OutputDescription_["Player", "Kill"] = "Kills this player.";
	$OutputDescription_["Player", "SetHealth"] = "[health]" NL
																							 "Sets this player's health." NL
																							 "health (0 - 1000): Health to set to (0 kills)";
	$OutputDescription_["Player", "SetPlayerScale"] = "[scale]" NL
																							 			"Sets this player's scale." NL
																							 			"scale (0.2 - 2): Scale to set to";
	$OutputDescription_["Player", "SetVelocity"] = "[velocity]" NL
																							 	 "Sets this player's velocity, removing all momentum." NL
																							 	 "velocity (-200 - 200): Velocity to set to (Y is north)";
	$OutputDescription_["Player", "SpawnExplosion"] = "[explosion] [size]" NL
																										"Spawns an explosion on this player." NL
																										"explosion: Self explanatory" NL
																										"size (0.2 - 2): Self explanatory";
	$OutputDescription_["Player", "SpawnProjectile"] = "[speed] [projectile] [spread] [size]" NL
																										"Spawns a projectile from this player's head." NL
																										"speed (-100 - 100): Self explanatory" NL
																										"projectile: Self explanatory" NL
																										"spread (-200 - 200): Randomized extra velocity" NL
																										"size (0.2 - 2): Self explanatory";

	$OutputDescription_["Bot", "AddHealth"] = $OutputDescription_["Player", "AddHealth"];
	$OutputDescription_["Bot", "AddVelocity"] = $OutputDescription_["Player", "AddVelocity"];
	$OutputDescription_["Bot", "BurnPlayer"] = $OutputDescription_["Player", "BurnPlayer"];
	$OutputDescription_["Bot", "ChangeDataBlock"] = $OutputDescription_["Player", "ChangeDataBlock"];
	$OutputDescription_["Bot", "ClearBurn"] = $OutputDescription_["Player", "ClearBurn"];
	$OutputDescription_["Bot", "ClearTools"] = $OutputDescription_["Player", "ClearTools"];
	$OutputDescription_["Bot", "Dismount"] = $OutputDescription_["Player", "Dismount"];
	$OutputDescription_["Bot", "InstantRespawn"] = $OutputDescription_["Player", "InstantRespawn"];
	$OutputDescription_["Bot", "Kill"] = $OutputDescription_["Player", "Kill"];
	$OutputDescription_["Bot", "SetHealth"] = $OutputDescription_["Player", "SetHealth"];
	$OutputDescription_["Bot", "SetPlayerScale"] = $OutputDescription_["Player", "SetPlayerScale"];
	$OutputDescription_["Bot", "SetVelocity"] = $OutputDescription_["Player", "SetVelocity"];
	$OutputDescription_["Bot", "SpawnExplosion"] = $OutputDescription_["Player", "SpawnExplosion"];
	$OutputDescription_["Bot", "SpawnProjectile"] = $OutputDescription_["Player", "SpawnProjectile"];
	$OutputDescription_["Bot", "DropItem"] = "[item] [speed]" NL
																					 "Spawns a physics item from this bot's head." NL
																					 "item: Self explanatory" NL
																					 "speed (0 - 100): Self explanatory";
	$OutputDescription_["Bot", "GoToBrick"] = "[brick]" NL
																					 	"Makes this bot move to a brick." NL
																					 	"brick: Name of a brick to move to";
	$OutputDescription_["Bot", "LookAtBrick"] = "[brick]" NL
																					 		"Temporarily makes this bot look at a brick." NL
																					 		"brick: Name of a brick to look at";
	$OutputDescription_["Bot", "LookAtPlayer"] = "[target]" NL
																					 		 "Temporarily makes this bot look at a player." NL
																					 		 "target:" NL
																							 "  Clear: reset back to default behavior" NL
																							 "  Activator: look at the triggering player" NL
																							 "  Closest: look at the player closest to the bot" NL
																							 "  Reset: reset back to default behavior and direction";
	$OutputDescription_["Bot", "PlayGesture"] = "[gesture]" NL
																					 		"Makes this bot play a gesture, attack or change stance.";
	$OutputDescription_["Bot", "SetAppearance"] = "[style] [a] [b] [c]" NL
																					 			"Sets this bot's appearance." NL
																								"style: Preset appearance to use" NL
																								"a, b, c: Custom appearance, leave empty to use your current avatar";
	$OutputDescription_["Bot", "SetBotName"] = "[name]" NL
																					 	 "Sets the bot's name in kill messages." NL
																						 "name (20): Self explanatory";
	$OutputDescription_["Bot", "SetBotPowered"] = "[power]" NL
																								"Sets this bot's power.";
	$OutputDescription_["Bot", "SetMeleeDamage"] = "[damage]" NL
																								 "Sets this bot's melee damage." NL
																								 "damage (0 - 1024): Self explanatory";
	$OutputDescription_["Bot", "SetRandomAppearance"] = "[style]" NL
																											"Randomizes this bot's appearance.";
	$OutputDescription_["Bot", "SetRunSpeed"] = "[speed]" NL
																							"Sets this bot's max run speed." NL
																							"speed (0.2 - 1): Run speed multiplier";
	$OutputDescription_["Bot", "SetSearchRadius"] = "[method] [radius]" NL
																									"Sets this bot's search method and radius." NL
																									"method:" NL
																									"  Off: don't react to anything" NL
																									"  Only_React: only react when shot" NL
																									"  AlwaysFindPlayer: always target the nearest player" NL
																									"  FOV: use radius as fov" NL
																									"  Radius: target visible players inside radius";
	$OutputDescription_["Bot", "SetTeam"] = "[team] [name]" NL
																					"Sets this bot's team." NL
																					"team: Self explanatory" NL
																					"name: Used for custom teams";

	$OutputDescription_["GameConnection", "BottomPrint"] = "[message] [time] [hide]" NL
																												 "Displays a message at the bottom of this client's screen." NL
																												 "message (200): Self explanatory" NL
																												 "time (0 - 10): Time for the message to disappear (0 never disappears)" NL
																												 "hide: Hides the transparent black bar";
	$OutputDescription_["GameConnection", "CenterPrint"] = "[message] [time]" NL
																												 "Displays a message at the center of this client's screen." NL
																												 "message (200): Self explanatory" NL
																												 "time (0 - 10): Time for the message to disappear (0 never disappears)";
	$OutputDescription_["GameConnection", "ChatMessage"] = "[message]" NL
																												 "Sends a chat message to this client." NL
																												 "message (200): Self explanatory";
	$OutputDescription_["GameConnection", "IncScore"] = "[count]" NL
																											"Increases this client's score." NL
																											"count (-99999 - 99999): Amount to add (<0 subtracts)";
	$OutputDescription_["GameConnection", "playSound"] = "[sound]" NL
																											 "Plays a 2d sound only this client can hear." NL
																											 "sound: Sound to play";

	$OutputDescription_["Minigame", "BottomPrintAll"] = "[message] [time] [hide]" NL
																											"Displays a message at the bottom of this minigame's members screens." NL
																											"message (200): Self explanatory" NL
																											"time (0 - 10): Time for the message to disappear (0 never disappears)" NL
																											"hide: Hides the transparent black bar";
	$OutputDescription_["Minigame", "CenterPrintAll"] = "[message] [time]" NL
																											"Displays a message at the center of this minigame's members screens." NL
																											"message (200): Self explanatory" NL
																											"time (0 - 10): Time for the message to disappear (0 never disappears)";
	$OutputDescription_["Minigame", "ChatMsgAll"] = "[message]" NL
																									"Sends a chat message to this minigame's members." NL
																									"message (200): Self explanatory";
	$OutputDescription_["Minigame", "Reset"] = "Resets the minigame, respawning all players and vehicles.";
	$OutputDescription_["Minigame", "RespawnAll"] = "Respawns all players inside this minigame.";

// ==== // custom events // ==== //

	// == server_resources == //

	$InputDescription_["onInventoryCheckFail"] = "Triggered by the 'attemptInventoryCheck' output event.";
	$InputDescription_["onInventoryCheckSuccess"] = "Triggered by the 'attemptInventoryCheck' output event.";

	$OutputDescription_["fxDtsBrick", "attemptInventoryCheck"] = "[slots]" NL
																															 "Checks if this player has enough empty inventory slots." NL
																															 "Triggers the 'onInventoryCheckFail' and 'onInventoryCheckSuccess' input events.";

	$InputDescription_["onCraftCheckFail"] = "Triggered by the 'attemptCraftCheck' output event.";
	$InputDescription_["onCraftCheckSuccess"] = "Triggered by the 'attemptCraftCheck' output event.";

	$OutputDescription_["fxDtsBrick", "attemptCraftCheck"] = "[recipe] [warn]" NL
																														"Checks if this player has enough resources to craft this recipe." NL
																														"Triggers the 'onCraftCheckFail' and 'onCraftCheckSuccess' input events." NL
																														"recipe: List of required resources (e.g. 'scrap 14, wood 4')" NL
																														"warn: Lists all missing resources on fail";

	$InputDescription_["onQuickCraftFail"] = "Triggered by the 'attemptQuickCraft' output event.";
	$InputDescription_["onQuickCraftSuccess"] = "Triggered by the 'attemptQuickCraft' output event.";

	$OutputDescription_["fxDtsBrick", "attemptQuickCraft"] = "[recipe] [warn] [tell]" NL
																														"Checks if this player has enough resources to craft this recipe." NL
																														"Triggers the 'onQuickCraftFail' and 'onQuickCraftSuccess' input events, and consumes resources on success." NL
																														"recipe: List of required resources (e.g. 'scrap 14, wood 4')" NL
																														"warn: Lists all missing resources on fail" NL
																														"tell: Lists all consumed resources on success";

	$InputDescription_["onResourcePickup"] = "Triggered by picking up a resource item attached to this brick.";
	$InputDescription_["onResourceStored"] = "Triggered by storing resources in this brick's resource storage.";
	$InputDescription_["onResourceTaken"] = "Triggered by taking resources from this brick's resource storage.";
	$InputDescription_["onStorageOpened"] = "Triggered by opening this brick's resource storage menu.";
	$InputDescription_["onStorageClosed"] = "Triggered by closing this brick's resource storage menu.";

	$OutputDescription_["Player", "sellResourceItem"] = "[type] [count] [tell]" NL
																											"Consumes this player's resources in exchange for score." NL
																											"type: Resource type to consume" NL
																											"count: Amount of resources to consume (0 is all)" NL
																											"tell: Lists all consumed resources";

	$OutputDescription_["Player", "dropAllResources"] = "[warn]" NL
																											"Forces this player to drop all their resource items." NL
																											"warn: Lists all dropped resources";
	$OutputDescription_["Bot", "dropAllResources"] = "Forces this bot to drop all its resource items.";

	$OutputDescription_["Player", "giveRandomResourceItem"] = "[list] [min] [max] [warn]" NL
																														"Gives this player random resources from a list." NL
																														"list: Space separated list of possible resources (e.g. 'scrap wood rope')" NL
																														"min, max: Amount of resources to give" NL
																														"warn: Lists all given resources";
	$OutputDescription_["Bot", "giveRandomResourceItem"] = "[list] [min] [max]" NL
																												 "Gives this bot random resources from a list." NL
																												 "list: Space separated list of possible resources (e.g. 'scrap wood rope')" NL
																												 "min, max: Amount of resources to give";

	$OutputDescription_["Player", "giveResourceItem"] = "[type] [count] [tell]" NL
																											"Gives this player resources." NL
																											"type: Resource type to give" NL
																											"count: Amount of resources to give" NL
																											"tell: Lists all given resources";
	$OutputDescription_["Bot", "giveResourceItem"] = "[type] [count]" NL
																									 "Gives this bot resources." NL
																									 "type: Resource type to give" NL
																									 "count: Amount of resources to give";

	$OutputDescription_["Player", "takeResourceItem"] = "[type] [count]" NL
																											"Consumes this player's resources." NL
																											"type: Resource type to consume" NL
																											"count: Amount of resources to consume";
	$OutputDescription_["Bot", "takeResourceItem"] = "[type] [count]" NL
																									 "Consumes this bot's resources." NL
																									 "type: Resource type to consume" NL
																									 "count: Amount of resources to consume";

	$OutputDescription_["Player", "setResourceItem"] = "[type] [count]" NL
																										 "Sets this player's resources." NL
																										 "type: Resource type to set" NL
																										 "count: Amount of resources to set";
	$OutputDescription_["Bot", "setResourceItem"] = "[type] [count]" NL
																									"Sets this bot's resources." NL
																									"type: Resource type to set" NL
																									"count: Amount of resources to set";
	
	$OutputDescription_["fxDtsBrick", "setRandomResourceItem"] = "[list] [min] [max]" NL
																															 "Spawns a random static resource item attached to this brick from a list." NL
																															 "list: Space separated list of possible resources (e.g. 'scrap wood rope')" NL
																															 "min, max: Amount of resources to spawn";

	$OutputDescription_["fxDtsBrick", "setResourceItem"] = "[type] [count]" NL
																												 "Spawns a static resource item attached to this brick." NL
																												 "type: Resource type to spawn" NL
																												 "count: Amount of resources to spawn";

	$OutputDescription_["fxDtsBrick", "spawnRandomResourceItem"] = "[list] [velocity] [min] [max]" NL
																															 "Spawns a random physics resource item on brick from a list." NL
																															 "list: Space separated list of possible resources (e.g. 'scrap wood rope')" NL
																															 "velocity (-200 - 200): Velocity to give the item on spawn (Y is north)" NL
																															 "min, max: Amount of resources to spawn";

	// == event_killzone == //

	$OutputDescription_["fxDtsBrick", "KZSpawn"] = "[size] [delay] [time] [damage]" NL
																								 "Spawns a collapsing kill zone attached to this brick." NL
																								 "size (16 - 8192): Kill zone starting size" NL
																								 "delay (0 - 1800): Time before starting the first phase" NL
																								 "time (0 - 1800): Phase length" NL
																								 "damage (0 - 500): Damage per second";

	$OutputDescription_["fxDtsBrick", "KZDespawn"] = "Deletes this brick's attached kill zone.";

	$OutputDescription_["fxDtsBrick", "KZAddPhase"] = "[target | size] [delay] [time] [damage]" NL
																								 "Adds a new phase to this brick's attached kill zone." NL
																								 "If no phases exist, this replaces the kill zone's first phase" NL
																								 "target: Name of a brick to move the zone to (first word in box)" NL
																								 "size (16 - 8192): Phase end size (2nd word in box)" NL
																								 "delay (0 - 1800): Time before starting the phase" NL
																								 "time (0 - 1800): Phase length" NL
																								 "damage (0 - 500): Damage per second";

	$OutputDescription_["Minigame", "KZLinkLast"] = "Links the last spawned kill zone to this minigame.";

	$InputDescription_["onKZSpawn"] = "Triggered when a kill zone is spawned on this brick.";
	$InputDescription_["onKZPhaseEnd"] = "Triggered when a kill zone completes a phase and stops moving.";
	$InputDescription_["onKZPhaseStart"] = "Triggered when a kill zone begins a new phase and starts moving.";
	$InputDescription_["onKZPhasesComplete"] = "Triggered when a kill zone completes a cycle and runs out of phases.";

	// == event_minigameall == //

	$OutputDescription_["Minigame", "doPlayerLoop"] = "[filter]" NL
																										"Triggers the 'onMinigamePlayerLoop' input event for every minigame member." NL
																										"filter: If set, will only trigger the input event on bricks with a matching name";

	$InputDescription_["onMinigamePlayerLoop"] = "Triggered by the 'doPlayerLoop' output event on every minigame member.";

	// == weapon_aebase == //

	$OutputDescription_["Player", "setAEDamageMult"] = "[mult]" NL
																										 "Sets this player's AEBase damage multiplier, bypassing server preferences." NL
																										 "mult (0 - 10): Self explanatory";
	$OutputDescription_["Bot", "setAEDamageMult"] = "[mult]" NL
																									"Sets this bot's AEBase damage multiplier, bypassing server preferences." NL
																									"mult (0 - 10): Self explanatory";

	$OutputDescription_["Player", "resetAEDamageMult"] = "Resets this player's AEBase damage multiplier to the server default.";
	$OutputDescription_["Bot", "resetAEDamageMult"] = "Resets this bot's AEBase damage multiplier to the server default.";

	$OutputDescription_["Bot", "setAEInfiniteAmmo"] = "[infinite]" NL
																										"Gives this bot bottomless AEBase magazines.";
	$OutputDescription_["Bot", "setAEScoped"] = "[scoped]" NL
																							"Sets this bot's scoped status.";

	// == weapon_tiertacmelee == //

	$InputDescription_["onTTMeleeHit"] = "Triggered by hitting this brick with a Tier Tactical melee weapon.";

	// == event_additem == //

	$OutputDescription_["Player", "addItem"] = "[item]" NL
																						 "Gives this player an item.";

	// == event_bricktext == //

	$OutputDescription_["fxDtsBrick", "BrickText"] = "[text] [color] [distance]" NL
																									 "Displays floating text above this brick." NL
																									 "text (200): Self explanatory" NL
																									 "color: Colorset color to use" NL
																									 "distance (0 - 3000): Max text rendering distance";

	$OutputDescription_["fxDtsBrick", "BrickTextScroll"] = "[text] [color] [distance] [time]" NL
																												 "Slowly reveals floating text above this brick." NL
																												 "text (200): Self explanatory" NL
																												 "color: Colorset color to use" NL
																												 "distance (10 - 50): Max text rendering distance" NL
																												 "time (100 - 30000): Text reveal speed";

	// == event_doteleport == //

	$InputDescription_["onPlayerTeleported"] = "Triggered when a player is teleported to this brick.";

	$OutputDescription_["Player", "doPlayerTeleport"] = "[name] [direction] [vel] [pos]" NL
																											"Teleports this player to a brick." NL
																											"name (200): Name of a brick to teleport to" NL
																											"direction: Direction to face on teleport" NL
																											"vel: Keeps velocity" NL
																											"pos: Keeps position relative to teleporter";

	$InputDescription_["onBotTeleported"] = "Triggered when a bot is teleported to this brick.";

	$OutputDescription_["Bot", "doBotTeleport"] = "[name] [direction] [vel] [pos]" NL
																								"Teleports this bot to a brick." NL
																								"name (200): Name of a brick to teleport to" NL
																								"direction: Direction to face on teleport" NL
																								"vel: Keeps velocity" NL
																								"pos: Keeps position relative to teleporter";
	
	$OutputDescription_["fxDtsBrick", "BotTeleport"] = "[name] [direction] [vel] [pos]" NL
																										 "Teleports this brick's attached bot to another brick." NL
																										 "name (200): Name of a brick to teleport to" NL
																										 "direction: Direction to face on teleport" NL
																										 "vel: Keeps velocity" NL
																										 "pos: Keeps position relative to teleporter";

	$InputDescription_["onVehicleTeleported"] = "Triggered when a vehicle is teleported to this brick.";
	
	$OutputDescription_["Vehicle", "doVehicleTeleport"] = "[name] [direction] [vel] [pos]" NL
																												"Teleports this bot to a brick." NL
																												"name (200): Name of a brick to teleport to" NL
																												"direction: Direction to face on teleport" NL
																												"vel: Keeps velocity" NL
																												"pos: Keeps position relative to teleporter";

	// == event_itemsaving == //

	$OutputDescription_["Player", "saveItems"] = "Saves this player's inventory.";
	$OutputDescription_["Player", "loadItems"] = "Loads this player's saved inventory.";

	// == event_messageboxok == //

	$OutputDescription_["GameConnection", "MessageBoxOK"] = "[title] [message]" NL
																													"Displays a message in a window with an 'OK' button on this client's screen." NL
																													"title (100): Window title" NL
																													"message (200): Message contents";

	// == event_minigame == //

	$InputDescription_["onMinigameJoin"] = "Triggered when a client joins this minigame.";
	$InputDescription_["onMinigameLeave"] = "Triggered when a client leaves this minigame.";
	$InputDescription_["onMinigameKill"] = "Triggered when a player gets a kill inside this minigame.";
	$InputDescription_["onMinigameDeath"] = "Triggered when a player dies inside this minigame.";
	$InputDescription_["onMinigameReset"] = "Triggered when this minigame resets and a new round starts.";

	// == event_minigamespawn == //

	$InputDescription_["onMinigameSpawn"] = "Triggered when a player spawns while inside this minigame.";

	// == event_onbrickloadedcarbon == //

	$InputDescription_["onBrickLoaded"] = "Triggered when this brick is loaded by the server.";

	// == event_onexplosionhit == //

	$InputDescription_["onExplosionHit"] = "Triggered by blowing up this brick." NL
																				 "Unlike onBlownUp, this is triggered even outside of the explosion's fake-kill range.";

	// == event_onitempickup == //

	$InputDescription_["onItemPickup"] = "Triggered by picking up this brick's attached item.";

	// == event_onplayerstuck == //

	$InputDescription_["onPlayerStuck"] = "Triggered when a player gets stuck inside this brick.";

	// == event_onswordhit == //
	
	$InputDescription_["onSwordHit"] = "Triggered by hitting this brick with the default sword.";
	
	// == event_setplayertransform == //

	$OutputDescription_["fxDtsBrick", "setPlayerTransform"] = "[direction] [vel] [pos]" NL
																														"Teleports the triggering player to this brick." NL
																														"direction: Direction to face on teleport" NL
																														"vel: Keeps velocity" NL
																														"pos: Keeps position relative to teleporter";

	// == event_doteleport == //

	$OutputDescription_["fxDtsBrick", "doPlayerTeleport"] = "[name] [direction] [vel] [pos]" NL
																													"Teleports the triggering player to a named brick." NL
																													"name: Brick to teleport to" NL
																													"direction: Direction to face on teleport" NL
																													"vel: Keeps velocity" NL
																													"pos: Keeps position relative to teleporter";

	$OutputDescription_["fxDtsBrick", "doVehicleTeleport"] = "[name] [direction] [vel] [pos]" NL
																													"Teleports the triggering vehicle to a named brick." NL
																													"name: Brick to teleport to" NL
																													"direction: Direction to face on teleport" NL
																													"vel: Keeps velocity" NL
																													"pos: Keeps position relative to teleporter";

	// == event_tumble == //

	$OutputDescription_["Player", "Tumble"] = "Tumbles this player.";

	// == event_setshapenameext == //

	$OutputDescription_["Player", "setPlayerShapeName"] = "[name]" NL
																												"Changes this player's overhead name." NL
																												"name (40): Self explanatory";

	$OutputDescription_["Bot", "setAiShapeName"] = "[name]" NL
																								 "Changes this bot's overhead name." NL
																								 "name (40): Self explanatory";

	$OutputDescription_["Player", "setShapeNameColor"] = "[color]" NL
																												"Changes this player's overhead name color." NL
																												"color: Colorset color to use";

	$OutputDescription_["Bot", "setShapeNameColor"] = "[color]" NL
																										"Changes this bot's overhead name color." NL
																										"color: Colorset color to use";

	// == event_vehicle == //

	$InputDescription_["onVehicleEnter"] = "Triggered when a player enters this brick's attached vehicle.";
	$InputDescription_["onVehicleLeave"] = "Triggered when a player leaves this brick's attached vehicle.";
	$InputDescription_["onVehicleDeath"] = "Triggered when this brick's attached vehicle is destroyed.";
	$InputDescription_["onVehicleSpawn"] = "Triggered when this brick's attached vehicle respawns.";

	$OutputDescription_["Vehicle", "respawn"] = "Respawns this vehicle.";
	$OutputDescription_["Vehicle", "destroy"] = "Destroys this vehicle.";
	$OutputDescription_["Vehicle", "addHealth"] = "[health]" NL
																								"Increases this vehicle's health." NL
																								"health: Amount to add (<0 damages)";
	$OutputDescription_["Vehicle", "setHealth"] = "[health]" NL
																								"Sets this vehicle's health." NL
																								"health (0 - 10000): Health to set to (0 destroys)";
	$OutputDescription_["Vehicle", "setVelocity"] = "[velocity]" NL
																							 		"Sets this vehicle's velocity, removing all momentum." NL
																							 		"velocity (-200 - 200): Velocity to set to (Y is north)";
	$OutputDescription_["Vehicle", "addVelocity"] = "[velocity]" NL
																							 		"Increases this vehicle's velocity." NL
																							 		"velocity (-200 - 200): Velocity to give (Y is north)";
	$OutputDescription_["Vehicle", "setVehicleScale"] = "[scale]" NL
																							 				"Sets this vehicle's scale." NL
																							 				"scale (0.2 - 2): Scale to set to";
	$OutputDescription_["Vehicle", "setColor"] = "[color]" NL
																							 "Sets this vehicle's color." NL
																							 "color: Colorset color to use";
	$OutputDescription_["Vehicle", "setShapeName"] = "[name]" NL
																									 "Changes this vehicle's overhead name." NL
																									 "name (40): Self explanatory";
	$OutputDescription_["Vehicle", "setShapeNameColor"] = "[color]" NL
																												"Sets this vehicle's overhead name color." NL
																												"color: Colorset color to use";
	$OutputDescription_["Vehicle", "setShapeNameDistance"] = "[distance]" NL
																													 "Sets this vehicle's max overhead name render distance." NL
																													 "distance (0 - 3000): Self explanatory";
	$OutputDescription_["Vehicle", "unmountDriver"] = "Forces this vehicle's driver to dismount";
	$OutputDescription_["Vehicle", "unmountPlayer"] = "[seat] [all]" NL
																										"Forces this vehicle's users to dismount" NL
																										"seat (1 - 32): Seat to dismount players from" NL
																										"all: Dismounts all mounted players";
	$OutputDescription_["Vehicle", "toggleWheel"] = "[wheel] [enable]" NL
																									"Toggles this vehicle's wheels" NL
																									"wheel (1 - 12): Tire to toggle" NL
																									"enable: Self explanatory";
	$OutputDescription_["Vehicle", "spawnExplosion"] = "[explosion] [size]" NL
																										 "Spawns an explosion on this vehicle." NL
																										 "explosion: Self explanatory" NL
																										 "size (0.2 - 2): Self explanatory";
	$OutputDescription_["Vehicle", "spawnProjectile"] = "[speed] [projectile] [spread] [size]" NL
																											"Spawns a projectile from this vehicle's center." NL
																											"speed (-100 - 100): Self explanatory" NL
																											"projectile: Self explanatory" NL
																											"spread (-200 - 200): Randomized extra velocity" NL
																											"size (0.2 - 2): Self explanatory";

	// == event_vehiclenames == //

	$OutputDescription_["fxDTSBrick", "setVehicleName"] = "[name]" NL
																												"Changes this brick's attached vehicle's overhead name." NL
																												"name (30): Self explanatory";

	$OutputDescription_["fxDTSBrick", "setVehicleNameColor"] = "[r] [g] [b]" NL
																															"Changes this brick's attached vehicle's overhead name color." NL
																															"r, g, b (0 - 255): Self explanatory";

	// == event_waterbrickevents == //

	$InputDescription_["onBotEnterWater"] = "Triggered when a bot enters this water brick.";
	$InputDescription_["onBotInWater"] = "Repeatedly triggers when a bot is inside this water brick.";
	$InputDescription_["onPlayerEnterWater"] = "Triggered when a player enters this water brick.";
	$InputDescription_["onPlayerInWater"] = "Repeatedly triggers when a player is inside this water brick.";

	// == event_zones == //

	$InputDescription_["onVehicleEnterZone"] = "Triggered when a vehicle enters this zone brick.";
	$InputDescription_["onVehicleLeaveZone"] = "Triggered when a vehicle exits this zone brick.";

	$InputDescription_["onPlayerEnterZone"] = "Triggered when a player enters this zone brick.";
	$InputDescription_["onPlayerLeaveZone"] = "Triggered when a player exits this zone brick.";

	$InputDescription_["onBotEnterZone"] = "Triggered when a bot enters this zone brick.";
	$InputDescription_["onBotLeaveZone"] = "Triggered when a bot exits this zone brick.";

	$InputDescription_["onInZone"] = "Repeatedly triggers when a player is inside this zone brick.";

	// == gamemode_slayer == //
	
	$InputDescription_["onCPCapture"] = "Triggered when a player captures this point.";
	$InputDescription_["onCPReset"] = "Triggered when this point's team gets reset.";

	$InputDescription_["onMinigameRoundStart"] = "Triggered when this brick's owner's minigame begins a new round.";
	$InputDescription_["onMinigameRoundEnd"] = "Triggered when this brick's owner's minigame's current round ends.";

	$OutputDescription_["fxDtsBrick", "setTeamControl"] = "[color]" NL
																												"Gives control of this brick to a specific color team." NL
																												"This prevents enemies from triggering this brick's events." NL
																												"color: Color of team to give control to";

	$OutputDescription_["fxDtsBrick", "setTeamControlLocked"] = "[mode] [color] [lock]" NL
																															"Sets this brick's color lock state." NL
																															"mode, color, lock:" NL
																															"  TriggerTeam: apply lock state to the triggering player's team" NL
																															"  TeamColor: apply lock state to the selected color team" NL
																															"  ALL: apply lock state to all teams";

	$OutputDescription_["GameConnection", "addLives"] = "[count]" NL
																											"Grants this client more lives." NL
																											"count (0 - 200): Self explanatory";
	$OutputDescription_["GameConnection", "addDeaths"] = "[count]" NL
																											 "Grants this client more deaths." NL
																											 "count (0 - 200): Self explanatory";
	$OutputDescription_["GameConnection", "addKills"] = "[count]" NL
																											"Grants this client more kills." NL
																											"count (0 - 200): Self explanatory";
																											
	$OutputDescription_["GameConnection", "setLives"] = "[count]" NL
																											"Sets this client's life count." NL
																											"count (0 - 200): Self explanatory";
	$OutputDescription_["GameConnection", "setDeaths"] = "[count]" NL
																											 "Sets this client's death count." NL
																											 "count (0 - 200): Self explanatory";
	$OutputDescription_["GameConnection", "setKills"] = "[count]" NL
																											"Sets this client's kill count." NL
																											"count (0 - 200): Self explanatory";

	$OutputDescription_["GameConnection", "joinTeam"] = "[name] [reason] [despawn]" NL
																											"Sets this client's team." NL
																											"name: Name of a team to join" NL
																											"reason: Optional message to display" NL
																											"despawn: Disables respawning after switching";

	$OutputDescription_["Minigame", "incTimeRemaining"] = "[time] [warn]" NL
																												"Increases this minigame's timer." NL
																												"time (-999 - 999): Time to add (<0 shortens game)" NL
																												"warn: Displays a message with the time remaining";

	$OutputDescription_["Minigame", "setTimeRemaining"] = "[time] [warn]" NL
																												"Sets this minigame's timer." NL
																												"time (1 - 999): Time to set to" NL
																												"warn: Displays a message with the time remaining";

	$OutputDescription_["Minigame", "Win"] = "[mode] [custom]" NL
																					 "Ends the round and grants a win to a team." NL
																					 "mode, custom:" NL
																					 "  TriggerPlayer: grant the triggering player a win" NL
																					 "  TriggerTeam: grant the triggering player's team a win" NL
																					 "  CustomPlayer: grant a specific player a win" NL
																					 "  CustomTeam: grant a specific team a win" NL
																					 "  CustomString: grant nobody a win but show custom as winner";

	// $OutputDescription_["Slayer_TeamSO", ] // todo

	// == gamemode_slayer_ctf == //

	$InputDescription_["onFlagPickedUp"] = "Triggered when a player picks up this brick's attached flag.";
	$InputDescription_["onFlagDropped"] = "Triggered when a player drops this brick's attached flag.";
	$InputDescription_["onFlagReturned"] = "Triggered when a player captures this brick's attached flag.";
	$InputDescription_["onFlagRecovered"] = "Triggered when a player recovers this brick's attached flag.";

	$OutputDescription_["Player", "dropFlag"] = "Forces this player to drop their held flag.";
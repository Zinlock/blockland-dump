$hvl = 2000;

function highVehicleLimit()
{
	$Max::MaxPhysVehicles_Total = $hvl;
	$Server::MaxPhysVehicles_Total = $hvl;
	$Server::Quota::Vehicle = $hvl;

	$Max::MaxPlayerVehicles_Total = $hvl;
	$Server::MaxPlayerVehicles_Total = $hvl;
	$Server::Quota::Player = $hvl;
}

schedule(0, 0, highVehicleLimit);
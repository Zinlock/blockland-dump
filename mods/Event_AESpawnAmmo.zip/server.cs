registerOutputEvent(fxDtsBrick, AESpawnAmmo, "vector 200", 1);

function fxDtsBrick::AESpawnAmmo(%brk, %dir, %src)
{
	if(!isObject(%itm = %brk.item))
		return;
	
	%idb = %itm.getDatablock();

	if(!%idb.aebase || !isObject(%idb.aetype))
		return;
	
	%ray = %brk.isRayCasting();
	
	%brk.setRayCasting(1);
	%brk.spawnItem(%dir, %idb.aetype, %src);
	%brk.setRayCasting(%ray);
}
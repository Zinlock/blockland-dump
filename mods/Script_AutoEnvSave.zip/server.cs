$aesEnvzones = false;

if(!isPackage(Server_Autosaver))
{
	if(forceRequiredAddOn("Support_AutoSaver") == $Error::AddOn_NotFound)
	{
		error("Script_AutoEnvSave error: Missing required Add-On Support_AutoSaver");
		return;
	}
}

if(isFile("Add-Ons/Server_EnvironmentZones/server.cs") && isFunction(NetObject, setNetFlag) && $AddOn__Server_EnvironmentZones)
	$aesEnvzones = true;

package AutoEnvSave
{
	function Autosaver_Save(%file)
	{
		Parent::Autosaver_Save(%file);

		%save = $Server::AS["RelatedBrickCount"] && !$Pref::Server::AS_["SaveRelatedBrickcount"];

		if(!%save)
		{
			%dir = $Pref::Server::AS_["Directory"];
		
			if($Server::AS["SaveName"] !$= "")
				%direc2 = %dir @ $Server::AS["SaveName"] @ ".env";
			else
				%direc2 = %dir @ "Autosave.env";

			messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Saved global environment.");
			saveEnvironment(%direc2);

			if($aesEnvzones)
			{
				if($Server::AS["SaveName"] !$= "")
					%direc = %dir @ $Server::AS["SaveName"] @ ".ez";
				else
					%direc = %dir @ "Autosave.ez";
				
			if(EnvironmentZoneGroup.getCount() > 0 && exportEnvironmentZones(%direc))
					messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Saved " @ EnvironmentZoneGroup.getCount() @ " env zones.");
			}
		}
		else
			messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Canceled environment autosave.");
	}

	function loadAutoSave(%name, %bl_id, %desc)
	{
		Parent::loadAutoSave(%name, %bl_id, %desc);

		EnvAutoLoadCheck(%name, false);
	}
};
activatePackage(AutoEnvSave);

function EnvAutoLoadCheck(%name, %force)
{
	cancel($aeswait);
	
	%load = false;

	if(clientGroup.getCount() > 0)
	{
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
			if(clientGroup.getObject(%i).hasSpawnedOnce)
			{
				%load = true;
				break;
			}
		}

		if(%load && !%force)
		{
			schedule(2000, 0, EnvAutoLoadCheck, %name, true);
		}
		else if(%load && %force)
		{
			$aeswarned = false;
			
			if(%name $= "last" && $Autosaver::Pref["LastAutoSave"] !$= "")
				%path2 = $Pref::Server::AS_["Directory"] @ $Autosaver::Pref["LastAutoSave"] @ ".env";
			else
				%path2 = $Pref::Server::AS_["Directory"] @ %name @ ".env";

			%envFile = %path2;
			if(isFile(%envFile))
			{
				%res = GameModeGuiServer::ParseGameModeFile(%envFile, 1);
					
				EnvGuiServer::getIdxFromFilenames();
				EnvGuiServer::SetSimpleMode();

				if(!$EnvGuiServer::SimpleMode)     
				{
					EnvGuiServer::fillAdvancedVarsFromSimple();
					EnvGuiServer::SetAdvancedMode();
				}
			}

			if(%res)
				messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Loaded global environment.");
			
			if($aesEnvzones)
			{
				if(%name $= "last" && $Autosaver::Pref["LastAutoSave"] !$= "")
					%path = $Pref::Server::AS_["Directory"] @ $Autosaver::Pref["LastAutoSave"] @ ".ez";
				else
					%path = $Pref::Server::AS_["Directory"] @ %name @ ".ez";
				
				showEnvironmentZones(1);
				if(loadEnvironmentZones(%path))
					messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Loaded " @ EnvironmentZoneGroup.getCount() @ " env zones.");
			}
			
			return;
		}
	}
	
	if(!%load)
	{
		if(!$aeswarned)
		{
			$aeswarned = true;
			messageAll('', "<color:FFFFFF>[<spush>\c0!<spop>] Waiting for players to load environment...");
			echo("  - Couldn't load environment: no players in world");
		}

		$aeswait = schedule(1000, 0, EnvAutoLoadCheck, %name);
	}
}
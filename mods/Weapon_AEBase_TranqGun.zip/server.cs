if(ForceRequiredAddOn("Weapon_AEBase") == $Error::AddOn_NotFound)
{
	//we don't have the base, so we're screwed =(
	error("ERROR: AEBase_TranqGun - required add-on Weapon_AEBase not found");
	return;
}

if(ForceRequiredAddOn("Emote_Snore") == $Error::AddOn_NotFound)
{
	//we don't have the base, so we're screwed =(
	error("ERROR: AEBase_TranqGun - required add-on Emote_Snore not found");
	return;
}

// AMMO ITEM //

datablock ItemData(AE_TranqPAmmoItem : AE_AmmoItem)
{
	shapeFile = "./tranq_darts.dts";
	uiName = "A: Tranquilizer Darts";
	AEAmmo = "Tranq Darts";
	AEMax = 18;
	AERefill = 3;

	colorShiftColor = "0.45 0.5 0.6 1";
};

// SOUNDS //

datablock AudioProfile(xTranqPistolFireSound)
{
   filename    = "./tranq_fire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(xTranqPistolExtractSound)
{
   filename    = "./reload_out.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(xTranqPistolInsertSound)
{
   filename    = "./reload_in.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(xTranqPistolCloseSound)
{
   filename    = "./reload_close.wav";
   description = AudioClosest3d;
   preload = true;
};

// VOID CUBE //

datablock StaticShapeData(xTranqVoidShapeData)
{
	shapeFile = "./void.dts";
};

// TRANQ PROJECTILE //

datablock ProjectileData(xTranqProjectile : AEProjectile)
{
	projectileShapeName = "base/data/shapes/empty.dts";
	directDamage        = 0;

	brickExplosionRadius = 0;
	brickExplosionImpact = false;          //destroy a brick if we hit it directly?
	brickExplosionForce  = 0;
	brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
	brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground

	impactImpulse         = 0;
	verticalImpulse     = 100;

	muzzleVelocity      = 140;
	velInheritFactor    = 0;

	armingDelay         = 0;
	lifetime            = 6000;
	fadeDelay           = 5500;
	isBallistic         = true;
	gravityMod = 0.5;
};

function xTranqProjectile::onCollision(%this, %obj, %col, %fade, %pos, %normal, %velocity)
{
	Parent::onCollision(%this, %obj, %col, %fade, %pos, %normal, %velocity);
	
	if(!isObject(%col))
		return;

	%cn = %col.getClassName();
	if(%cn !$= "Player" && %cn !$= "AIPlayer")
	{
		if(getRandom() > 0.75)
			serverPlay3D(RallyImpact @ getRandom(1,4) @ Sound, %pos);
	}
}

$xt_DamageWake = true; // wake up on damage
$xt_ClickWake = true; // wake up on spam click
$xt_VelocityWake = 15; // wake up on push

$xt_StunTime = 8; // how long to sleep for
$xt_StunTimeAdd = 6; // how much longer to sleep after getting shot again
$xt_StunTimeMax = 16; // max time to sleep for

$xt_StunDelayBody = 10; // delay before falling asleep on bodyshots
$xt_StunDelayHead = 0; // delay before falling asleep on headshots
$xt_StunDelaySlow = 0.5; // slow movement during delay

function xTranqProjectile::Damage(%this, %obj, %col, %fade, %pos, %normal)
{
	if(!isObject(%col))
		return;
	
	if(%col.IsA("WheeledVehicle") || %col.IsA("FlyingVehicle"))
		return;
	
	%headshot = (ae_calculateDamagePosition(%col, %pos) $= "head");
	
	if(getSimTime() - %col.lastImpactSound > 300)
	{
		serverPlay3D(AEBodyshot @ getRandom(1,3) @ Sound, %pos);
		%col.lastImpactSound = getSimTime();
	}

	%col.xTranqStun(%headshot);
}

function Player::xTranqStun(%pl, %head)
{	
	%pl.playThread(2, plant);
	if(isEventPending(%pl.xs))
		%timeout = getTimeRemaining(%pl.xs);
	cancel(%pl.xs);

	if(!%pl.xAsleep)
	{
		%pl.rex_stun = $xt_StunDelaySlow;
		%pl.aeUpdateSpeed();

		if(%timeout !$= "" && !($xt_StunDelayHead <= 0 && %head || $xt_StunDelayBody <= 0 && !%head))
			%delay = %timeout / 2;
		else
		{
			if(%head)
				%delay = $xt_StunDelayHead * 1000;
			else
				%delay = $xt_StunDelayBody * 1000;
		}
		
		%pl.xs = %pl.schedule(%delay, xTranqSleepLoop);
		%pl.xsDelay = %delay;
		if(!%pl.IsA("AIPlayer"))
			%pl.xTranqFadeLoop();
	}
	else
	{
		%max = $xt_StunTimeMax * 1000;
		%pl.xSleepTimeout += $xt_StunTimeAdd * 1000;

		if(!%pl.IsA("AIPlayer"))
			%pl.Client.camera.setDamageFlash(0.5);

		if(%pl.xSleepTimeout - getSimTime() > %max)
			%pl.xSleepTimeout = getSimTime() + %max;
	}
}

function Player::xTranqFadeLoop(%pl)
{
	cancel(%pl.xfl);

	%cl = %pl.client;

	if(%pl.getDamageLevel() >= 1.0 || %pl.xAsleep || !isEventPending(%pl.xs))
		return;
	
	%flash = 0.7 - (getTimeRemaining(%pl.xs) / %pl.xsDelay);
	%pl.setDamageFlash(%flash);
	
	%pl.xfl = %pl.schedule(100, xTranqFadeLoop);
}

function Player::xTranqSleepLoop(%pl)
{
	cancel(%pl.xsl);

	%cl = %pl.client;

	if(%pl.getDamagePercent() >= 1.0)
	{
		if(!%pl.IsA("AIPlayer"))
		{
			%cl.dummyCamera.delete();
			%cl.camera.setControlObject(%cl.camera);
			%cl.camera.setMode("Corpse", %pl);
			%cl.setControlObject(%cl.camera);
		}

		return;
	}

	if(!%pl.xAsleep)
	{
		%pl.rex_stun = "";
		%pl.xAsleep = true;
		%pl.xSleepTimeout = getSimTime() + $xt_StunTime * 1000;
		%pl.playThread(1, jump);
		%pl.schedule(100, playThread, 1, sit);

		if(!%pl.IsA("AIPlayer"))
		{
			%dCam = new Camera(){datablock = Observer;};
			%cam = %cl.camera;
			%cl.dummyCamera = %dCam;
			%dCam.scopeToClient(%cl);

			if (!isObject(xVoidCube))
			{
				new StaticShape(xVoidCube)
				{
					datablock = xTranqVoidShapeData;
					scale = "1 1 1";
					position = "0 0 -1000";
				};
				xVoidCube.setNodeColor("ALL", "0 0 0 1");
			}

			%cam.setTransform("0 0 -1000");
			%cam.setFlyMode();
			%cam.setDamageFlash(0.8);
			%cam.mode = "Observer";
			%cl.setControlObject(%cam);
			%cam.setControlObject(%dCam);
		}
		else if(%pl.hLoopActive)
		{
			%pl.xActive = true;
			%pl.stopHoleLoop();
		}
	}
	else
	{
		if(getSimTime() > %pl.xSleepTimeout || vectorLen(%pl.getVelocity()) >= $xt_VelocityWake)
		{
			%pl.xTranqWake();
			return;
		}
		else
		{
			if(!%pl.IsA("AIPlayer"))
				%cl.centerPrint("<font:impact:24>\c7You are unconscious...<br>\c7You will wake up in \c2" @ mCeil((%pl.xSleepTimeout - getSimTime()) / 1000) @ "\c7 seconds.", 2);

			if(getSimTime() - %pl.lastSleepFxTime > 4000)
			{
				%pl.lastSleepFxTime = getSimTime();
				%pl.mountImage(snoreImage, 3);
			}
		}
	}

	%pl.xsl = %pl.schedule(100, xTranqSleepLoop);
}

function Player::xTranqWake(%pl)
{
	cancel(%pl.xsl);
	cancel(%pl.xfl);
	cancel(%pl.xs);

	%cl = %pl.Client;

	%pl.xAsleep = false;
	%pl.playThread(1, root);
	%pl.playThread(2, undo);
	%pl.rex_stun = "";
	%pl.aeUpdateSpeed();
	%pl.xSleepTimeout = 0;

	if(%pl.getMountedImage(0).armReady)
		%pl.playThread(1, armReadyRight);

	if(!%pl.IsA("AIPlayer"))
	{
		%pl.setWhiteout(0.7);
		%cl.dummyCamera.delete();
		%cl.setControlObject(%pl);
		%cl.centerPrint();
	}
	else if(%pl.xActive && !%pl.hLoopActive)
		%pl.startHoleLoop();
}

// SLEEP PACKAGE //

package xTranqPackage
{
	function Armor::damage(%db, %pl, %src, %pos, %dmg, %type)
	{
		if(%pl.xAsleep && $xt_DamageWake && %dmg > 1)
			%pl.xTranqWake();
			
		return Parent::damage(%db, %pl, %src, %pos, %dmg, %type);
	}

	function Player::activateStuff(%pl)
	{
		%p = Parent::activateStuff(%pl);
		
		if(%pl.activatelevel >= 5 && $xt_ClickWake)
		{
			%dir = %pl.getEyeVector();
			%pos = %pl.getEyePoint();
			%dist = 6;
			%vec = VectorScale(%dir, %dist);
			%end = VectorAdd(%pos, %vec);
			%mask = $TypeMasks::PlayerObjectType  |
							$TypeMasks::fxBrickObjectType |
							$TypeMasks::VehicleObjectType |
							$TypeMasks::StaticObjectType;
			%ray = containerRayCast(%pos, %end, %mask, %pl);

			if(%ray && (%ray.IsA("Player") || %ray.IsA("AIPlayer")) && %ray.xAsleep)
				%ray.xTranqWake();
		}

		return %p;
	}

	function serverCmdUseTool(%cl, %id)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdUseTool(%cl, %id);
	}

	function serverCmdUnuseTool(%cl, %id)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdUnuseTool(%cl, %id);
	}

	function serverCmdDropTool(%cl, %id)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdDropTool(%cl, %id);
	}
	
	function serverCmdAlarm(%cl)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdAlarm(%cl);
	}
	
	function serverCmdSit(%cl)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdSit(%cl);
	}

	function serverCmdActivateStuff(%cl)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdActivateStuff(%cl);
	}
	
	function serverCmdStartTalking(%cl)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdStartTalking(%cl);
	}

	function serverCmdSuicide(%cl)
	{
		if(%cl.Player.xAsleep)
			return;
		
		return Parent::serverCmdSuicide(%cl);
	}

	function serverCmdMessageSent(%cl, %msg)
	{
		if(%cl.Player.xAsleep)
			return messageClient(%cl, '', "\c7Can't talk while asleep...");
		
		return Parent::serverCmdMessageSent(%cl, %msg);
	}
	
	function serverCmdTeamMessageSent(%cl, %msg)
	{
		if(%cl.Player.xAsleep)
			return messageClient(%cl, '', "\c7Can't talk while asleep...");
		
		return Parent::serverCmdTeamMessageSent(%cl, %msg);
	}
};
activatePackage(xTranqPackage);

// TRANQ ITEM //

datablock ItemData(xTranqPistolItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./tranq.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Tranquilizer Pistol";
	iconName = "./tranq_ico";
	doColorShift = true;
	colorShiftColor = "0.35 0.4 0.5 1";

	 // Dynamic properties defined by the scripts
	image = xTranqPistolImage;
	canDrop = true;

	AEAmmo = 1;
	AEType = AE_TranqPAmmoItem.getID();
	AEBase = 1;

	RPM = 60;
	recoil = "Low";
	uiColor = "1 1 1";
	description = "The tranquilizer pistol is a quiet gun capable of harmlessly neutralizing enemies.";

	useImpactSounds = true;
	softImpactThreshold = 2;
	softImpactSound = "AEWepImpactSoft1Sound AEWepImpactSoft2Sound AEWepImpactSoft3Sound";
	hardImpactThreshold = 8;
	hardImpactSound = "AEWepImpactHard1Sound AEWepImpactHard2Sound AEWepImpactHard3Sound";
};

// TRANQ IMAGE //

datablock ShapeBaseImageData(xTranqPistolImage)
{
   // Basic Item properties
   shapeFile = "./tranq.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0 0 0";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = xTranqPistolItem;
   ammo = " ";
   projectile = xTranqProjectile;
   projectileType = Projectile;

   casing = "";
   shellExitDir        = "-1 0 0.5";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 25;
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
	melee = false;
   //raise your arm up or not
	armReady = true;
	hideHands = false;
	safetyImage = "";
  scopingImage = xTranqPistolIronsightImage;
	doColorShift = true;
	colorShiftColor = xTranqPistolItem.colorShiftColor;//"0.400 0.196 0 1.000";
	R_MovePenalty = 1.0;

	muzzleFlashScale = "0 0 0";
	bulletScale = "1 1 1";

	projectileDamage = 0;
	projectileCount = 1;
	projectileHeadshotMult = 1;
	projectileVelocity = 165;
	projectileTagStrength = 0.0;  // tagging strength
	projectileTagRecovery = 0.0; // tagging decay rate

	recoilHeight = 0;
	recoilWidth = 0;
	recoilWidthMax = 0;
	recoilHeightMax = 0;

	spreadBurst = 1; // how much shots it takes to trigger spread i think
	spreadReset = 150; // m
	spreadBase = 10;
	spreadMin = 10;
	spreadMax = 10;

	screenshakeMin = "0.05 0.05 0.05";
	screenshakeMax = "0.1 0.1 0.1"; //trollface

	farShotSound = "";
	farShotDistance = 0;

	sonicWhizz = false;
	whizzSupersonic = 0;
	whizzThrough = false;
	whizzDistance = 14;
	whizzChance = 100;
	whizzAngle = 80;

	staticHitscan = false;

	stateName[0]                     	= "Activate";
	stateTimeoutValue[0]             	= 0.01;
	stateTransitionOnTimeout[0]       	= "LoadCheckA";
	stateSequence[0]			= "root";

	stateName[1]                     	= "Ready";
	stateScript[1]				= "onReady";
	stateTransitionOnNotLoaded[1]     = "Empty";
	stateTransitionOnNoAmmo[1]       	= "Reload";
	stateTransitionOnTriggerDown[1]  	= "preFire";
	stateAllowImageChange[1]         	= true;

	stateName[2]                       = "preFire";
	stateTransitionOnTimeout[2]        = "Fire";
	stateScript[2]                     = "AEOnFire";
	stateFire[2]                       = true;

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "SemiAutoCheck";
	stateEmitter[3]					= AEBaseSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateTimeoutValue[3]             	= 0.25;
	stateEmitterNode[3]				= "muzzlePoint";
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateWaitForTimeout[3]			= true;

	stateName[5]				= "LoadCheckA";
	stateScript[5]				= "AEMagLoadCheck";
	stateTimeoutValue[5]			= 0.1;
	stateTransitionOnTimeout[5]		= "LoadCheckB";

	stateName[6]				= "LoadCheckB";
	stateTransitionOnAmmo[6]		= "Ready";
	stateTransitionOnNotLoaded[6] = "Empty";
	stateTransitionOnNoAmmo[6]		= "Reload";

	stateName[7]				= "Reload";
	stateTimeoutValue[7]			= 0.35;
	stateScript[7]				= "onReloadStart";
	stateTransitionOnTimeout[7]		= "ReloadWait";
	stateWaitForTimeout[7]			= true;
	stateSequence[7]			= "ReloadStart";
	stateSound[7]				= xTranqPistolExtractSound;

	stateName[8]				= "ReloadWait";
	stateScript[8]				= "onReloadWait";
	stateTimeoutValue[8]			= 0.125;
	stateTransitionOnTimeout[8]		= "ReloadInsert";

	stateName[9]				= "ReloadInsert";
	stateTimeoutValue[9]			= 0.5;
	stateScript[9]				= "onReloadInsert";
	stateTransitionOnTimeout[9]		= "ReloadEnd";
	stateWaitForTimeout[9]			= true;
	stateSequence[9]			= "magIn";
	stateSound[9]				= xTranqPistolInsertSound;

	stateName[10]				= "ReloadEnd";
	stateTimeoutValue[10]			= 0.35;
	stateScript[10]				= "onReloadEnd";
	stateTransitionOnTimeout[10]		= "Ready";
	stateWaitForTimeout[10]			= true;
	stateSequence[10]			= "ReloadEnd";
	stateSound[10]				= xTranqPistolCloseSound;

	stateName[11]				= "FireLoadCheckA";
	stateScript[11]				= "AEMagLoadCheck";
	stateTimeoutValue[11]			= 0.1;
	stateTransitionOnTimeout[11]		= "FireLoadCheckB";

	stateName[12]				= "FireLoadCheckB";
	stateTransitionOnNoAmmo[12]		= "Reload";
	stateTransitionOnAmmo[12]  = "Ready";
	stateTransitionOnNotLoaded[12]  = "Ready";

	stateName[14]				= "Reloaded";
	stateTimeoutValue[14]			= 0.1;
	stateScript[14]				= "AEMagReloadAll";
	stateTransitionOnTimeout[14]		= "Ready";

	stateName[20]				= "ReadyLoop";
	stateTransitionOnTimeout[20]		= "Ready";

	stateName[21]          = "Empty";
	stateTransitionOnTriggerDown[21]  = "Dryfire";
	stateTransitionOnLoaded[21] = "Reload";
	stateScript[21]        = "AEOnEmpty";

	stateName[22]           = "Dryfire";
	stateTransitionOnTriggerUp[22] = "Empty";
	stateWaitForTimeout[22]    = false;
	stateScript[22]      = "onDryFire";
	
	stateName[23]           = "SemiAutoCheck";
	stateTransitionOnTriggerUp[23]	  	= "FireLoadCheckA";
};

// TRANQ IMAGE FUNCTIONS //

function xTranqPistolImage::AEOnFire(%this,%obj,%slot)
{
	%obj.stopAudio(0);
  %obj.playAudio(0, xTranqPistolFireSound);

	Parent::AEOnFire(%this, %obj, %slot);
}

function xTranqPistolImage::onDryFire(%this, %obj, %slot)
{
	%obj.aeplayThread(2, plant);
	serverPlay3D(AEDryFireSound, %obj.getHackPosition());
}

function xTranqPistolImage::AEOnLowClimb(%this, %obj, %slot)
{
   %obj.aeplayThread(2, shiftLeft);
	 %obj.aeplayThread(3, shiftRight);
}

function xTranqPistolImage::onReloadInsert(%this,%obj,%slot)
{
  %obj.schedule(50, "aeplayThread", "2", "plant");
  %obj.schedule(550, "aeplayThread", "3", "shiftright");
}

function xTranqPistolImage::onReloadEnd(%this,%obj,%slot)
{
	Parent::AEMagReloadAll(%this, %obj, %slot);
}

function xTranqPistolImage::onReloadStart(%this,%obj,%slot)
{
   %obj.aeplayThread(2, shiftLeft);
}

function xTranqPistolImage::onReady(%this,%obj,%slot)
{
	%obj.baadDisplayAmmo(%this);

	if(getSimTime() - %obj.reloadTime[%this.getID()] <= %this.stateTimeoutValue[0] * 1000 + 1000)
		%obj.schedule(0, setImageAmmo, %slot, 0);
}

function xTranqPistolImage::onMount(%this,%obj,%slot)
{
	%obj.aeplayThread(2, plant);
	%this.AEMountSetup(%obj, %slot);
	parent::onMount(%this,%obj,%slot);
}

function xTranqPistolImage::onUnMount(%this,%obj,%slot)
{
	%this.AEUnmountCleanup(%obj, %slot);
	parent::onUnMount(%this,%obj,%slot);
}

// TRANQ ADS IMAGE //

datablock ShapeBaseImageData(xTranqPistolIronsightImage : xTranqPistolImage)
{
	recoilHeight = 0;
	spreadBase = 0;
	spreadMin = 0;
	spreadMax = 0;

	scopingImage = xTranqPistolImage;
	sourceImage = xTranqPistolImage;

	isScopedImage = false;

	offset = "0 0 0";
	eyeOffset = "0 0.55 -0.6001";
	rotation = eulerToMatrix( "0 -20 0" );

	desiredFOV = 75;
	projectileZOffset = 0;
	R_MovePenalty = 0.8;

	stateName[7]				= "Reload";
	stateScript[7]				= "onDone";
	stateTimeoutValue[7]			= 1;
	stateTransitionOnTimeout[7]		= "";
	stateSound[7]				= "";
};

// TRANQ ADS FUNCTIONS //

function xTranqPistolIronsightImage::onDone(%this,%obj,%slot)
{
	%obj.reloadTime[%this.sourceImage.getID()] = getSimTime();
	%obj.mountImage(%this.sourceImage, 0);
}

function xTranqPistolIronsightImage::onReady(%this,%obj,%slot)
{
	%obj.baadDisplayAmmo(%this);
}

function xTranqPistolIronsightImage::AEOnFire(%this,%obj,%slot)
{
	%obj.stopAudio(0);
  %obj.playAudio(0, xTranqPistolFireSound);

	Parent::AEOnFire(%this, %obj, %slot);
}

function xTranqPistolIronsightImage::onDryFire(%this, %obj, %slot)
{
	%obj.aeplayThread(2, plant);
	serverPlay3D(AEDryFireSound, %obj.getHackPosition());
}

function xTranqPistolIronsightImage::onMount(%this,%obj,%slot)
{
	%obj.aeplayThread(2, plant);
	if(isObject(%obj.client) && %obj.client.IsA("GameConnection"))
		%obj.client.play2D(AEAdsIn3Sound, %obj.getHackPosition());
	%this.AEMountSetup(%obj, %slot);
	parent::onMount(%this,%obj,%slot);
}

function xTranqPistolIronsightImage::onUnMount(%this,%obj,%slot)
{
	if(isObject(%obj.client) && %obj.client.IsA("GameConnection"))
		%obj.client.play2D(AEAdsOut3Sound, %obj.getHackPosition());
	%this.AEUnmountCleanup(%obj, %slot);
	parent::onUnMount(%this,%obj,%slot);
}
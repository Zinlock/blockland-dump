$SB_Timeout = 8000;
$SB_Start = 0;
$SB_SendBuffer = "";
$SB_Disable = false;

$SB_Trim = true;

package SaveBoosterClient
{
	function LoadBricks_ClientServerCheck (%filename, %colorMethod)
	{
		if (!isFile (%filename) || ServerConnection.isLocal())
			return Parent::LoadBricks_ClientServerCheck(%filename, %colorMethod);

		%path = filePath (%filename);

		if (strlen (%path) - strlen ("saves/") > 0)
			%dirName = getSubStr (%path, strlen ("saves/"), strlen (%path) - strlen ("saves/"));
		else 
			%dirName = 0;
		
		%ownership = 0;
		if (LoadBricksGui_SavedOwner.getValue ())
			%ownership = 1;
		else if (LoadBricksGui_Public.getValue ())
			%ownership = 2;

		if(!$SB_Disable)
		{
			$SB_Start = getSimTime();
			$SB_SendBuffer = "";

			$LoadingBricks_FileName = %filename;
			commandToServer ('SetColorMethod', %colorMethod);
			commandToServer ('SetSaveUploadDirName', %dirName, %ownership);
			SB_ClientStartLoad(%filename);
		}
		else
		{
			$SB_Start = 0;
			cancel($SB_Cancel);
			return Parent::LoadBricks_ClientServerCheck(%filename, %colorMethod);
		}
	}

	function disconnectedCleanup(%rec)
	{
		if(isObject($SB_LoadFileObj))
		{
			$SB_LoadFileObj.close();
			$SB_LoadFileObj.delete();
		}

		$SB_Start = 0;
		$SB_Trim = true;
		$SB_SendBuffer = "";

		cancel($SB_Cancel);

		return Parent::disconnectedCleanup(%rec);
	}
};
activatePackage(SaveBoosterClient);

function SB_ClientStartLoad(%file)
{
	$SB_LoadFileObj = new FileObject();
	$SB_LoadFileObj.openForRead(%file);
	Progress_Bar.total = 0;
	Progress_Bar.count = 0;
	$SB_Start = getSimTime();
	$SB_SendBuffer = "";
	cancel($SB_Cancel);
	SB_ClientLoadTick();
}

function SB_ClientLoadTick()
{
	if (isEventPending ($UploadSaveFile_Tick_Schedule))
		cancel ($UploadSaveFile_Tick_Schedule);
	
	if (!isObject ($SB_LoadFileObj))
		return;
	
	%lines = 0;

	for(%i = 0; %i < 3; %i++) // 3 iterations actually seems to make it faster, though it makes all other client commands very laggy until the server receives everything
	{
		if($SB_SendBuffer !$= "")
		{
			%buff = $SB_SendBuffer;
			$SB_SendBuffer = "";
		}
		else
			%buff = "";
			
		while(!$SB_LoadFileObj.isEOF())
		{
			%line = $SB_LoadFileObj.readLine ();
			%len = strlen(%line);

			if (Progress_Bar.total == 0)
			{
				%firstWord = getWord (%line, 0);
				if (%firstWord $= "Linecount")
				{
					%lineCount = getWord (%line, 1);
					Canvas.pushDialog (ProgressGui);
					Progress_Window.setText ("Loading Progress");
					Progress_Bar.setValue (0);
					Progress_Bar.total = %lineCount;
					Progress_Bar.count = 0;
					Progress_Text.setText ("Uploading...");
				}
			}
			else
			{
				%prefix = getSubStr (%line, 0, 2);
				if (%prefix !$= "+-")
				{
					Progress_Bar.count += 1;
					Progress_Bar.setValue (Progress_Bar.count / Progress_Bar.total);
				}
			}

			if(strlen(%buff) + %len < 255)
			{
				%buff = %buff NL %line;
			}
			else
			{
				$SB_SendBuffer = %line;
				break;
			}

			if($SB_Trim)
			{
				$SB_Trim = false;
				%buff = trim(%buff);
			}
		}

		commandToServer('UploadSaveFileLine', %buff);

		%lines += getRecordCount(%buff);

		if($SB_LoadFileObj.isEOF())
			break;
	}
	
	%time = (getSimTime() - $SB_Start) / 1000;

	Progress_Text.setText ("Uploading... (" @ mFloatLength(Progress_Bar.count / Progress_Bar.total * 100, 1) @ "%, " @ Progress_Bar.count @ "/" @ Progress_Bar.total @ ")");

	%time = 100 / $pref::Net::PacketRateToServer;
	if (%time < 1)
		%time = 1;
	
	if (!$SB_LoadFileObj.isEOF ())
		$UploadSaveFile_Tick_Schedule = schedule (%time, 0, SB_ClientLoadTick);
	else
	{
		if($SB_SendBuffer !$= "")
		{
			commandToServer('UploadSaveFileLine', $SB_SendBuffer);
			$SB_SendBuffer = "";
		}

		schedule(%time, 0, SB_ClientLoadEnd);
	}
}

function SB_ClientLoadEnd()
{
	$SB_LoadFileObj.close();
	$SB_LoadFileObj.delete();
	Canvas.popDialog (ProgressGui);

	commandToServer ('EndSaveFileUpload');

	$SB_Trim = true;
	$SB_Start = 0;
	$SB_SendBuffer = "";
}
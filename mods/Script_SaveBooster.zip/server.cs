package SaveBoosterServer
{
	function serverCmdUploadSaveFileLine (%client, %line)
	{
		if (!%client.isAdmin || %client != $LoadingBricks_Client)
			return Parent::serverCmdUploadSaveFileLine(%client, %line);
		
		if((%cts = getRecordCount(%line)) > 1)
		{
			for(%i = 1; %i < %cts; %i++)
				$LoadBrick_LineCount += (getRecord(%line, %i) !$= "");
		}
		Parent::serverCmdUploadSaveFileLine(%client, %line);
	}
};
activatePackage(SaveBoosterServer);
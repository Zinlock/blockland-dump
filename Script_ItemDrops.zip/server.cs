// Script_ItemDrops by Oxy
// Makes items dropped inside minigames stay until the minigame restarts
// Adds slayer "Drop items on death" and "Keep items until reset" prefs

if($AddOn__GameMode_Slayer)
	%err = forceRequiredAddon("GameMode_Slayer");
else if($Version == 20 && $AddOn__GameMode_SlayerV20)
	%err = forceRequiredAddon("GameMode_SlayerV20");

if(%err == $Error::AddOn_NotFound)
{
	error("Script_ItemDrops Error: Required Add-On GameMode_Slayer" @ ($Version == 20 ? "V20" : "") @ " not found!");
	return;
}

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Items";
	title = "Drop items on death";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.DropItemsOnDeath";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Items";
	title = "Keep items until reset";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.KeepItemsAround";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Items";
	title = "Despawn Time";
	defaultValue = 10;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.ItemDespawnTime";
	type = "int";
	int_minValue = 1;
	int_maxValue = 600;
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Items";
	title = "Allow dropping items";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.AllowItemDrops";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

function serverCmdClearItems(%cl)
{
	if(!%cl.isAdmin || !isObject(%mg = %cl.minigame))
		return;
	
	%mg.clearItems();
}

function serverCmdClearAllItems(%cl)
{
	if(!%cl.isAdmin)
		return;

	if(isObject(%set = MissionCleanup) && (%cts = %set.getCount()) > 0)
	{
		%items = 0;
		for(%i = 0; %i < %cts; %i++)
		{
			%obj = %set.getObject(%i);
			if(%obj.getClassName() $= "Item" && !%obj.static)
			{
				%obj.schedule(0, delete);
				%items++;
			}
		}
		messageAll('', "\c3" @ %cl.name @ "\c0 cleared all dropped items. (" @ %items @ ")");
	}
}

function MinigameSO::clearItems(%mg)
{
	if(isObject(%set = %mg.ItemSet) && (%cts = %set.getCount()) > 0)
	{
		for(%i = 0; %i < %cts; %i++)
			%set.getObject(%i).schedule(0, delete);
	}
}

function Player::dumpItems(%pl)
{
	if(%pl.getClassName() $= "AIPlayer" ||
		 !isObject(%cl = %pl.Client) ||
		 !isObject(%mg = %cl.minigame) ||
		 getSimTime() - %mg.idResetTime < 200 ||
		 getSimTime() - %cl.idMiniJoinTime < 200 ||
		 !%mg.DropItemsOnDeath)
		return;

	%db = %pl.getDatablock();
	$randomItemDir = true;
	for(%i = 0; %i < %db.maxTools; %i++)
	{
		// pretend the player dropped these themselves.
		// this makes sure all mods are supported and guns dont magically refill on death
		serverCmdDropTool(%cl, %i);
	}
	schedule(0, 0, eval, "$randomItemDir = false;"); // dumb
}

function Item::checkPop(%itm)
{
	if($randomItemDir)
	{
		%vel = vectorLen(%itm.getVelocity()) / 2;

		if(%vel < 10)
			%vel = 10;

		%dirx = (getRandom() - 0.5) * 2;
		%diry = (getRandom() - 0.5) * 2;
		%dirz = (getRandom() - 0.5) * 1.4;

		%dir = vectorScale(%dirx SPC %diry SPC %dirz, %vel);

		%itm.schedule(0, setVelocity, %dir);
	}

	%resetPop = false;

	if((isObject(%mg = %itm.minigame) || isObject(%mg = getMiniGameFromObject(%itm))))
	{
		if(!isObject(%mg.ItemSet))
			%mg.ItemSet = new SimSet();
		
		%mg.ItemSet.add(%itm);

		if(%mg.KeepItemsAround)
			return;

		%resetPop = true;

		if(%mg.ItemDespawnTime <= 0)
			%time = 10000;
		else
			%time = %mg.ItemDespawnTime * 1000;

		$Game::Item::PopTime = %time;
	}
	
	%itm.forceSchedulePop();

	if(%resetPop)
		$Game::Item::PopTime = 10000;
}

function Item::forceSchedulePop(%itm)
{
	$forcePop = true;
	%itm.schedulePop();
	$forcePop = false;
}

registerOutputEvent ("fxDTSBrick", "spawnItem", "vector 200" TAB "dataBlock ItemData", 1); // by default, spawnItem doesnt pass the activating client

package ItemDrops
{
	function fxDTSBrick::spawnItem (%obj, %vector, %itemData, %client)
	{
		$itemSourceClient = %client;
		$itemSourceTime = getSimTime();
		return Parent::spawnItem(%obj, %vector, %itemData, %client);
	}

	function ItemData::onAdd(%db, %itm)
	{
		if(getSimTime() - $itemSourceTime < 3)
		{
			%itm.minigame = getMiniGameFromObject(%itm);

			%cl = $itemSourceClient;
			if(isObject(%cl) && %cl.getClassName() $= "GameConnection")
			{
				%itm.client = %cl;
				%itm.bl_id = %cl.getBLID();
				%itm.minigame = %cl.minigame;
			}
		}

		return Parent::onAdd(%db, %itm);
	}

	function Item::schedulePop(%itm)
	{
		if(!$forcePop)
		{
			%itm.schedule(0, checkPop); // item.minigame is set after schedulePop is called...
			return;
		}
		
		return Parent::schedulePop(%itm);
	}

	function MinigameSO::reset(%mini, %client)
	{
		%mini.idResetTime = getSimTime();
		%p = Parent::reset(%mini, %client);

		%mini.schedule(0, clearItems);
		%mini.schedule(33, clearItems);
		return %p;
	}

	function MinigameSO::endGame(%mini)
	{
		%mini.idResetTime = getSimTime();
		%mini.clearItems();
		return Parent::endGame(%mini);
	}

	function MinigameSO::addMember(%mini, %cl)
	{
		%cl.idMiniJoinTime = getSimTime();
		return Parent::addMember(%mini, %cl);
	}
	
	function Armor::onDisabled(%db, %pl, %state)
	{
		if(isObject(%pl))
			%pl.dumpItems();

		return Parent::onDisabled(%db, %pl, %state);
	}

	function Armor::onRemove(%db, %pl, %x, %y)
	{
		if(isObject(%pl))
			%pl.dumpItems();

		return Parent::onRemove(%db, %pl, %x, %y);
	}
};
activatePackage(ItemDrops);
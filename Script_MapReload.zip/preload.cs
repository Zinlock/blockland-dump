if($Version $= "21" || !isFile("config/server/add_on_list.cs") || !$Server::Dedicated)
	return;

exec("config/server/add_on_list.cs");

if(!$AddOn__Script_MapReload)
	return;

if(isFile("config/server/rtb/modPrefs.cs"))
	exec("config/server/rtb/modPrefs.cs");

if(isFile("config/server/lastMap.cs"))
{
	exec("config/server/lastMap.cs");

	if($Pref::MapReload::reloadLastMission)
	{
		if($missionArg $= "")
			$missionArg = $LastSaveMission;
	}
}
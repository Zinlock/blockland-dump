// edited v21 loading code

function getLoaderBrickGroup()
{
	if(!isObject(BrickGroup_990990))
	{		
		%brickGroup = new SimGroup(BrickGroup_990990);
		%brickGroup.bl_id = 990990;
		%brickGroup.name = "\c1Loader\c0";
		%brickGroup.QuotaObject = GlobalQuota;
		%brickGroup.DoNotDelete = 1;
		%brickGroup.isAdmin = 1;
		%brickGroup.isSuperAdmin = 1;
		%brickGroup.client = %brickGroup;
		mainBrickGroup.add(%brickGroup);
	}

	return BrickGroup_990990;
}

function DirectSaveLoad(%filename, %color, %owners, %silent)
{
	$LoadingBricks_DirName = "";

	if(%color $= "")
		$LoadingBricks_ColorMethod = 3;
	else
		$LoadingBricks_ColorMethod = %color;

	if(%owners $= "")
		$LoadingBricks_Ownership = 1;
	else
		$LoadingBricks_Ownership = %owners;

	if(%silent $= "")
		$LoadingBricks_Silent = true;
	else
		$LoadingBricks_Silent = %silent;
	
	calcSaveOffset();

	if(isObject($LoadBrick_FileObj))
	{
		$LoadBrick_FileObj.close();
		$LoadBrick_FileObj.delete();
	}

	getLoaderBrickGroup();

	$LoadingBricks_BrickGroup = BrickGroup_990990;
	$LoadingBricks_Client = $LoadingBricks_BrickGroup;

	$LoadingBricks_StartTime = getSimTime();
	$LoadingBricks_Filename = %filename;
	LoadSaveFileStart(%filename);
}

function LoadSaveFileStart(%filename)
{
	if($Game::MissionCleaningUp)
	{
		echo("LOADING CANCELED: Mission cleanup in progress");
		return;
	}

	$Server_LoadFileObj = new FileObject();

	if(isFile(%filename))
		$Server_LoadFileObj.openForRead(%filename);
	else
		$Server_LoadFileObj.openForRead("base/server/temp/temp.bls");

	if($UINameTableCreated == 0)
		createUINameTable();
	
	$LastLoadedBrick = 0;
	$Load_failureCount = 0;
	$Load_brickCount = 0;

	$Server_LoadFileObj.readLine();
	%lineCount = $Server_LoadFileObj.readLine();

	%i = 0;
	while(%i < %lineCount)
	{
		$Server_LoadFileObj.readLine();
		%i += 1;
	}
	if(isEventPending($LoadSaveFile_Tick_Schedule))
		cancel($LoadSaveFile_Tick_Schedule);
	
	ServerLoadSaveFile_ProcessColorData();
	LoadSaveFileTick();
	stopRaytracer();
}

function LoadSaveFileTick()
{
	if (isObject (ServerConnection))
	{
		if (!ServerConnection.isLocal ())
		{
			return;
		}
	}
	%line = $Server_LoadFileObj.readLine ();
	if (trim (%line) $= "")
	{
		if(!$Server_LoadFileObj.isEOF())
			LoadSaveFileTick();

		return;
	}
	%firstWord = getWord (%line, 0);
	if (%firstWord $= "+-EVENT")
	{
		if (isObject ($LastLoadedBrick))
		{
			%idx = getField (%line, 1);
			%enabled = getField (%line, 2);
			%inputName = getField (%line, 3);
			%delay = getField (%line, 4);
			%targetName = getField (%line, 5);
			%NT = getField (%line, 6);
			%outputName = getField (%line, 7);
			%par1 = getField (%line, 8);
			%par2 = getField (%line, 9);
			%par3 = getField (%line, 10);
			%par4 = getField (%line, 11);
			%inputEventIdx = inputEvent_GetInputEventIdx (%inputName);
			%targetIdx = inputEvent_GetTargetIndex ("fxDTSBrick", %inputEventIdx, %targetName);
			if (%targetName == -1)
			{
				%targetClass = "fxDTSBrick";
			}
			else 
			{
				%field = getField ($InputEvent_TargetList["fxDTSBrick", %inputEventIdx], %targetIdx);
				%targetClass = getWord (%field, 1);
			}
			%outputEventIdx = outputEvent_GetOutputEventIdx (%targetClass, %outputName);
			%NTNameIdx = -1;
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				%j = 0;
				while (%j < 4)
				{
					%field = getField ($OutputEvent_parameterList[%targetClass, %outputEventIdx], %j);
					%dataType = getWord (%field, 0);
					if (%dataType $= "datablock")
					{
						if (%par[%j + 1] != -1 && !isObject (%par[%j + 1]))
						{
							warn ("WARNING: could not find datablock for event " @ %outputName @ " -> " @ %par[%j + 1]);
						}
					}
					%j += 1;
				}
			}
			$LoadingBricks_Client.wrenchBrick = $LastLoadedBrick;
			serverCmdAddEvent ($LoadingBricks_Client, %enabled, %inputEventIdx, %delay, %targetIdx, %NTNameIdx, %outputEventIdx, %par1, %par2, %par3, %par4);
			$LastLoadedBrick.eventNT[$LastLoadedBrick.numEvents - 1] = %NT;
		}
	}
	else if (%firstWord $= "+-NTOBJECTNAME")
	{
		if (isObject ($LastLoadedBrick))
		{
			%name = getWord (%line, 1);
			$LastLoadedBrick.setNTObjectName (%name);
		}
	}
	else if (%firstWord $= "+-LIGHT")
	{
		if (isObject ($LastLoadedBrick))
		{
			%line = getSubStr (%line, 8, strlen (%line) - 8);
			%pos = strpos (%line, "\"");
			%dbName = getSubStr (%line, 0, %pos);
			%db = $uiNameTable_Lights[%dbName];
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				if (!isObject (%db))
				{
					warn ("WARNING: could not find light datablock for uiname \"" @ %dbName @ "\"");
				}
			}
			if (!isObject (%db))
			{
				%db = $uiNameTable_Lights["Player\'s Light"];
			}
			if ((strlen (%line) - %pos) - 2 >= 0)
			{
				%line = getSubStr (%line, %pos + 2, (strlen (%line) - %pos) - 2);
				%enabled = %line;
				if (%enabled $= "")
				{
					%enabled = 1;
				}
			}
			else 
			{
				%enabled = 1;
			}
			%quotaObject = getQuotaObjectFromBrick ($LastLoadedBrick);
			setCurrentQuotaObject (%quotaObject);
			$LastLoadedBrick.setLight (%db);
			if (isObject ($LastLoadedBrick.light))
			{
				$LastLoadedBrick.light.setEnable (%enabled);
			}
			clearCurrentQuotaObject ();
		}
	}
	else if (%firstWord $= "+-EMITTER")
	{
		if (isObject ($LastLoadedBrick))
		{
			%line = getSubStr (%line, 10, strlen (%line) - 10);
			%pos = strpos (%line, "\"");
			%dbName = getSubStr (%line, 0, %pos);
			if (%dbName $= "NONE")
			{
				%db = 0;
			}
			else 
			{
				%db = $uiNameTable_Emitters[%dbName];
			}
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				if (%db $= "")
				{
					warn ("WARNING: could not find emitter datablock for uiname \"" @ %dbName @ "\"");
				}
			}
			%line = getSubStr (%line, %pos + 2, (strlen (%line) - %pos) - 2);
			%dir = getWord (%line, 0);
			%quotaObject = getQuotaObjectFromBrick ($LastLoadedBrick);
			setCurrentQuotaObject (%quotaObject);
			if (isObject (%db))
			{
				$LastLoadedBrick.setEmitter (%db);
			}
			$LastLoadedBrick.setEmitterDirection (%dir);
			clearCurrentQuotaObject ();
		}
	}
	else if (%firstWord $= "+-ITEM")
	{
		if (isObject ($LastLoadedBrick))
		{
			%line = getSubStr (%line, 7, strlen (%line) - 7);
			%pos = strpos (%line, "\"");
			%dbName = getSubStr (%line, 0, %pos);
			if (%dbName $= "NONE")
			{
				%db = 0;
			}
			else 
			{
				%db = $uiNameTable_Items[%dbName];
			}
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				if (%dbName !$= "NONE" && !isObject (%db))
				{
					warn ("WARNING: could not find item datablock for uiname \"" @ %dbName @ "\"");
				}
			}
			%line = getSubStr (%line, %pos + 2, (strlen (%line) - %pos) - 2);
			%pos = getWord (%line, 0);
			%dir = getWord (%line, 1);
			%respawnTime = getWord (%line, 2);
			%quotaObject = getQuotaObjectFromBrick ($LastLoadedBrick);
			setCurrentQuotaObject (%quotaObject);
			if (isObject (%db))
			{
				$LastLoadedBrick.setItem (%db);
			}
			$LastLoadedBrick.setItemDirection (%dir);
			$LastLoadedBrick.setItemPosition (%pos);
			$LastLoadedBrick.setItemRespawntime (%respawnTime);
			clearCurrentQuotaObject ();
		}
	}
	else if (%firstWord $= "+-AUDIOEMITTER")
	{
		if (isObject ($LastLoadedBrick))
		{
			%line = getSubStr (%line, 15, strlen (%line) - 15);
			%pos = strpos (%line, "\"");
			%dbName = getSubStr (%line, 0, %pos);
			%db = $uiNameTable_Music[%dbName];
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				if (!isObject (%db))
				{
					warn ("WARNING: could not find music datablock for uiname \"" @ %dbName @ "\"");
				}
			}
			%quotaObject = getQuotaObjectFromBrick ($LastLoadedBrick);
			setCurrentQuotaObject (%quotaObject);
			$LastLoadedBrick.setSound (%db);
			clearCurrentQuotaObject ();
		}
	}
	else if (%firstWord $= "+-VEHICLE")
	{
		if (isObject ($LastLoadedBrick))
		{
			%line = getSubStr (%line, 10, strlen (%line) - 10);
			%pos = strpos (%line, "\"");
			%dbName = getSubStr (%line, 0, %pos);
			%db = $uiNameTable_Vehicle[%dbName];
			if ($LoadingBricks_Client == $LoadingBricks_BrickGroup)
			{
				if (!isObject (%db))
				{
					warn ("WARNING: could not find vehicle datablock for uiname \"" @ %dbName @ "\"");
				}
			}
			%line = getSubStr (%line, %pos + 2, (strlen (%line) - %pos) - 2);
			%recolorVehicle = getWord (%line, 0);
			%quotaObject = getQuotaObjectFromBrick ($LastLoadedBrick);
			setCurrentQuotaObject (%quotaObject);
			$LastLoadedBrick.setVehicle (%db);
			$LastLoadedBrick.setReColorVehicle (%recolorVehicle);
			clearCurrentQuotaObject ();
		}
	}
	else if (%firstWord $= "Linecount")
	{
		if (isObject (ProgressGui))
		{
			Progress_Bar.total = getWord (%line, 1);
			Progress_Bar.setValue (0);
			Progress_Bar.count = 0;
			Canvas.popDialog (ProgressGui);
			Progress_Window.setText ("Loading Progress");
			Progress_Text.setText ("Loading...");
		}
	}
	else if (%firstWord $= "+-OWNER")
	{
		if (isObject ($LastLoadedBrick))
		{
			if ($LoadingBricks_Ownership == 1)
			{
				%ownerBLID = mAbs (mFloor (getWord (%line, 1)));
				%oldGroup = $LastLoadedBrick.getGroup ();
				if ($Server::LAN)
				{
					$LastLoadedBrick.bl_id = %ownerBLID;
				}
				else if (%ownerBLID == 999999)
				{
					
				}
				else 
				{
					%ownerBrickGroup = "BrickGroup_" @ %ownerBLID;
					if (isObject (%ownerBrickGroup))
					{
						%ownerBrickGroup = %ownerBrickGroup.getId ();

						if(getSubStr(%ownerBrickGroup.name, 0, 8) $= "\c1BLID: " && $LastSeen_[%ownerBLID] !$= "")
							%ownerBrickGroup.name = "\c1" @ getField($LastSeen_[%ownerBLID], 0) @ "\c1\c0";
					}
					else 
					{
						%ownerBrickGroup = new SimGroup (("BrickGroup_" @ %ownerBLID));
						%ownerBrickGroup.client = 0;
						if($LastSeen_[%ownerBLID] !$= "")
							%ownerBrickGroup.name = "\c1" @ getField($LastSeen_[%ownerBLID], 0) @ "\c1\c0";
						else
							%ownerBrickGroup.name = "\c1BL_ID: " @ %ownerBLID @ "\c1\c0";
						%ownerBrickGroup.bl_id = %ownerBLID;
						mainBrickGroup.add (%ownerBrickGroup);
					}
					if (isObject (%ownerBrickGroup))
					{
						%ownerBrickGroup.add ($LastLoadedBrick);
						if (isObject (brickSpawnPointData))
						{
							if ($LastLoadedBrick.getDataBlock ().getId () == brickSpawnPointData.getId ())
							{
								if (%ownerBrickGroup != %oldGroup)
								{
									%oldGroup.removeSpawnBrick ($LastLoadedBrick);
									%ownerBrickGroup.addSpawnBrick ($LastLoadedBrick);
								}
							}
						}
					}
				}
			}
		}
	}
	else 
	{
		if(isObject($LastLoadedBrick.vehicle))
			$LastLoadedBrick.schedule(0, respawnVehicle);

		if (getBrickCount() >= getBrickLimit())
		{
			MessageAll ('', 'Brick limit reached (%1)', getBrickLimit());
			DirectSaveLoadEnd();
			return;
		}
		%quotePos = strstr (%line, "\"");
		if (%quotePos <= 0)
		{
			error ("ERROR: LoadSaveFileTick() - Bad line \"" @ %line @ "\" - expected brick line but found no uiname");
		}
		else
		{
			%uiName = getSubStr (%line, 0, %quotePos);
			%db = $uiNameTable[%uiName];
			%line = getSubStr (%line, %quotePos + 2, 9999);
			%pos = getWords (%line, 0, 2);
			%angId = getWord (%line, 3);
			%isBaseplate = getWord (%line, 4);
			%colorId = $colorTranslation[mFloor (getWord (%line, 5))];
			%printName = getWord (%line, 6);

			if($AllPrintRatios_ARList $= "")
			{
				if (strpos (%printName, "/") != -1)
				{
					%printName = fileBase (%printName);
					%aspectRatio = %db.printAspectRatio;
					%printIDName = %aspectRatio @ "/" @ %printName;
					%printId = $printNameTable[%printIDName];
					if (%printId $= "")
					{
						%printIDName = "Letters/" @ %printName;
						%printId = $printNameTable[%printIDName];
					}
					if (%printId $= "")
					{
						%printId = $printNameTable["Letters/-space"];
					}
				}
				else 
				{
					%printId = $printNameTable[%printName];
				}
			}
			else %printId = $printNameTable[%printName];
			%colorFX = getWord (%line, 7);
			%shapeFX = getWord (%line, 8);
			%rayCasting = getWord (%line, 9);
			%collision = getWord (%line, 10);
			%rendering = getWord (%line, 11);
			%pos = VectorAdd (%pos, $LoadingBricks_PositionOffset);
			if (%db)
			{
				%trans = %pos;
				if (%angId == 0)
				{
					%trans = %trans SPC " 1 0 0 0";
				}
				else if (%angId == 1)
				{
					%trans = %trans SPC " 0 0 1" SPC $piOver2;
				}
				else if (%angId == 2)
				{
					%trans = %trans SPC " 0 0 1" SPC $pi;
				}
				else if (%angId == 3)
				{
					%trans = %trans SPC " 0 0 -1" SPC $piOver2;
				}
				%b = new fxDTSBrick ("")
				{
					dataBlock = %db;
					angleID = %angId;
					isBasePlate = %isBaseplate;
					colorID = %colorId;
					printID = %printId;
					colorFxID = %colorFX;
					shapeFxID = %shapeFX;
					isPlanted = 1;
				};
				if (isObject ($LoadingBricks_BrickGroup))
				{
					$LoadingBricks_BrickGroup.add (%b);
				}
				else 
				{
					error ("ERROR: LoadSaveFileTick() - $LoadingBricks_BrickGroup does not exist!");
					MessageAll ('', "ERROR: LoadSaveFileTick() - $LoadingBricks_BrickGroup does not exist!");
					%b.delete ();
					DirectSaveLoadEnd();
					return;
				}
				%b.setTransform (%trans);
				%b.trustCheckFinished ();
				$LastLoadedBrick = %b;
				%err = %b.plant ();
				if (%err == 1 || %err == 3 || %err == 5)
				{
					$Load_failureCount += 1;
					%b.delete ();
					$LastLoadedBrick = 0;
				}
				else 
				{
					if (%rayCasting !$= "")
					{
						%b.setRayCasting (%rayCasting);
					}
					if (%collision !$= "")
					{
						%b.setColliding (%collision);
					}
					if (%rendering !$= "")
					{
						%b.setRendering (%rendering);
					}
					if ($LoadingBricks_Ownership && !$Server::LAN)
					{
						%oldGroup = %b.getGroup ();
						%ownerGroup = "";
						if (%b.getNumDownBricks ())
						{
							%ownerGroup = %b.getDownBrick (0).getGroup ();
							%ownerGroup.add (%b);
						}
						else if (%b.getNumUpBricks ())
						{
							%ownerGroup = %b.getUpBrick (0).getGroup ();
							%ownerGroup.add (%b);
						}
						if (isObject (brickSpawnPointData))
						{
							if (%b.getDataBlock ().getId () == brickSpawnPointData.getId ())
							{
								if (%ownerGroup > 0 && %ownerGroup != %oldGroup)
								{
									%oldGroup.removeSpawnBrick (%b);
									%ownerGroup.addSpawnBrick (%b);
								}
							}
						}
					}
					else 
					{
						$LastLoadedBrick.client = $LoadingBricks_Client;
					}
				}
			}
			else 
			{
				if (!$Load_MissingBrickWarned[%uiName])
				{
					warn ("WARNING: loadBricks() - DataBlock not found for brick named \"", %uiName, "\"");
					$Load_MissingBrickWarned[%uiName] = 1;
				}
				$LastLoadedBrick = 0;
				$Load_failureCount += 1;
			}
			$Load_brickCount += 1;
			if (isObject (ProgressGui))
			{
				Progress_Bar.count += 1;
				Progress_Bar.setValue (Progress_Bar.count / Progress_Bar.total);
				if (Progress_Bar.count + 1 == Progress_Bar.total)
				{
					Canvas.popDialog (ProgressGui);
				}
			}
		}
	}

	if (!$Server_LoadFileObj.isEOF ())
	{
		if ($Server::ServerType $= "SinglePlayer")
		{
			$LoadSaveFile_Tick_Schedule = schedule (0, 0, LoadSaveFileTick);
		}
		else 
		{
			$LoadSaveFile_Tick_Schedule = schedule (0, 0, LoadSaveFileTick);
		}
	}
	else
		DirectSaveLoadEnd();
}

function DirectSaveLoadEnd()
{
	%path = $LoadingBricks_Filename;

	ServerLoadSaveFile_End();

	%base = filePath(%path) @ "/" @ fileBase(%path);
	if($Pref::MapReload::autoSaveEnv)
	{
		if(($Version $= "21" || isObject(MissionInfo) && MissionInfo.enableEnvControl) && isFile(%base @ ".env"))
		{
			loadEnvironment(%base @ ".env");
			messageAll('', "\c7Loaded global environment.");
		}

		if($mrenvzones && isFile(%base @ ".ez"))
		{
			if(loadEnvironmentZones(%base @ ".ez"))
			{
				messageAll('', "\c7Loaded \c2" @ EnvironmentZoneGroup.getCount() @ "\c7 env zones.");
				showEnvironmentZones(1);
			}
		}
	}

	if(isPackage(XTrench))
	{
		if(isFile(%base @ ".xtd"))
			XTrenchLoadMap(%base @ ".xtd");
		else
			XTrenchClearResetList();
	}

	if($lmFirstLoad)
	{
		$lmFirstLoad = false;
		$LastSaveModified = false;
	}

	if($lmReset)
	{
		$lmReset = false;
		
		if(isObject(%mg = vmgGetDefaultMinigame()) && %mg.numMembers > 0)
			%mg.schedule(1000, reset);
	}
}
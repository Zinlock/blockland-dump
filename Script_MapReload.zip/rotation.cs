function vmgGetDefaultMinigame()
{
	if(isObject($DefaultMiniGame))
		return $DefaultMiniGame;

	if(isObject(Slayer.Minigames))
	{
		for(%i = 0; %i < Slayer.Minigames.getCount(); %i++)
		{
			%mg = Slayer.Minigames.getObject(%i);

			if(%mg.isDefaultMinigame)
				return %mg;
		}
	}

	return -1;
}

function serverCmdSetMapPlaylist(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7)
{
	if(!%cl.isAdmin)
		return;

	%str = %n0;
	for(%i=1;%i<8;%i++) %str = %str SPC %n[%i];
	%str = trim(%str);

	$Pref::MapReload::mapRotationPlaylist = %str;
	
	if(%str $= "")
	{
		$lmMapCount = 0;
		messageClient(%cl, '', "\c5Playlist disabled.");
	}
	else
		messageClient(%cl, '', "\c5Playlist set to " @ %str @ ".");
	
	RebuildPlaylist();
}

function serverCmdSavePlaylistMap(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7)
{
	if(!%cl.isAdmin)
		return;

	if($Pref::MapReload::mapRotationPlaylist $= "")
	{
		messageClient(%cl, '', "\c5No playlist is currently set.");
		return;
	}

	if(getRealBrickCount() <= 0)
	{
		messageClient(%cl, '', "\c5No bricks to save.");
		return;
	}

	%str = %n0;
	for(%i=1;%i<8;%i++) %str = %str SPC %n[%i];
	%str = trim(%str);

	if(%str $= "")
	{
		messageClient(%cl, '', "\c5Invalid save name.");
		return;
	}

	%save = "config/server/MRPlaylists/" @ $Pref::MapReload::mapRotationPlaylist @ "/" @ %str @ ".bls";
	exportMapSave(%save, true);
	
	%nfoPath = "config/server/MRPlaylists/" @ $Pref::MapReload::mapRotationPlaylist @ "_info.txt";

	%nfo = readInfoFile(%nfoPath);
	if(!isObject(%nfo))
	{
		%nfo = newInfoObject();
		newInfoGroup(%nfo);
	}
	
	%old = false;

	for(%i = 0; (%map = %nfo.listGet("maps", %i)) !$= ""; %i++)
	{
		if(%map $= %str)
		{
			%old = true;
			break;
		}
	}

	if(!%old)
		%nfo.listAdd("maps", %str);

	%nfo.set("mapMission_" @ getSafeVariableName(%str), $Server::MissionFile);
	%nfo.set("mapSave_" @ getSafeVariableName(%str), %save);

	writeInfoFile(%nfo, %nfoPath);

	%nfo.getGroup().delete();

	messageClient(%cl, '', "\c5Added \c3" @ %str @ "\c5 to playlist \c3" @ $Pref::MapReload::mapRotationPlaylist @ "\c5.");

	RebuildPlaylist();
}

function serverCmdRemovePlaylistMap(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7)
{
	if(!%cl.isAdmin && !%cl.isSuperAdmin)
		return;

	if($Pref::MapReload::mapRotationPlaylist $= "")
	{
		messageClient(%cl, '', "\c5No playlist is currently set.");
		return;
	}

	%str = %n0;
	for(%i=1;%i<8;%i++) %str = %str SPC %n[%i];
	%str = trim(%str);

	if(isFile(%save = "config/server/MRPlaylists/" @ $Pref::MapReload::mapRotationPlaylist @ "/" @ %str @ ".bls"))
	{
		fileCopy(%save, "config/server/MRPlaylists.bkp/" @ $Pref::MapReload::mapRotationPlaylist @ "/" @ %str @ ".bls");
		fileDelete(%save);

		%nfoPath = "config/server/MRPlaylists/" @ $Pref::MapReload::mapRotationPlaylist @ "_info.txt";

		%nfo = readInfoFile(%nfoPath);
		if(isObject(%nfo))
		{
			for(%i = 0; (%map = %nfo.listGet("maps", %i)) !$= ""; %i++)
			{
				if(%map $= %str)
				{
					%nfo.listRemove("maps", %i);
					%nfo.set("mapMission_" @ getSafeVariableName(%str), "");
					%nfo.set("mapSave_" @ getSafeVariableName(%str), "");
				}
			}
		}
		
		writeInfoFile(%nfo, %nfoPath);

		%nfo.getGroup().delete();

		messageClient(%cl, '', "\c5Removed \c3" @ %str @ "\c5 from playlist \c3" @ $Pref::MapReload::mapRotationPlaylist @ "\c5.");
	}
	else messageClient(%cl, '', "\c5The map \c3" @ %str @ "\c5 is not in playlist \c3" @ $Pref::MapReload::mapRotationPlaylist @ "\c5.");

	RebuildPlaylist();
}

function serverCmdMaplist(%cl)
{
	if($Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
	{
		messageClient(%cl, '', "\c5No playlist is currently set.");
		return;
	}
	else if($lmMapCount <= 0)
		RebuildPlaylist();

	for(%i = 0; %i < $lmMapCount; %i++)
		messageClient(%cl, '', '\c6%1: \c3%2', %i + 1, $lmMap[%i]);
}

function RebuildPlaylist()
{
	if($Pref::MapReload::mapRotationPlaylist $= "")
	{
		%lmMapCount = 0;
		return;
	}

	echo("Playlist: " @ $Pref::MapReload::mapRotationPlaylist);

	$lmMapCount = 0;

	%nfoPath = "config/server/MRPlaylists/" @ $Pref::MapReload::mapRotationPlaylist @ "_info.txt";

	%nfo = readInfoFile(%nfoPath);
	if(isObject(%nfo))
	{
		for(%i = 0; (%map = %nfo.listGet("maps", %i)) !$= ""; %i++)
		{
			echo(" - " @ %map);
			$lmMap[$lmMapCount] = %map;
			$lmMapMission[$lmMapCount] = %nfo.get("mapMission_" @ getSafeVariableName(%map));
			$lmMapSave[$lmMapCount] = %nfo.get("mapSave_" @ getSafeVariableName(%map));
			$lmMapCount++;
		}
	}
	else warn(" ! Missing or invalid info file");

	%nfo.getGroup().delete();

	echo($lmMapCount @ " maps");
}

function loadMRMap(%id)
{
	if($Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
		return 1;

	$lmWaitingForMap = false;

	if($lmMap[%id] !$= $lmCurrMap)
	{
		%mapSave = $lmMapSave[%id];
		%mapMission = $lmMapMission[%id];

		$lmNextUp = %mapMission;
		$lmNextSave = %mapSave;
		$lmNextMap = true;

		$lmCurrMap = $lmMap[%id];

		%bg = getLoaderBrickGroup();

		if(isObject(%mg = vmgGetDefaultMinigame()) && %mapMission !$= $Server::MissionFile)
		{
			%cts = ClientGroup.getCount();
			for(%i = 0; %i < %cts; %i++)
			{
				%cc = ClientGroup.getObject(%i);
				%cc.hasSpawnedOnce = 0;
			}

			schedule(0, %mg, serverCmdChangeMap, %bg, %mapMission);
		}
		else
		{
			waitForMRMap();
			serverCmdClearAllBricks(%bg);
		}
	}
	else if(isObject(%mg = vmgGetDefaultMinigame()))
	{
		$lmRound = 0;

		if($lmWaitingForVote)
			%mg.reset();
	}

	$lmWaitingForVote = false;
}

function waitForMRMap()
{
	cancel($mrs);

	if(getRealBrickCount() <= 0)
	{
		loadMapSave();
		return;
	}

	$mrs = schedule(1000, 0, waitForMRMap);
}

package MapRotationPkg
{
	function Slayer_MiniGameSO::endRound(%mg, %winner, %time)
	{
		if($Pref::MapReload::enableMapRotation && $Pref::MapReload::mapRotationPlaylist !$= "" && $Pref::MapReload::mapRotationRounds > 0 && %mg == vmgGetDefaultMinigame() && $lmMapCount > 0 && !$lmNextMap)
		{
			if(!$lmMapVoting && !$lmWaitingForMap && $lmRound >= $Pref::MapReload::mapRotationRounds)
			{
				$lmWaitingForVote = true;
				mrSchedule(5000, %mg, startMapVote);
				return Parent::endRound(%mg, %winner, -1);
			}
		}

		return Parent::endRound(%mg, %winner, %time);
	}

	function MiniGameSO::Reset(%mg, %cl)
	{
		if($Pref::MapReload::enableMapRotation && $Pref::MapReload::mapRotationPlaylist !$= "" && $Pref::MapReload::mapRotationRounds > 0 && %mg == vmgGetDefaultMinigame() && $lmMapCount > 0 && !$lmNextMap)
		{
			$lmWaitingForVote = true;

			if(%mg.numMembers > 0)
				$lmRound++;
			else
				$lmRound = 1;

			if(!$lmMapVoting && !$lmWaitingForMap && $lmRound > $Pref::MapReload::mapRotationRounds)
			{
				mrSchedule(1000, %mg, startMapVote);
				return;
			}

			messageAll('', '\c5Round \c3%1/%2\c5', $lmRound, $Pref::MapReload::mapRotationRounds);
		}

		return Parent::Reset(%mg, %cl);
	}
};
activatePackage(MapRotationPkg);

if($Pref::MapReload::mapRotationPlaylist !$= "")
	RebuildPlaylist();
exec("./Support_InfoTxt.cs");

if(isFile("config/server/lastMap.cs"))
	exec("config/server/lastMap.cs");

RTB_registerPref("Enable Auto Save", "Autosaver", "$Pref::MapReload::enableAutoSave", "bool", "Script_MapReload", true, false, false, "");
RTB_registerPref("Auto Save Delay (5m)", "Autosaver", "$Pref::MapReload::autoSaveDelay", "int 1 16", "Script_MapReload", 5, false, false, "");
RTB_registerPref("Auto Load Environments", "Autosaver", "$Pref::MapReload::autoSaveEnv", "bool", "Script_MapReload", true, false, false, "");
RTB_registerPref("Silent Autosave", "Autosaver", "$Pref::MapReload::silentAutoSave", "bool", "Script_MapReload", false, false, false, "");

if($Version !$= "21")
	RTB_registerPref("Reload Last Map", "Autosaver - Reload", "$Pref::MapReload::reloadLastMission", "bool", "Script_MapReload", true, false, false, "");
RTB_registerPref("Reload Last Save", "Autosaver - Reload", "$Pref::MapReload::reloadLastSave", "bool", "Script_MapReload", true, false, false, "");

RTB_registerPref("Enable Map Rotation", "Autosaver - Map Rotation", "$Pref::MapReload::enableMapRotation", "bool", "Script_MapReload", false, false, false, "");
RTB_registerPref("Map Rotation Playlist", "Autosaver - Map Rotation", "$Pref::MapReload::mapRotationPlaylist", "string 256", "Script_MapReload", "", false, false, "");
RTB_registerPref("Map Rotation Rounds (4)", "Autosaver - Map Rotation", "$Pref::MapReload::mapRotationRounds", "int 0 99", "Script_MapReload", 4, false, false, "");

RTB_registerPref("Enable Map Voting", "Autosaver - Map Voting", "$Pref::MapReload::enableMapVoting", "bool", "Script_MapReload", true, false, false, "");
RTB_registerPref("Map Vote Time (30s)", "Autosaver - Map Voting", "$Pref::MapReload::mapVoteTime", "int 10 120", "Script_MapReload", 30, false, false, "");

RTB_registerPref("Enable Map RTV", "Autosaver - Map RTV", "$Pref::MapReload::enableRTV", "bool", "Script_MapReload", true, false, false, "");
RTB_registerPref("Map RTV Ratio (50%)", "Autosaver - Map RTV", "$Pref::MapReload::mapRTVRatio", "int 10 100", "Script_MapReload", 50, false, false, "");
RTB_registerPref("Map RTV Timeout (5m)", "Autosaver - Map RTV", "$Pref::MapReload::mapRTVTimeout", "int 1 99", "Script_MapReload", 5, false, false, "");

// function taken from visolator's support_autosaver
function fxDtsBrick::saveToFile(%brick, %events, %ownership, %f)
{
	if(!isObject(%brick) || !isObject(%f))
	{
		//error("fxDtsBrick::saveStrToFile() - File object does not exist!");
		return -1;
	}

	%data = %brick.getDataBlock();

	if(%data.hasPrint)
	{
		%texture = getPrintTexture(%brick.getPrintID());
		%path = filePath(%texture);
		%underscorePos = strPos(%path, "_");
		%name = getSubStr(%path, %underscorePos + 1, strPos(%path, "_", 14) - 14) @ "/" @ fileBase(%texture);
		if($printNameTable[%name] !$= "")
			%print = %name;
	}

	%f.writeLine(%data.uiName @ "\" " @ %brick.getPosition() SPC %brick.getAngleID() SPC %brick.isBasePlate() SPC %brick.getColorID() 
		SPC %print SPC %brick.getColorFXID() SPC %brick.getShapeFXID() SPC %brick.isRayCasting() SPC %brick.isColliding() SPC %brick.isRendering());

	if(%data.uiName $= "")
	{
		talk("!!! brick " @ %brick @ " can not be saved (no uiname)");
		echo("!!! brick " @ %brick @ " can not be saved (no uiname)");
	}

	if(%ownership && !$Server::LAN)
	{
		//%tempID = %brick.stackBL_ID;
		if(%tempID $= "")
			%tempID = getBrickGroupFromObject(%brick).bl_id;

		if(%tempID == -1)
			%tempID = 888888;

		if(%tempID !$= "")
			%f.writeLine("+-OWNER " @ %tempID);
		else
			%f.writeLine("+-OWNER 888888");
	}

	if(%events)
	{
		if(%brick.getName() !$= "")
			%f.writeLine("+-NTOBJECTNAME " @ %brick.getName());

		for(%b = 0; %b < %brick.numEvents; %b++)
		{
			%eventsFound++;
			%params = getFields(%brick.serializeEventToString(%b), 7, 10);
			%f.writeLine("+-EVENT" TAB %b TAB %brick.eventEnabled[%b] TAB %brick.eventInput[%b] TAB %brick.eventDelay[%b] TAB %brick.eventTarget[%b] 
				TAB %brick.eventNT[%b] TAB %brick.eventOutput[%b] TAB %params);
		}
	}
			
	if(isObject(%emitter = %brick.emitter) && isObject(%emitterData = %emitter.getEmitterDatablock()) && (%emitterName = %emitterData.uiName) !$= "")
		%f.writeLine("+-EMITTER " @ %emitterName @ "\" " @ %brick.emitterDirection);

	if(isObject(%light = %brick.getLightID()) && isObject(%lightData = %light.getDataBlock()) && (%lightName = %lightData.uiName) !$= "")
		%f.writeLine("+-LIGHT " @ %lightName @ "\" "); // Not sure if something else comes after the name

	if(isObject(%item = %brick.item) && isObject(%itemData = %item.getDataBlock()) && (%itemName = %itemData.uiName) !$= "")
		%f.writeLine("+-ITEM " @ %itemName @ "\" " @ %brick.itemPosition SPC %brick.itemDirection SPC %brick.itemRespawnTime);

	if(isObject(%audioEmitter = %brick.audioEmitter) && isObject(%audioData = %audioEmitter.getProfileID()) && (%audioName = %audioData.uiName) !$= "")
		%f.writeLine("+-AUDIOEMITTER " @ %audioName @ "\" "); // Not sure if something else comes after the name

	if(isObject(%spawnMarker = %brick.vehicleSpawnMarker) && (%spawnMarkerName = %spawnMarker.uiName) !$= "")
		%f.writeLine("+-VEHICLE " @ %spawnMarkerName @ "\" " @ %brick.reColorVehicle);

	return %eventsFound;
}

exec("./loading.cs");

$MapReloadSilent = false;

if($LastSaveSilent $= "") $LastSaveSilent = false;

if(isFile("Add-Ons/Server_EnvironmentZones/server.cs") && isFunction(NetObject, setNetFlag) && $AddOn__Server_EnvironmentZones == 1)
	$mrenvzones = true;

function autoSaveLoop()
{
	if($Pref::MapReload::enableAutoSave)
	{
		if($LastSaveModified)
		{
			if($Pref::MapReload::silentAutoSave)
				$MapReloadSilent = true;

			if(!isEventPending($lsasAsync))
				exportMapSaveAsync();
			else
				warn("An async save is already running...");

			if($Pref::MapReload::silentAutoSave)
				$MapReloadSilent = false;
		}
		else
		{
			if(!$Pref::MapReload::silentAutoSave)
				messageAll('', "\c7No changes to save");

			echo(" - No changes to save");
		}
	}

	scheduleAutoSave();
}

function scheduleAutoSave()
{
	cancel($lsas);
	$lsas = schedule(1000 * 60 * $Pref::MapReload::autoSaveDelay, 0, autoSaveLoop);
}

if(!isEventPending($lsas))
	scheduleAutoSave();

function loadEnvironment(%path)
{
	cancel($envLoadSchedule);

	if(clientGroup.getCount() > 0)
	{
		%load = false;
		for(%i = 0; %i < clientGroup.getCount(); %i++)
		{
			if(clientGroup.getObject(%i).hasSpawnedOnce)
			{
				%load = true;
				break;
			}
		}

		if(%load && isFile(%path))
		{
			%res = GameModeGuiServer::ParseGameModeFile(%path, 1);

			if(!%res)
				return;

			EnvGuiServer::getIdxFromFilenames();
			EnvGuiServer::SetSimpleMode();

			if(!$EnvGuiServer::SimpleMode)     
			{
				EnvGuiServer::fillAdvancedVarsFromSimple();
				EnvGuiServer::SetAdvancedMode();
			}

			return;
		}
	}

	$envLoadSchedule = schedule(1000, 0, loadEnvironment, %path);
}

function exportLoaderPrefs()
{
	export("$lastSave*", "config/server/lastMap.cs");
}

function getSavePath(%name2, %abs)
{
	if(isObject(MissionInfo))
		%name = MissionInfo.SaveName;
	else
		%name = $missionArg;
	
	%date = strReplace(getDateTime(), "/", ".");
	%date = strReplace(%date,         " ", "_");
	%date = strReplace(%date,         ":", ".");

	if(!%abs)
	{
		if(%name !$= "")
		{
			if(%name2 !$= "")
				%path = "saves/" @ %name @ "/" @ %name2 @ ".bls";
			else
				%path = "saves/" @ %name @ "/auto_" @ %date @ ".bls";
		}
		else
		{
			if(%name2 !$= "")
				%path = "saves/" @ %name2 @ ".bls";
			else
				%path = "saves/auto_" @ %date @ ".bls";
		}
	}
	else %path = %name2;

	return %path;
}

function exportMapSave(%name2, %abs)
{
	if(isObject(MissionInfo))
		%name = MissionInfo.SaveName;
	else
		%name = $missionArg;

	%path = getSavePath(%name2, %abs);

	%cts = 0;
	if(getRealBrickCount() > 0)
	{
		%start = getRealTime();

		if(isFile(%path))
			fileCopy(%path, "saves/auto_temp.bls");

		%file = new FileObject();
		if(!%file.openForWrite(%path))
		{
			error("Failed to write to file " @ %path);

			%file.close();
			%file.delete();
			return -1;
		}

		%file.writeLine("This is a Blockland save file.  You probably shouldn't modify it cause you'll mess it up.");
		%file.writeLine("1");
		%file.writeLine("");

		for(%i = 0; %i < 64; %i++)
			%file.writeLine(getColorIDTable(%i));

		%file.writeLine("Linecount " @ getBrickCount());

		for(%g = 0; %g < mainBrickGroup.getCount(); %g++)
		{
			%group = mainBrickGroup.getObject(%g);
			for(%i = 0; %i < %group.getCount(); %i++)
			{
				%brk = %group.getObject(%i);

				if(%brk.isPlanted())
				{
					%cts++;
					%brk.saveToFile(1, 1, %file);
				}
			}
		}

		%file.close();
		%file.delete();

		if(%cts > 0)
		{
			%time = mFloatLength((getRealTime() - %start) / 1000, 1);

			if(!$MapReloadSilent)
				messageAll('', "\c7Saved \c2" @ %cts @ "\c7 bricks as \c2" @ fileName(%path) @ "\c7 in \c2" @ %time @ "\c7 seconds");

			echo(" - Saved " @ %cts @ " bricks as " @ fileName(%path) @ " in " @ %time @ " seconds");

			%last = $LastSave_[getSafeVariableName(%name)];
			$LastSave_[getSafeVariableName(%name)] = %path;
			$LastSaveIgnore_[getSafeVariableName(%name)] = false;

			%base = filePath(%path) @ "/" @ fileBase(%path);
			if($Version $= "21" || isObject(MissionInfo) && MissionInfo.enableEnvControl)
			{
				saveEnvironment(%base @ ".env");

				if(!$MapReloadSilent)
					messageAll('', "\c7Saved global environment.");

				if($mrenvzones)
				{
					if($lmExiting && isFile(%last))
					{
						$lmExiting = false;
						%ez = filePath(%last) @ "/" @ fileBase(%last) @ ".ez";

						if(isFile(%ez))
						{
							fileCopy(%ez, %base @ ".ez");
							echo(" - Copied last save's env zones.");
						}
					}
					else
					{
						if(EnvironmentZoneGroup.getCount() > 0 && exportEnvironmentZones(%base @ ".ez"))
						{
							if(!$MapReloadSilent)
								messageAll('', "\c7Saved \c2" @ EnvironmentZoneGroup.getCount() @ "\c7 env zones.");
						}
						else
							fileDelete(%base @ ".ez");
					}
				}
			}
			else fileDelete(%base @ ".env");

			if(isPackage(XTrench))
			{
				if(XTrenchExportMap(%base @ ".xtd") <= 0)
					fileDelete(%base @ ".xtd");
			}
		}
		else if(isFile("saves/auto_temp.bls"))
			fileCopy("saves/auto_temp.bls", %path);
	}

	exportLoaderPrefs();

	$LastSaveModified = false;

	if(%cts > 0)
		return 1;
	else
	{
		$LastSaveIgnore_[getSafeVariableName(%name)] = true;
		return 0;
	}
}

function exportMapSaveAsync(%name2, %abs)
{
	if(getRealBrickCount() <= 8000)
		return exportMapSave(%name2, %abs);
	
	if(isEventPending($lsasAsync))
	{
		warn("MapReload: Async autosave already running");
		return -2;
	}

	if(isObject(MissionInfo))
		%name = MissionInfo.SaveName;
	else
		%name = $missionArg;

	%path = getSavePath(%name2, %abs);

	%cts = 0;
	%start = getRealTime();

	if(isFile(%path))
		fileCopy(%path, "saves/auto_temp.bls");

	%file = new FileObject();
	if(!%file.openForWrite(%path))
	{
		error("Failed to write to file " @ %path);

		%file.close();
		%file.delete();
		return -1;
	}

	if(!$MapReloadSilent)
		messageAll('', "\c7Saving bricks...");

	%file.writeLine("This is a Blockland save file.  You probably shouldn't modify it cause you'll mess it up.");
	%file.writeLine("1");
	%file.writeLine("");

	for(%i = 0; %i < 64; %i++)
		%file.writeLine(getColorIDTable(%i));

	%file.writeLine("Linecount " @ getBrickCount());

	$LastSaveModified = false;

	$lsasAsync = schedule(0, 0, exportMapSaveAsyncTick, %path, %name, %start, %cts, %file, 0, 0);
}

function exportMapSaveAsyncTick(%path, %name, %start, %cts, %file, %groupIdx, %brickIdx)
{
	cancel($lsasAsync);

	%max = 8000;

	if(%groupIdx < mainBrickGroup.getCount())
	{
		%done = true;
		%group = mainBrickGroup.getObject(%groupIdx);
		for(%i = %brickIdx; %i < %group.getCount(); %i++)
		{
			%brk = %group.getObject(%i);

			if(%brk.isPlanted())
			{
				%cts++;
				%brk.saveToFile(1, 1, %file);
			}

			if(%i >= %brickIdx + %max)
			{
				%brickIdx = %i + 1;
				%done = false;
				break;
			}
		}

		if(%done)
		{
			%brickIdx = 0;
			%groupIdx++;
		}

		schedule(32, 0, exportMapSaveAsyncTick, %path, %name, %start, %cts, %file, %groupIdx, %brickIdx);
		return;
	}

	%file.close();
	%file.delete();
	
	if(%cts > 0)
	{
		%time = mFloatLength((getRealTime() - %start) / 1000, 1);

		if(!$MapReloadSilent)
			messageAll('', "\c7Saved \c2" @ %cts @ "\c7 bricks as \c2" @ fileName(%path) @ "\c7 in \c2" @ %time @ "\c7 seconds");

		echo(" - Saved " @ %cts @ " bricks as " @ fileName(%path) @ " in " @ %time @ " seconds");

		$LastSave_[getSafeVariableName(%name)] = %path;
		$LastSaveIgnore_[getSafeVariableName(%name)] = false;

		%base = filePath(%path) @ "/" @ fileBase(%path);
		if($Version $= "21" || isObject(MissionInfo) && MissionInfo.enableEnvControl)
		{
			saveEnvironment(%base @ ".env");

			if(!$MapReloadSilent)
				messageAll('', "\c7Saved global environment.");

			if($mrenvzones)
			{
				if(EnvironmentZoneGroup.getCount() > 0 && exportEnvironmentZones(%base @ ".ez"))
				{
					if(!$MapReloadSilent)
						messageAll('', "\c7Saved \c2" @ EnvironmentZoneGroup.getCount() @ "\c7 env zones.");
				}
				else
					fileDelete(%base @ ".ez");
			}
		}
		else fileDelete(%base @ ".env");

		if(isPackage(XTrench))
		{
			if(XTrenchExportMap(%base @ ".xtd") <= 0)
				fileDelete(%base @ ".xtd");
		}
	}
	else if(isFile("saves/auto_temp.bls"))
		fileCopy("saves/auto_temp.bls", %path);

	exportLoaderPrefs();

	if(%cts <= 0)
		$LastSaveIgnore_[getSafeVariableName(%name)] = true;
}

function loadMapSave()
{
	if($lmNextMap)
	{
		$lmNextMap = false;
		$lmRound = 0;

		if(isFile(%path = $lmNextSave))
		{
			DirectSaveLoad(%path);

			fileCopy(%path, "base/server/temp/temp.bls");
			
			if(!$MapReloadSilent)
				messageAll('', "\c7Loaded save from \c2" @ fileName(%path));

			echo(" - Loaded save from " @ fileName(%path));
		}

		$lmNextUp = "";
		$lmNextSave = "";

		$lmReset = true;

		$lmFirstLoad = true;
		return 1;
	}
	else if(!$Pref::MapReload::reloadLastSave)
		return 1;

	if(isObject(MissionInfo))
		%name = MissionInfo.SaveName;
	else
		%name = $missionArg;
	
	if($LastSaveIgnore_[getSafeVariableName(%name)])
		return 1;
	
	%path = $LastSave_[getSafeVariableName(%name)];

	if(%path $= "" || !isFile(%path))
		return 0;

	DirectSaveLoad(%path);

	fileCopy(%path, "base/server/temp/temp.bls");
	
	if(!$MapReloadSilent)
		messageAll('', "\c7Loaded last save from \c2" @ fileName(%path));
	
	echo(" - Loaded last save from " @ fileName(%path));

	$lmFirstLoad = true;
	
	return 1;
}

function loadSave(%str)
{
	if(isObject(MissionInfo))
		%name = MissionInfo.SaveName;
	else
		%name = $missionArg;
	
	if(%str $= "")
		%str = fileBase($LastSave_[getSafeVariableName(%name)]);
	
	if(%name !$= "")
		%path = "saves/" @ %name @ "/" @ %str @ ".bls";
	else
		%path = "saves/" @ %str @ ".bls";
	
	if(!isFile(%path))
		return;
	
	DirectSaveLoad(%path);
	
	fileCopy(%path, "base/server/temp/temp.bls");
	
	if(!$MapReloadSilent)
		messageAll('', "\c7Loaded save from \c2" @ fileName(%str));
	
	echo(" - Loaded save from " @ fileName(%str));
}

function getRealBrickCount()
{
	%bricks = 0;

	%cts = mainBrickGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%group = mainBrickGroup.getObject(%i);

		%ct2 = %group.getCount();
		for(%b = 0; %b < %ct2; %b++)
		{
			if(%group.getObject(%b).isPlanted())
				%bricks++;
		}
	}

	return %bricks;
}

function serverCmdSB(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7) { serverCmdSaveBricks(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7); }
function serverCmdSaveBricks(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7)
{
	if(!%cl.isAdmin && !%cl.isSuperAdmin)
		return;

	%str = %n0;
	for(%i=1;%i<8;%i++) %str = %str SPC %n[%i];
	%str = trim(%str);

	%res = exportMapSave(%str);
	if(%res == 0)
		messageClient(%cl, '', "\c5No bricks to save.");
	else if (%res == -1)
		messageClient(%cl, '', "\c5Couldn't write save file.");
	else
		scheduleAutoSave();
}

function serverCmdLB(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7) { serverCmdLoadBricks(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7); }
function serverCmdLoadBricks(%cl, %n0, %n1, %n2, %n3, %n4, %n5, %n6, %n7)
{
	if(!%cl.isAdmin && !%cl.isSuperAdmin)
		return;

	%str = %n0;
	for(%i=1;%i<8;%i++) %str = %str SPC %n[%i];
	%str = trim(%str);

	loadSave(%str);
}

function serverCmdMAS(%cl) { serverCmdMuteAutosave(%cl); }
function serverCmdMuteAutosave(%cl)
{
	if(!%cl.isAdmin)
		return;

	$Pref::MapReload::silentAutoSave = !$Pref::MapReload::silentAutoSave;

	if($Pref::MapReload::silentAutoSave)
		messageClient(%cl, '', "\c5Auto-saver muted.");
	else
		messageClient(%cl, '', "\c5Auto-saver un-muted.");
}

function serverCmdTAS(%cl) { serverCmdToggleAutosave(%cl); }
function serverCmdToggleAutosave(%cl)
{
	if(!%cl.isAdmin)
		return;
	
	$Pref::MapReload::enableAutoSave = !$Pref::MapReload::enableAutoSave;

	if($Pref::MapReload::enableAutoSave)
	{
		messageClient(%cl, '', "\c5Auto-saver enabled.");
		scheduleAutoSave();
	}
	else
		messageClient(%cl, '', "\c5Auto-saver disabled.");
	
	exportLoaderPrefs();
}

package MapReloadPkg
{
	function serverCmdChangeMap(%client, %path)
	{	
		if(%client.isAdmin || %client.isSuperAdmin)
		{
			if($LastSaveModified)
				exportMapSave();
		}

		Parent::serverCmdChangeMap(%client, %path);
	}

	function onMissionLoaded()
	{
		$LastSaveMission = fileBase($Server::MissionFile);
		$lms = schedule(3000, 0, loadMapSave);

		$lmReset = true;
		
		exportLoaderPrefs();

		Parent::onMissionLoaded();
	}

	function onExit()
	{
		$MapReloadSilent = true;

		if($LastSaveModified)
		{
			$lmExiting = true;
			exportMapSave();
		}

		exportLoaderPrefs();
		cancel($lms);
		cancel($lsas);
		$MapReloadSilent = false;
		Parent::onExit();
	}
	
	function destroyServer()
	{
		$MapReloadSilent = true;

		if($LastSaveModified)
		{
			$lmExiting = true;
			exportMapSave();
		}

		exportLoaderPrefs();
		cancel($lms);
		cancel($lsas);
		$MapReloadSilent = false;
		Parent::destroyServer();
	}

	// this sucks!

	function fxDtsBrick::onPlant(%brk)
	{
		Parent::onPlant(%brk);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::onLoadPlant(%brk)
	{
		Parent::onLoadPlant(%brk);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::onDeath(%brk)
	{
		Parent::onDeath(%brk);
		$LastSaveModified = true;
	}

	function fxDtsBrick::setLight(%brk, %db, %cl)
	{
		Parent::setLight(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setEmitter(%brk, %db, %cl)
	{
		Parent::setEmitter(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setEmitterDirection(%brk, %dir)
	{
		Parent::setEmitterDirection(%brk, %dir);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setItem(%brk, %db, %cl)
	{
		Parent::setItem(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setItemDirection(%brk, %dir)
	{
		Parent::setItemDirection(%brk, %dir);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setItemPosition(%brk, %dir)
	{
		Parent::setItemPosition(%brk, %dir);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setItemRespawntime(%brk, %time)
	{
		Parent::setItemRespawntime(%brk, %time);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setMusic(%brk, %db, %cl)
	{
		Parent::setMusic(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setSound(%brk, %db, %cl)
	{
		Parent::setSound(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setVehicle(%brk, %db, %cl)
	{
		Parent::setVehicle(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setReColorVehicle(%brk, %db, %cl)
	{
		Parent::setReColorVehicle(%brk, %db, %cl);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setColor(%brk, %val)
	{
		Parent::setColor(%brk, %val);
		$LastSaveModified = true;
	}

	function fxDtsBrick::setColliding(%brk, %val)
	{
		Parent::setColliding(%brk, %val);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setRayCasting(%brk, %val)
	{
		Parent::setRayCasting(%brk, %val);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setRendering(%brk, %val)
	{
		Parent::setRendering(%brk, %val);
		$LastSaveModified = true;
	}
	
	function fxDtsBrick::setNTObjectName(%brk, %val)
	{
		Parent::setNTObjectName(%brk, %val);
		$LastSaveModified = true;
	}

	function serverCmdAddEvent(%cl, %enabled, %inputEventIdx, %delay, %targetIdx, %NTNameIdx, %outputEventIdx, %par1, %par2, %par3, %par4)
	{
		Parent::serverCmdAddEvent(%cl, %enabled, %inputEventIdx, %delay, %targetIdx, %NTNameIdx, %outputEventIdx, %par1, %par2, %par3, %par4);
		$LastSaveModified = true;
	}
};

function getMapName(%mis)
{
	if(!isFile(%mis))
		return "";
	
	%file = new FileObject();

	if(!%file.openForRead(%mis))
		return "";

	%inMissionInfo = false;
	
	while(!%file.isEOF())
	{
		%line = trim(%file.readLine());

		if(%line $= "new ScriptObject(MissionInfo) {")
			%inMissionInfo = true;
		else if(%inMissionInfo && getSubStr(%line, 0, 6) $= "name =")
		{
			%name = getSubStr(%line, 8, strlen(%line) - 10);
			return %name;
		}
	}

	return fileBase(%mis);
}

exec("./rotation.cs");
exec("./vote.cs");

if($mapListCount <= 0)
{
	schedule(0, 0, echo, "Generating map list...");
	schedule(0, 0, generateMapList);
}

if(isFile("Add-Ons/Server_AdminUtilities/svlock.cs") && $AddOn__Server_AdminUtilities == 1)
{
	activatePackage(MapReloadPkg);
	return;
}

// adminutil is either not installed or disabled; handle blid logging manually
package MapReloadPkg
{
	function GameConnection::onDrop(%cl, %res)
	{
		if(%cl.getBLID() >= 0)
			$LastSeen_[%cl.getBLID()] = %cl.name TAB getDateTime();

		export("$LastSeen*", "config/server/joinLogs.cs");

		Parent::onDrop(%cl, %res);
	}
};

activatePackage(MapReloadPkg);
datablock AudioProfile(MapVoteStartSound)
{
	fileName = "./voteStart.wav";
	preload = true;
	description = AudioDefault3D;
};

datablock AudioProfile(MapVoteSound)
{
	fileName = "./vote.wav";
	preload = true;
	description = AudioDefault3D;
};

datablock AudioProfile(MapVoteTimerSound)
{
	fileName = "./voteTimer.wav";
	preload = true;
	description = AudioDefault3D;
};

function resetMRSchedules()
{
	if($mrSchedules > 0)
	{
		for(%i = 0; %i < $mrSchedules; %i++)
			cancel($mrSchedule[%i]);
	}

	$mrSchedules = 0;
}

function mrSchedule(%delay, %src, %fn, %arg0, %arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
{
	if($mrSchedules $= "")
		$mrSchedules = 0;
	
	%id = schedule(%delay, %src, %fn, %arg0, %arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7);

	$mrSchedule[$mrSchedules] = %id;
	$mrSchedules++;

	return %id;
}

function checkMapVote()
{
	if($lmWaitingForMap || $lmMapVoting || $Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
		return;
	
	if(getVotes() >= getMinVotes())
		schedule(0, 0, startMapVote);
}

function startMapVote(%time)
{
	if($lmWaitingForMap || !isObject(%mg = vmgGetDefaultMinigame()) || $Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
		return;

	resetMRSchedules();
	
	if(!$Pref::MapReload::enableMapVoting)
	{
		endMapVote();
		return;
	}

	if(%mg.numMembers < 1)
		return;

	if(%time $= "")
		%time = $Pref::MapReload::mapVoteTime;

	if(%time < 10)
		%time = 10;
	
	%time = mFloatLength(%time, 0);

	serverPlay2D(MapVoteStartSound);
	messageAll('', "\c5Map voting has started!");
	messageAll('', "\c5Use \c3/maplist\c5 to see available maps and vote with \c3/vote [id/name]\c5.");
	messageAll('', '\c5Voting will end in \c3%1 seconds\c5.', %time);

	if(%time > 30)
	{
		mrSchedule((%time - 30) * 1000, 0, messageAll, '', "\c5Voting will end in \c330 seconds\c5.");
		mrSchedule((%time - 30) * 1000, 0, serverPlay2D, MapVoteTimerSound);
	}

	if(%time > 15)
	{
		mrSchedule((%time - 15) * 1000, 0, messageAll, '', "\c5Voting will end in \c315 seconds\c5.");
		mrSchedule((%time - 15) * 1000, 0, serverPlay2D, MapVoteTimerSound);
	}
	
	if(%time > 10)
	{
		mrSchedule((%time - 10) * 1000, 0, messageAll, '', "\c5Voting will end in \c310 seconds\c5.");
		mrSchedule((%time - 10) * 1000, 0, serverPlay2D, MapVoteTimerSound);
	}

	for(%i = 5; %i > 0; %i--)
	{
		mrSchedule((%time - %i) * 1000, 0, messageAll, '', '\c5Voting will end in \c3%1 second%2\c5.', %i, (%i != 1 ? "s" : ""));
		mrSchedule((%time - %i) * 1000, 0, serverPlay2D, MapVoteTimerSound);
	}
	
	mrSchedule(%time * 1000, 0, endMapVote);

	$lmMessages = %start SPC %end;
	$lmMapVoting = true;

	%cts = clientGroup.getCount();
	for(%i = 0; %i < %cts; %i++)
	{
		%cl = clientGroup.getObject(%i);
		%cl.mapVote = -1;
	}
}

function endMapVote()
{
	resetMRSchedules();

	if(!isObject(%mg = vmgGetDefaultMinigame()) || $Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
		return;

	if(%mg.numMembers < 1)
		return;

	if(!$Pref::MapReload::enableMapVoting)
	{
		%next = getRandom(0, $lmMapCount-1);

		messageAll('', '\c5Next up: \c3%1', $lmMap[%next]);
		
		$lmMapLoadTime = getSimTime() + 5000;

		mrSchedule(5000, 0, loadMRMap, %next);
		return;
	}

	messageAll('', "\c5Voting is over!");

	$lmMapVoting = false;
	$lmWaitingForMap = true;

	for(%i = 0; %i < $lmMapCount; %i++)
		$lmMapVotes[%i] = 0;

	%cts = %mg.numMembers;
	for(%i = 0; %i < %cts; %i++)
	{
		%cl = %mg.member[%i];
		
		if(%cl.mapVote !$= "" && %cl.mapVote >= 0)
			$lmMapVotes[%cl.mapVote]++;

		%cl.rtv = 0;
	}
	
	%highest = -1;
	for(%i = 0; %i < $lmMapCount; %i++)
	{
		if($lmMapVotes[%i] > 0)
		{
			if(%highest == -1 || $lmMapVotes[%i] > $lmMapVotes[firstWord(%highest)])
				%highest = %i;
			else if($lmMapVotes[%i] == $lmMapVotes[firstWord(%highest)])
				%highest = addItemToList(%highest, %i);
		}
	}

	%next = 0;
	if(%highest == -1)
	{
		%next = getRandom(0, $lmMapCount-1);

		if($lmMap[%next] !$= $lmCurrMap)
			messageAll('', '\c5Nobody voted. Next up: \c3%1', $lmMap[%next]);
		else
			messageAll('', '\c5Nobody voted. Extending \c3%1', $lmMap[%next]);
	}
	else if((%cts = getWordCount(%highest)) > 1)
	{
		%next = getWord(%highest, getRandom(0, %cts-1));

		if($lmMap[%next] !$= $lmCurrMap)
			messageAll('', '\c3%1\c5 maps were tied with \c3%2\c5 votes. Next up: \c3%3', %cts, $lmMapVotes[%next], $lmMap[%next]);
		else
			messageAll('', '\c3%1\c5 maps were tied with \c3%2\c5 votes. Extending \c3%3', %cts, $lmMapVotes[%next], $lmMap[%next]);
	}
	else
	{
		%next = %highest;

		if($lmMap[%next] !$= $lmCurrMap)
			messageAll('', '\c5Next up: \c3%1\c5 with \c3%2\c5 vote%3', $lmMap[%next], $lmMapVotes[%next], ($lmMapVotes[%next] == 1 ? "" : "s"));
		else
			messageAll('', '\c5Extending \c3%1\c5 with \c3%2\c5 vote%3', $lmMap[%next], $lmMapVotes[%next], ($lmMapVotes[%next] == 1 ? "" : "s"));
	}

	$lmMapLoadTime = getSimTime() + 5000;

	if($Pref::MapReload::enableRTV)
	{
		mrSchedule($Pref::MapReload::mapRTVTimeout * 60 * 1000 + 5000, 0, messageAll, '', "\c5You can now rock the vote.");
		mrSchedule($Pref::MapReload::mapRTVTimeout * 60 * 1000 + 5000, 0, serverPlay2D, MapVoteTimerSound);
	}

	mrSchedule(5000, 0, loadMRMap, %next);
}

function getMinVotes()
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return 1;

	return mCeil(%mg.numMembers / (100 / $Pref::MapReload::mapRTVRatio));
}

function getVotes()
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return 0;

	%cts = %mg.numMembers;
	%votes = 0;
	for(%i = 0; %i < %cts; %i++)
	{
		%cl = %mg.member[%i];

		if(%cl.rtv)
			%votes++;
	}

	return %votes;
}

function serverCmdRTV(%client)
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return;

	if($lmWaitingForMap || $lmMapVoting || !%mg.isMember(%client) || !$Pref::MapReload::enableRTV)
		return;

	schedule(0, 0, checkMapVote);

	%t = (getSimTime() - $lmMapLoadTime);
	%time = ($Pref::MapReload::mapRTVTimeout - mFloor(%t / 1000 / 60));
	if(%t < $Pref::MapReload::mapRTVTimeout * 60 * 1000)
		return messageClient(%client, '', '\c5You will be able to rock the vote in \c3%1 minute%2\c5.', %time, (%time == 1 ? "" : "s"));

	if(%client.rtv)
		messageClient(%client, '', "\c5You already rocked the vote.");
	else
	{
		%client.rtv = true;
		messageAll('', '\c3%1\c5 wants to rock the vote! \c3(%2/%3)', %client.name, getVotes(), getMinVotes());
		serverPlay2D(MapVoteSound);
	}
}

function serverCmdVote(%client, %i0, %i1, %i2, %i3, %i4, %i5, %i6, %i7)
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return;

	if(!$lmMapVoting || !%mg.isMember(%client))
		return;

	if(getSimTime() - %client.lastVoteTime < 2000)
		return messageClient(%client, '', "\c5You are voting too fast.");

	%id = %i0;
	for(%i=1;%i<8;%i++) %id = %id SPC %i[%i];
	%id = trim(%id);

	%idx = mrGetMapId(%id);
	if(%idx < 0)
		return messageClient(%client, '', "\c5Invalid map. See all available maps with /maplist");

	if(%idx == %client.mapVote)
		return messageClient(%client, '', "\c5You already voted for this map.");
	
	%client.lastVoteTime = getSimTime();
	%client.mapVote = %idx;
	messageAll('', '\c3%1\c5 voted for \c3%2', %client.name, $lmMap[%idx]);
	serverPlay2D(MapVoteSound);
}

function mrGetMapId(%id)
{
	%isNum = false;

	if((%id | 0) $= %id)
		%isNum = true;

	for(%i = 0; %i < $lmMapCount; %i++)
	{
		if((!%isNum && $lmMap[%i] $= %id || %isNum && %i == %id - 1) && isFile($lmMapSave[%i]))
			return %i;
	}

	return -1;
}

function serverCmdForceVote(%client)
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return;

	if(!%client.isAdmin)
		return;

	messageAll('', '\c3%1\c5 forced a map vote', %client.name);
	startMapVote();
}

function serverCmdStopVote(%client)
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return;

	if(!%client.isAdmin)
		return;

	if($lmWaitingForMap || $lmMapVoting)
	{
		messageAll('', '\c3%1\c5 stopped the ongoing map vote', %client.name);
		resetMRSchedules();

		$lmMapVoting = false;
		$lmWaitingForMap = false;
	}
}

function serverCmdRewindRounds(%client, %rds)
{
	if(!isObject(%mg = vmgGetDefaultMinigame()))
		return;

	if(!%client.isAdmin)
		return;

	%rds = %rds * 1;

	if(%rds < 1 || %rds > $Pref::MapReload::mapRotationRounds || %rds == $lmRound)
		return messageClient(%client, '', "\c5Invalid round count.");

	messageAll('', '\c3%1\c5 %4 to map round \c3%2/%3', %client.name, %rds, $Pref::MapReload::mapRotationRounds, ($lmRound > %rds ? "rewound" : "skipped"));

	$lmRound = %rds;
}

function serverCmdForceMap(%client, %i0, %i1, %i2, %i3, %i4, %i5, %i6, %i7)
{
	if(!%client.isAdmin)
		return;

	if($Pref::MapReload::mapRotationPlaylist $= "" || !$Pref::MapReload::enableMapRotation)
		return;

	%id = %i0;
	for(%i=1;%i<8;%i++) %id = %id SPC %i[%i];
	%id = trim(%id);

	%idx = mrGetMapId(%id);

	if(%idx < 0)
		return messageClient(%client, '', "\c5Invalid map. See all available maps with /maplist");

	resetMRSchedules();

	messageAll('', '\c3%1\c5 changed the map to \c3%2', %client.name, $lmMap[%idx]);
	loadMRMap(%idx);
}

//addItemToList, hasItemOnList and removeItemFromList by Ephialtes
//Useful functions for manipulating space delimited lists
function addItemToList(%string,%item)
{
	if(hasItemOnList(%string,%item))
		return %string;

	if(%string $= "")
		return %item;
	else
		return %string SPC %item;
}
function hasItemOnList(%string,%item)
{
	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
			return 1;
	}
	return 0;
}
function removeItemFromList(%string,%item)
{
	if(!hasItemOnList(%string,%item))
		return %string;

	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
		{
			if(%i $= 0)
				return getWords(%string,1,getWordCount(%string));
			else if(%i $= getWordCount(%string)-1)
				return getWords(%string,0,%i-1);
			else
				return getWords(%string,0,%i-1) SPC getWords(%string,%i+1,getWordCount(%string));
		}
	}
}
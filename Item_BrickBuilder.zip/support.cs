// PnP functions taken from Conan's prop tools
function PnP_mRound(%val)
{
	if (%val <= 0)
		return mCeil(%val-0.5);
	else
		return mFloor(%val+0.5);
}

function PnP_roundShiftVector(%vector)
{
	%x = getWord(%vector, 0)*2;
	%y = getWord(%vector, 1)*2;
	%z = getWord(%vector, 2)*5;

	return PnP_mRound(%x)/2 SPC PnP_mRound(%y)/2 SPC PnP_mRound(%z)/5;
}

// i wasted an entire day trying to figure out how to center a vector on the brick grid
// %pos is the position vector
// %norm is the normal
// %odb is the brick datablock
// %rid is the brick angle id
function getBrickPos(%pos, %norm, %odb, %rid)
{
	if(%rid % 2)
	{
		%sX = %odb.brickSizeY;
		%sY = %odb.brickSizeX;
		%sZ = %odb.brickSizeZ;
	}
	else
	{
		%sX = %odb.brickSizeX;
		%sY = %odb.brickSizeY;
		%sZ = %odb.brickSizeZ;
	}

	%posX = getWord(%pos, 0);
	%posY = getWord(%pos, 1);
	%posZ = getWord(%pos, 2);

	%normX = getWord(%norm, 0);
	%normY = getWord(%norm, 1);
	%normZ = getWord(%norm, 2);

	if(%sZ % 2 == 0)
		%posZ = %posZ + %sZ / 10 + 0.05;
	else
		%posZ = %posZ + %sZ / 10 - 0.05;

	if(%normZ < -0.8)
		%posZ -= %sZ * 0.2;
	else if(%normZ > -0.8 && %normZ < 0.8)
		%posZ -= %sZ * 0.1;

	if(%normX > 0.7)
		%posX += %sX * 0.25;
	else if(%normX < -0.7)
		%posX -= %sX * 0.25;

	if(%normY > 0.7)
		%posY += %sY * 0.25;
	else if(%normY < -0.7)
		%posY -= %sY * 0.25;

	if(%sX % 2) %posX += 0.25;
	if(%sY % 2) %posY += 0.25;
	if(%sZ % 2) %posZ += 0.1;

	%pos = PnP_roundShiftVector(%posX SPC %posY SPC %posZ);
	
	if(%sX % 2) %pos = vectorSub(%pos, "0.25 0 0");
	if(%sY % 2) %pos = vectorSub(%pos, "0 0.25 0"); // hacky alignment fixes
	if(%sZ % 2) %pos = vectorSub(%pos, "0 0 0.1");

	return %pos;
}

function rgb2hex( %rgb )
{
	%r = comp2hex( 255 * getWord( %rgb, 0 ) );
	%g = comp2hex( 255 * getWord( %rgb, 1 ) );
	%b = comp2hex( 255 * getWord( %rgb, 2 ) );

	return %r @ %g @ %b;
}

function comp2hex( %comp )
{
	%left = mFloor( %comp / 16 );
	%comp = mFloor( %comp - %left * 16 );

	%left = getSubStr( "0123456789ABCDEF", %left, 1 );
	%comp = getSubStr( "0123456789ABCDEF", %comp, 1 );

	return %left @ %comp;
}
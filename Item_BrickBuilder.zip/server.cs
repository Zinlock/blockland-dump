if(forceRequiredAddon("Brick_Doors") == $Error::AddOn_NotFound)
{
	error("Item_BrickBuilder - Required add-on Brick_Doors not found");
	return;
}

if(forceRequiredAddon("Server_Resources") == $Error::AddOn_NotFound)
{
	error("Item_BrickBuilder - Required add-on Server_Resources not found");
	return;
}

exec("./support.cs");

package BBuilderPackage
{
	function serverCmdUndoBrick(%client)
	{
		%call = %client.undoStack.pop();
		%type = getWord(%call, 1);
		if (%type $= "PROPBRICK")
		{
			%brk = getWord(%call, 0);
			%brk.bbKill();
			return;
		}

		%client.undoStack.push(%call);
		parent::serverCmdUndoBrick(%client);
	}

	function serverCmdUseFxCan(%cl, %idx)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				cancel(%pl.bbDismountSchedule);
				%pl.inInventory = false;
				%pl.bbDismount = false;
				return;
			}
		}

		Parent::serverCmdUseFxCan(%cl, %idx);
	}

	function serverCmdUseSprayCan(%cl, %idx)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				cancel(%pl.bbDismountSchedule);
				%cl.currentColor = %idx;
				%pl.inInventory = false;
				%pl.bbDismount = false;
				return;
			}
		}

		Parent::serverCmdUseSprayCan(%cl, %idx);
	}

	function serverCmdLight(%cl)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				if(isObject(%pl.bbGhost))
				{
					serverCmdRotateBrick(%cl, 1);
					return;
				}
			}
		}

		Parent::serverCmdLight(%cl);
	}

	function serverCmdRotateBrick(%cl, %dir)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				if(isObject(%pl.bbGhost))
				{
					%old = %pl.tempBrick;
					%pl.tempBrick = %pl.bbGhost;
					Parent::serverCmdRotateBrick(%cl, %dir);
					%pl.tempBrick = %old;

					return;
				}
			}
		}

		Parent::serverCmdRotateBrick(%cl, %dir);
	}

	function serverCmdUnUseTool(%cl)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				if(!%pl.inInventory)
				{
					%pl.inInventory = true;
					%pl.bbActiveTime = getSimTime();
					commandToClient(%cl, 'setScrollMode', 2);
					commandToClient(%cl, 'SetActiveTool', %pl.currBBSlot);
				}

				if(getSimTime() - %pl.bbActiveTime < %cl.getPing() + 60)
				{
					commandToClient(%cl, 'SetActiveTool', %pl.currBBSlot);
					return;
				}

				if(!%pl.bbDismount)
				{
					%pl.bbDismountSchedule = schedule(%cl.getPing() + 60, %cl, serverCmdUnUseTool, %cl);
					%pl.bbDismount = true;
					return;
				}

				%pl.bbDismount = false;
			}
		}

		Parent::serverCmdUnUseTool(%cl);
	}

	function serverCmdUseTool(%cl, %idx)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				%pl.currBBSlot = %idx;
				%pl.inInventory = true;
				return;
			}
		}

		Parent::serverCmdUseTool(%cl, %idx);
	}

	function serverCmdDropTool(%cl, %idx)
	{
		%pl = %cl.Player;

		if(isObject(%pl))
		{
			if(%pl.bbActive)
			{
				serverCmdUnUseTool(%cl);
				return;
			}
		}

		Parent::serverCmdDropTool(%cl, %idx);
	}

	function Armor::onRemove(%db, %obj)
	{
		if(isObject(%obj.bbGhost))
			%obj.bbGhost.delete();

		Parent::onRemove(%db, %obj);
	}

	function ProjectileData::onExplode(%db, %obj, %pos)
	{
		Parent::onExplode(%db, %obj, %pos);

		%rad = %db.explosion.damageRadius;
		%dmg = %db.explosion.radiusDamage;

		if(%dmg <= 0)
			return;

		initContainerRadiusSearch(%pos, %rad, $TypeMasks::fxBrickObjectType);
		while(isObject(%col = containerSearchNext()))
		{
			if(!%col.isBuilderBrick)
				continue;

			%ray = containerRayCast(%pos, %col.getPosition(), $TypeMasks::FxBrickObjectType | $TypeMasks::StaticShapeObjectType | $TypeMasks::InteriorObjectType, %col);
			if(isObject(%ray))
				continue;

			%dist = vectorDist(%pos, %col.getPosition());
			%mult = 1 - (%dist / %rad);

			%col.bbDamage(%dmg * %mult);
		}
	}

	function ProjectileData::onCollision(%db, %obj, %col, %fade, %pos, %normal, %vel)
	{
		Parent::onCollision(%db, %obj, %col, %fade, %pos, %normal, %vel);

		if(%db.directDamage <= 0 || !isObject(%col) ||  %col.getClassName() !$= "fxDtsBrick" || !%col.isBuilderBrick)
			return;

		%col.bbDamage(%db.directDamage);
	}

	function fxDtsBrick::onPlant(%brk)
	{
		Parent::onPlant(%brk);
		%brk.schedule(1000, bbCheck);
	}

	function fxDtsBrick::onLoadPlant(%brk)
	{
		Parent::onLoadPlant(%brk);
		%brk.schedule(1000, bbCheck);
	}

	function MinigameSO::onRemove(%mg)
	{
		if(isObject(%mg.builderSet))
		{
			%mg.builderSet.deleteAll();
			%mg.builderSet.delete();
		}

		Parent::onRemove(%mg);
	}

	function MinigameSO::reset(%mg,%cl)
	{
		if(isObject(%mg.builderSet))
			%mg.builderSet.deleteAll();

		Parent::reset(%mg,%cl);
	}
};
activatePackage(BBuilderPackage);

function serverCmdClearBuilderBricks(%cl)
{
	if(!%cl.isSuperAdmin)
	{
		messageClient(%cl, '', "\c5You are not a super admin.");
		return;
	}

	if(!isObject(builderBrickSet))
		new SimSet(builderBrickSet);
	
	%cts = builderBrickSet.getCount();
	builderBrickSet.deleteAll();

	messageAll('MsgClearBricks', "\c3" @ %cl.name @ "\c0 cleared " @ %cts @ " prop brick" @ (%cts != 1 ? "s" : "") @ ".");
}

function fxDTSBrick::bbCheck(%brk)
{
	%name = trim(strReplace(%brk.getName(), "_", " "));
	if(!%brk.isBuilderBrick && firstWord(%name) $= "bbrk")
	{
		%res = strReplace(getWords(%name, 3), " ", "_");
		if(!isObject(%res))
		{
			warn("fxDTSBrick::bbCheck() - invalid brick resource for " @ %brk @ " (" @ %res @ ")");
			return;
		}

		%brk.isBuilderBrick = true;
		%brk.bbHealth = getWord(%name, 1);
		%brk.bbValue = getWord(%name, 2);
		%brk.bbResource = %res.getId();
	}

	if(%brk.isBuilderBrick)
	{
		%brk.setName("_bbrk_" @ %brk.bbHealth @ "_" @ %brk.bbValue @ "_" @ %brk.bbResource.getName());

		if(!isObject(builderBrickSet))
			new SimSet(builderBrickSet);

		if(!builderBrickSet.isMember(%brk))
			builderBrickSet.add(%brk);
	}
}

function fxDTSBrick::bbKill(%brk)
{
	if(!%brk.isBuilderBrick)
		return;
	
	%brk.bbDamage(%brk.bbHealth + 100);
}

function fxDtsBrick::bbDamage(%brk, %dmg)
{
	if(!%brk.isBuilderBrick || %brk.bbHealth <= 0)
		return;

	%brk.bbHealth -= %dmg;

	if(%brk.bbHealth <= 0)
	{
		%itm = new Item()
		{
			dataBlock = %brk.bbResource;
			resources = %brk.bbValue;
			position = %brk.getPosition();
			canPickup = true;
			static = false;
			minigame = getMinigameFromObject(%brk);
			bl_id = %brk.getGroup().bl_id;
		};

		%itm.setCollisionTimeout(%brk);
		%itm.setVelocity((getRandom() * 2 - 1) SPC (getRandom() * 2 - 1) SPC (getRandom() * 2 - 1));
		%itm.schedulePop();

		%brk.bbHealth = 0;
		%brk.killBrick();
	}
	else
		%brk.bbCheck();
}

datablock ItemData(BrickBuilderItem : hammerItem)
{
	shapeFile = "base/data/shapes/brickWeapon.dts";
	uiName = "Brick Builder";

	iconName = "";

	canDrop = true;

	doColorShift = true;
	colorShiftColor = "0.8 0.25 0.25 1.0";

	image = BrickBuilderImage;
};

datablock ShapeBaseImageData(BrickBuilderImage)
{
	shapeFile = "base/data/shapes/brickWeapon.dts";
	emap = true;

	mountPoint = 0;
	offset = "0 0 0";
	eyeOffset = 0;
	rotation = eulerToMatrix( "0 0 0" );

	correctMuzzleVector = true;
	melee = true;

	className = "WeaponImage";

	armReady = true;

	item = BrickBuilderItem;
	ammo = " ";

	casing = "";

	doColorShift = true;
	colorShiftColor = BrickBuilderItem.colorShiftColor;

	projectileType = Projectile;
	projectile = "";

	bbRange = 5;
	bbResource = rsrc_PlasticPipesItem.getId();
	bbSlots = 10;
	bbItem[0]   = brick1x4Data; // brick datablock
	bbHealth[0] = 100; // brick health
	bbValue[0]  = 4; // plastic required to build

	bbItem[1]   = brick2x4Data;
	bbHealth[1] = 200;
	bbValue[1]  = 8;

	bbItem[2]   = brick2x2Data;
	bbHealth[2] = 100;
	bbValue[2]  = 4;

	bbItem[3]   = brick2x2x5GirderData;
	bbHealth[3] = 400;
	bbValue[3]  = 20;

	bbItem[4]   = brick4x1x5WindowData;
	bbHealth[4] = 200;
	bbValue[4]  = 16;

	bbItem[5]   = brick1x4x2BarsData;
	bbHealth[5] = 120;
	bbValue[5]  = 6;

	bbItem[6]   = brick8x8GrillData;
	bbHealth[6] = 175;
	bbValue[6]  = 10;

	bbItem[7]   = brick8x8fData;
	bbHealth[7] = 350;
	bbValue[7]  = 18;

	bbItem[8]   = brick4x4fData;
	bbHealth[8] = 150;
	bbValue[8]  = 12;

	bbItem[9]   = brickDoorGlassCWData;
	bbHealth[9] = 150;
	bbValue[9]  = 16;

	stateName[0]                     	= "Activate";
	stateTimeoutValue[0]             	= 0.01;
	stateTransitionOnTimeout[0]       = "Ready";

	stateName[1]                     	= "Ready";
	stateTransitionOnTriggerDown[1]  	= "Fire";
	stateTimeoutValue[1]              = 0.1;
	stateTransitionOnTimeout[1]       = "Ready";
	stateWaitForTimeout[1]            = false;
	stateScript[1]                    = "onReadyLoop";
	
	stateName[2]                     	= "Fire";
	stateSequence[2]                  = "fire";
	stateScript[2]                    = "onFire";
	stateTransitionOnTimeout[2]       = "Ready";
	stateTimeoutValue[2]              = 0.25;
	stateWaitForTimeout[2]            = true;
};

function BrickBuilderImage::onMount(%img, %pl, %slot)
{
	if(isObject(%pl.getControlObject()) || !isObject(%cl = %pl.Client))
		return;
	
	if(%cl.currentColor $= "")
		%cl.currentColor = 0;
}

function BrickBuilderImage::onUnMount(%img, %pl, %slot)
{
	if(isObject(%pl.getControlObject()) || !isObject(%cl = %pl.Client))
		return;

	%db = %pl.getDataBlock();

	if(%pl.bbActive)
	{
		%pl.bbActive = false;

		if(isObject(%pl.bbGhost))
			%pl.bbGhost.delete();

		%pl.currTool = %pl.lastSlot;

		commandToClient(%cl, 'SetPaintingDisabled', (isObject(%mg = %cl.minigame) ? !%mg.enablePainting : false));
		commandToClient(%cl, 'SetBuildingDisabled', (isObject(%mg = %cl.minigame) ? !%mg.enableBuilding : false));

		commandToClient(%cl, 'PlayGui_CreateToolHud', %db.maxTools);

		for(%i = 0; %i < %db.maxTools; %i++)
			messageClient(%cl, 'MsgItemPickup', "", %i, %pl.tool[%i]);
		
		commandToClient(%cl, 'SetActiveTool', %pl.currTool);
	}
}

function BrickBuilderImage::onReadyLoop(%img, %pl, %slot)
{
	if(isObject(%pl.getControlObject()) || !isObject(%cl = %pl.Client))
		return;
	
	if(%pl.bbActive)
	{
		%pos = %pl.getEyePoint();
		%vec = %pl.getEyeVector();

		%ray = containerRayCast(%pos, vectorAdd(%pos, vectorScale(%vec, %img.bbRange)), $TypeMasks::StaticShapeObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::TerrainObjectType, %pl.bbGhost);

		%pl.bbInRange = false;
		if(isObject(%ray))
		{
			if(!isObject(%pl.bbGhost))
			{
				%pl.bbGhost = new fxDtsBrick(bbghost)
				{
					datablock = %img.bbItem[%pl.currBBSlot];
					colorId = %cl.currentColor;
					client = %cl;
				};

				%cl.brickGroup.add(%pl.bbGhost);

				for(%i = 0; %i < %pl.lastBBAngle; %i++)
					serverCmdRotateBrick(%cl, 1);
			}
			
			%obj = %pl.bbGhost;
			%odb = %obj.getDataBlock();

			if(%odb != %img.bbItem[%pl.currBBSlot])
			{
				%odb = %img.bbItem[%pl.currBBSlot];
				%obj.setDataBlock(%odb);
			}

			if(%obj.getColorID() != %cl.currentColor)
				%obj.setColor(%cl.currentColor);

			%obj.bbSource = %img;
			%obj.bbIdx = %pl.currBBSlot;
			%pl.lastBBAngle = %obj.getAngleID();

			%pl.bbInRange = true;
			%pos = getBrickPos(posFromRaycast(%ray), normalFromRaycast(%ray), %odb, %obj.getAngleID());

			if(vectorDist(%obj.getPosition(), %pos) > 0.05)
			{
				%obj.setTransform(%pos);
				%obj.scopeToClient(%cl);
			}
		}
		else if(isObject(%pl.bbGhost))
			%pl.bbGhost.delete();
		
		%slot = %pl.currBBSlot;
		%cl.centerPrint("<font:impact:24><color:" @ rgb2hex(getColorIdTable(%cl.currentColor)) @ ">" @ %img.bbItem[%slot].uiName @ "<br><font:arial bold:18><color:FFFFFF>" @ %pl.rsrcCount[%img.bbResource] @ "/" @ %img.bbValue[%slot] @ " " @
		                %img.bbResource.resourceTitle @ "<br>" @ %img.bbHealth[%slot] @ "hp", 0.5);
	}
	else
		%cl.centerPrint("<font:impact:24><color:" @ rgb2hex(getColorIdTable(%cl.currentColor)) @ ">Brick Builder<br><font:arial bold:16><color:FFFFFF>Click to activate", 0.2);
}

function BrickBuilderImage::onFire(%img, %pl, %slot)
{
	if(isObject(%pl.getControlObject()) || !isObject(%cl = %pl.Client))
		return;

	if(!%pl.bbActive)
	{
		%pl.bbActive = true;
		%pl.bbActiveTime = getSimTime();

		%pl.lastSlot = %pl.currTool;
		%pl.currBBSlot = 0;

		%slots = %img.bbSlots;

		commandToClient(%cl, 'SetPaintingDisabled', 0);
		commandToClient(%cl, 'SetBuildingDisabled', 1);

		commandToClient(%cl, 'PlayGui_CreateToolHud', %slots);

		for(%i = 0; %i < %slots; %i++)
		{
			if(isObject(%itm = %img.bbItem[%i]))
				messageClient(%cl, 'MsgItemPickup', "", %i, %itm.getId());
			else
				messageClient(%cl, 'MsgItemPickup', "", %i, -1);
		}

		commandToClient(%cl, 'SetActiveTool', %pl.currBBSlot);
	}
	else
	{
		if(!isObject(%pl.bbGhost))
			return;
		
		%obj = %pl.bbGhost;
		%odb = %obj.getDataBlock();
		%slot = %pl.currBBSlot;

		if(%pl.rsrcCount[%img.bbResource] >= %img.bbValue[%slot] && %pl.bbInRange)
		{
			%brk = new fxDtsBrick(_bbrk)
			{
				datablock = %odb;
				position = %obj.position;
				rotation = %obj.rotation;
				colorId = %obj.getColorID();
				client = %cl;
			};

			%brk.isPlanted = true;
			%brk.isBuilderBrick = true;
			%brk.bbHealth = %img.bbHealth[%slot];
			%brk.bbValue = %img.bbValue[%slot];
			%brk.bbResource = %img.bbResource;

			%cl.brickGroup.add(%brk);

			%brk.setTransform(%obj.getTransform());

			%err = %brk.plant();

			if(%err == 0 || %err == 2)
			{
				%pl.takeResourceItem(%img.bbResource.resourceIdx, %img.bbValue[%slot], false);

				%brk.setRayCasting(true);
				%brk.setColliding(true);
				%brk.setRendering(true);
				%brk.setTrusted(1);		
				%brk.isBaseplate = true;
				%brk.willCauseChainKill();

				%cl.undoStack.push(%brk TAB "PROPBRICK");

				if(isObject(%mg = %cl.minigame))
				{
					if(!isObject(%mg.builderSet))
						%mg.builderSet = new SimSet(bbrkset);

					%mg.builderSet.add(%brk);
					%brk.sourceMinigame = %mg;
				}
			}
			else
			{
				%brk.delete();
				%cl.play2D(errorSound);
			}
		}
		else
			%cl.play2D(errorSound);
	}
}
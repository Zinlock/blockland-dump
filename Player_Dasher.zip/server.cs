if(forceRequiredAddOn("Item_Skis") == $Error::AddOn_NotFound)
{
	error("Player_Dasher Error: required add-on Item_Skis not found");
	return;
}

function mFloatLerp(%from, %to, %at)
{
  return %to + %at * (%from - %to); // to and from are flipped... whoops
}

function lerpColor(%from, %to, %at)
{
	%r = mFloatLerp(getWord(%to, 0), getWord(%from, 0), %at);
	%g = mFloatLerp(getWord(%to, 1), getWord(%from, 1), %at);
	%b = mFloatLerp(getWord(%to, 2), getWord(%from, 2), %at);
	%a = mFloatLerp(getWord(%to, 3), getWord(%from, 3), %at);

	return %r SPC %g SPC %b SPC %a;
}

datablock AudioProfile(Dash1Sound)
{
	filename    = "./dash1.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(Dash2Sound)
{
	filename    = "./dash2.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(Dash3Sound)
{
	filename    = "./dash3.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(ImpactPlayerSoftSound)
{
	filename    = "./impact_player_soft.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(ImpactPlayerHardSound)
{
	filename    = "./impact_player_hard.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(ImpactVehicleSoftSound)
{
	filename    = "./impact_veh_soft.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock AudioProfile(ImpactVehicleHardSound)
{
	filename    = "./impact_veh_hard.wav";
	description = AudioDefault3D;
	preload = true;
};

datablock ParticleData(DashTrailFXParticle)
{
	dragCoefficient      = 0.3;
	gravityCoefficient   = -0.1;
	windCoefficient		= 0;
	inheritedVelFactor   = 0.1;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/ring";

	spinSpeed			= 0.0;
	spinRandomMin	= 0.0;
	spinRandomMax	= 0.0;

	colors[0]	= "1 1 0.3 0.1";
	colors[1]	= "1 1 0.3 0.1";
	colors[2]	= "0.6 0.0 0.0 0.0";

	sizes[0]	= 2.0;
	sizes[1]	= 2.5;
	sizes[2]	= 2.5;
	
	times[0]	= 0.0;
	times[1]	= 0.2;
	times[2]	= 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(DashTrailFXEmitter)
{
	ejectionPeriodMS = 8;
	periodVarianceMS = 0;
	ejectionVelocity = 0.0;
	velocityVariance = 0.0;
	ejectionOffset   = 0.0;
	thetaMin         = 0;
	thetaMax         = 1;
	phiReferenceVel  = 360;
	phiVariance      = 0;

	overrideAdvance = false;

	particles = "DashTrailFXParticle";
};

datablock ShapeBaseImageData (DashTrailFXImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = 0;
	mountPoint = 8;
	offset = "0 0 1";
	doRetraction = 0;
	firstPersonParticles = 0;

	stateName[0] = "Ready";
	stateTransitionOnTimeout[0] = "FireA";
	stateTimeoutValue[0] = 0.01;

	stateName[1] = "FireA";
	stateTransitionOnTimeout[1] = "FireB";
	stateWaitForTimeout[1] = True;
	stateTimeoutValue[1] = 0.05;
	stateEmitter[1] = DashTrailFXEmitter;
	stateEmitterTime[1] = 0.05;

	stateName[2] = "FireB";
	stateTransitionOnTimeout[2] = "FireA";
	stateWaitForTimeout[2] = True;
	stateTimeoutValue[2] = 0.05;
	stateEmitter[2] = DashTrailFXEmitter;
	stateEmitterTime[2] = 0.05;
};

datablock PlayerData(PlayerDasherArmor : PlayerStandardArmor)
{
	airControl = 0.4;//0.5;
  minJetEnergy = 0;
  jetEnergyDrain = 0;
  canJet = 0;
	maxForwardSpeed = 9;
	maxSideSpeed = 7;
	maxBackwardSpeed = 5;
	rechargeRate = 0.6;

	minImpactSpeed = 20;

	dashEnergy = 55;
	dashStandEnergy = 40;
	dashForce = 55;
	dashBackForce = 25;
	tumbleMinForce = 20;
	tumbleForce = 0.8;
	tumbleRegen = 10;
	vehicleMinForce = 25;
	vehicleForce = 0.85;
	vehicleRegen = 15;
	groundRegen = 8;

  uiName = "Dasher Player";
  showEnergyBar = true;
};

function PlayerDasherArmor::onTrigger(%this, %obj, %slot, %val)
{
	if(%slot == 4 && %val && !%obj.isMounted())
	{
		if((%obj.isCrouched() && %obj.getEnergyLevel() >= %this.dashEnergy) || (!%obj.isCrouched() && %obj.getEnergyLevel() >= %this.dashStandEnergy))
		{
			if(vectorLen(%obj.getVelocity()) < %this.dashForce && !%obj.isDashing)
			{
				%vel = %obj.getVelocity();
				%vec = vectorNormalize(%vel);

				if(vectorLen(%vel) <= 4.5)
					%vec = %obj.getForwardVector();

				if(%obj.isCrouched())
				{
					%obj.setEnergyLevel(%obj.getEnergyLevel() - %this.dashEnergy);
					%eye = %obj.getEyeVector();
					%dot = VectorDot(%eye, %vec);
					if(%dot < 0.2)
					{
						%dot = VectorDot(%eye, "0 0 -1");
						if(%dot > 0.85)
							%vec = vectorScale(%eye, %this.dashForce);
						else
							%vec = vectorScale(%eye, %this.dashBackForce);
					}
					else
						%vec = vectorScale(%eye, %this.dashForce);
				}
				else
				{
					%obj.setEnergyLevel(%obj.getEnergyLevel() - %this.dashStandEnergy);
					%vec = vectorScale(%vec, %this.dashForce);
				}

				%obj.setVelocity(%vec);

				%obj.isDashing = true;
				cancel(%obj.fdi);
				%obj.fdi = schedule(400, %obj, eval, %obj @ ".isDashing = false;");

				%obj.DashStop(0, 400, 10, false);

				%obj.playAudio(2, Dash @ getRandom(1, 3) @ Sound);
				%obj.mountImage(DashTrailFXImage, 3);
				%obj.schedule(300, unmountImage, 3);
			}
		}
	}

	Parent::onTrigger(%this, %obj, %slot, %val);
}

function PlayerDasherArmor::onImpact(%this, %obj, %col, %vec, %force)
{
	if(%col.getType() & ($TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType))
	{
		if(%col.getDataBlock().getName() $= "DeathVehicle")
			%col = %col.getMountedObject(0);

		%owned = 0;
		if (!isObject (%obj.client.miniGame))
		{
			if (isObject (%col.spawnBrick))
			{
				if (%col.spawnBrick.getGroup ().bl_id == %obj.client.bl_id || %col.spawnBrick.getGroup ().bl_id == 888888)
				{
					%owned = 1;
				}
			}
		}

		if(miniGameCanDamage(%obj, %col) == 1 || %owned)
		{
			if(%col.getType() & $Typemasks::PlayerObjectType)
			{
				if(%force > %this.tumbleMinForce && !%obj.tumbleImmunity && !%col.tumbleImmunity && getSimTime() - %col.lastPushTime > 100)
				{
					if(%obj.isDashing && %col.isDashing)
					{
						%obj.lastPusher = %col;
						%obj.lastPushTime = getSimTime();
						%obj.lastDamager = %col;
						%obj.lastDamageTime = getSimTime();
						
						%col.lastPusher = %obj;
						%col.lastPushTime = getSimTime();
						%col.lastDamager = %obj;
						%col.lastDamageTime = getSimTime();

						%vel = vectorScale(vectorNormalize(%vec), %force * %this.tumbleForce * 0.5);//vectorScale(vectorNormalize(%vec), %force);
						%obj.setVelocity(%vel);
						tumble(%obj, 3000);
						// %obj.DashStop(200, 400, 9, false);

						%col.setVelocity(vectorScale(%vel, -1));
						tumble(%col, 3000);
						// %col.DashStop(200, 400, 9, false);

						serverPlay3D(ImpactPlayerHardSound, %col.getHackPosition());
					}
					else
					{
						if(%obj.isDashing)
							%obj.setEnergyLevel(%obj.getEnergyLevel() + %this.tumbleRegen);

						if(isEventPending(%col.tumbleImmunitySchedule))
							cancel(%col.tumbleImmunitySchedule);
						
						%col.setTumbleImmunity(true);

						%col.lastPusher = %obj;
						%col.lastPushTime = getSimTime();
						%col.lastDamager = %obj;
						%col.lastDamageTime = getSimTime();

						%obj.setVelocity(vectorScale(vectorNormalize(%vec), %force));
						%obj.DashStop(0, 250, 9, false);

						%col.setVelocity(vectorScale(vectorNormalize(%vec), -%force * %this.tumbleForce));
						%col.addVelocity(getRandom()-0.5 SPC getRandom()-0.5 @ %force / 10);
						tumble(%col, 3000);

						if(vectorLen(%col.getVelocity()) > 23)
							serverPlay3D(ImpactPlayerHardSound, %col.getHackPosition());
						else
							serverPlay3D(ImpactPlayerSoftSound, %col.getHackPosition());
						
						%col.tumbleImmunitySchedule = %col.schedule(1000, setTumbleImmunity, false);
					}
				}
			}
			else if(%col.getType() & $TypeMasks::VehicleObjectType)
			{
				if(%force > %this.vehicleMinForce && getSimTime() - %col.lastPushTime > 100)
				{
					if(%obj.isDashing)
						%obj.setEnergyLevel(%obj.getEnergyLevel() + %this.vehicleRegen);

					if(isEventPending(%col.tumbleImmunitySchedule))
						cancel(%col.tumbleImmunitySchedule);
					
					%col.setTumbleImmunity(true);

					%col.lastPusher = %obj.client;
					%col.lastPushTime = getSimTime();
					%col.lastDamager = %obj;
					%col.lastDamageTime = getSimTime();

					%obj.setVelocity(vectorScale(vectorNormalize(%vec), %force));
					%obj.DashStop(0, 250, 9, false);

					%sub = vectorSub(%col.getWorldBoxCenter(), %obj.getHackPosition());

					if(VectorDot(%obj.getEyeVector(), vectorNormalize(%sub)) <= 0.2)
						%alt = vectorScale(vectorNormalize(%sub), %force * %this.vehicleForce);
					else
						%alt = vectorScale(%obj.getEyeVector(), %force * %this.vehicleForce);
					
					if(vectorLen(%alt) > 200)
						%alt = vectorScale(vectorNormalize(%alt), 200);
					
					%col.setVelocity(%alt);//applyImpulse(vectorSub(%col.getWorldBoxCenter(), %obj.getEyeVector()), %alt);
					
					if(vectorLen(%col.getVelocity()) > 30)
						serverPlay3D(ImpactVehicleHardSound, %col.getWorldBoxCenter());
					else
						serverPlay3D(ImpactVehicleSoftSound, %col.getWorldBoxCenter());

					%col.tumbleImmunitySchedule = %col.schedule(400, setTumbleImmunity, false);
				}
			}
		}
	}
	else
	{
		if(%force > %this.tumbleMinForce && %obj.isDashing && !%obj.tumbleImmunity)
		{
			%obj.setEnergyLevel(%obj.getEnergyLevel() + %this.groundRegen);

			%vel = vectorScale(vectorNormalize(%vec), %force);

			if(vectorDot(vectorNormalize(%vel), vectorNormalize(%obj.getVelocity())) > -0.9)
				%obj.addVelocity(%vel);
			else
				%obj.setVelocity(vectorScale(%vel, 0.4));

			%obj.DashStop(0, 350, 9, false);

			serverPlay3D(ImpactVehicleSoftSound, %obj.getHackPosition());
		}
	}

	%sp = %this.minImpactSpeed;
	%this.minImpactSpeed = 30;
	Parent::onImpact(%this, %obj, %col, %vec, %force);
	%this.minImpactSpeed = %sp;
}

function Player::DashStop(%pl, %delay, %time, %maxVel, %noZ)
{
	cancel(%pl.sst);

	%pl.dashStartVel = vectorLen(%pl.getVelocity());
	%pl.dashStartTime = getSimTime();

	%pl.sst = %pl.schedule(%delay, DashStopTick, %time, %maxVel, %noZ);
}

function Player::DashStopTick(%pl, %time, %maxVel, %noZ)
{
	cancel(%pl.sst);

	if(vectorLen(%pl.getVelocity()) < %maxVel)
		return;

	%at = (getSimTime() - %pl.dashStartTime) / %time;

	if(%at >= 1)
		%at = 1;

	%vel = mFloatLerp(%pl.dashStartVel, %maxVel, 1 - %at);
	%vec = vectorScale(vectorNormalize(%pl.getVelocity()), %vel);
	
	if(%noZ)
		%vec = setWord(%vec, 2, getWord(%pl.getVelocity(), 2));
	
	%pl.setVelocity(%vec);
	
	if(%at < 1)
		%pl.sst = %pl.schedule(50, DashStopTick, %time, %maxVel, %noZ);
}

function ShapeBase::setTumbleImmunity(%this, %value)
{
	%this.tumbleImmunity = %value;
}

package TumbleCollision
{
	function Armor::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType)
	{
		if((%damageType == $DamageType::Vehicle || %damageType == $DamageType::Fall || %damageType == $DamageType::Impact) && %obj.isDashing)
			return;
		
		Parent::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType);
	}
	
	function WheeledVehicleData::onCollision(%this, %obj, %col, %vec, %speed)
	{
		if(%col.isDashing)
			return;
		
		Parent::onCollision(%this, %obj, %col, %vec, %speed);
	}

	function Vehicle::damage(%vehicle, %source, %pos, %damage, %type)
	{
		if(%vehicle.getDataBlock().getName() $= "deathVehicle")
		{
			if(%vehicle.getDamageLevel() + %damage >= %vehicle.getDataBlock().maxDamage)
			{
				if(isObject(%player = %vehicle.getMountedObject(0)))
				{
					if(isObject(%client = %player.client))
					{
						%vehicle.unMountObject(%player);
						%client.setControlObject(%player);
						%client.camera.setMode(%player, "Observer");
					}
				}
			}
		}
		
		Parent::damage(%vehicle, %source, %pos, %damage, %type);
	}
};
activatePackage(TumbleCollision);
registerInputEvent(fxDtsBrick,"onMinigamePlayerLoop","Self fxDtsBrick\tPlayer Player\tClient GameConnection");
registerOutputEvent(Minigame, "doPlayerLoop", "string 60 60", 1);

$MinigameAllInputID = inputEvent_GetInputEventIdx("onMinigamePlayerLoop");
$MinigameAllOutputID = outputEvent_getOutputEventIdx(Minigame,"doPlayerLoop");

function MinigameSO::doPlayerLoop(%mini, %targ)
{
	for(%i=0;%i<getWordCount($MinigameAllInputList);%i++)
	{
		%brick = getWord($MinigameAllInputList, %i);
		if(isObject(%brick))
		{
			if(getMinigameFromObject(getBrickGroupFromObject(%brick)) == %mini)
			{
				if(strLen(%mini.region))
				{
					if(%mini.class $= "Slayer_MinigameSO" && !%mini.isPointInRegion(%brick.getPosition()))
						continue;
				}
				
				if(trim(%targ) !$= "" && %brick.getName() !$= ("_" @ trim(%targ)))
					continue;
				
				for(%m = 0; %m < %mini.numMembers; %m++)
				{
					%client = %mini.member[%m];
					if(%mini.useAllPlayersBricks)
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						%brick.processInputEvent("onMinigamePlayerLoop",%client);
					}
					else if(!%mini.useAllPlayersBricks && getBrickGroupFromObject(%brick) == getBrickGroupFromObject(%client))
					{
						$inputTarget_Self = %brick;
						$inputTarget_Player = %client.player;
						$inputTarget_Client = %client;
						%brick.processInputEvent("onMinigamePlayerLoop",%client);
					}
				}
			}
		}
	}
}

package Event_MinigameAll
{
	function serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4)
	{
		if(%input == $MinigameAllInputID)
		{
			if(%output == $MinigameAllOutputID)
				return;
			
			$MinigameAllInputList = addItemToList($MinigameAllInputList,%client.wrenchBrick);
		}
		
		return Parent::serverCmdAddEvent(%client,%delay,%input,%target,%a,%b,%output,%para1,%para2,%para3,%para4);
	}
	function serverCmdClearEvents(%client)
	{
		if(hasItemOnList($MinigameAllInputList,%client.wrenchBrick))
		{
			$MinigameAllInputList = removeItemFromList($MinigameAllInputList,%client.wrenchBrick);
		}

		Parent::serverCmdClearEvents(%client);
	}
	function fxDtsBrick::onDeath(%brick)
	{
		if(hasItemOnList($MinigameAllInputList,%brick))
		{
			$MinigameAllInputList = removeItemFromList($MinigameAllInputList,%brick);
		}

		Parent::onDeath(%brick);
	}
};
activatePackage(Event_MinigameAll);

function addItemToList(%string,%item)
{
	if(hasItemOnList(%string,%item))
		return %string;

	if(%string $= "")
		return %item;
	else
		return %string SPC %item;
}
function hasItemOnList(%string,%item)
{
	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
			return 1;
	}
	return 0;
}
function removeItemFromList(%string,%item)
{
	if(!hasItemOnList(%string,%item))
		return %string;

	for(%i=0;%i<getWordCount(%string);%i++)
	{
		if(getWord(%string,%i) $= %item)
		{
			if(%i $= 0)
				return getWords(%string,1,getWordCount(%string));
			else if(%i $= getWordCount(%string)-1)
				return getWords(%string,0,%i-1);
			else
				return getWords(%string,0,%i-1) SPC getWords(%string,%i+1,getWordCount(%string));
		}
	}
}
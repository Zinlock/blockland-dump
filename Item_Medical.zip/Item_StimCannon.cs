datablock ProjectileData(medi_stimGunProjectile)
{
   projectileShapeName = "./needle.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = gunExplosion;
   particleEmitter     = medi_gauzeGunFlashEmitter;

   muzzleVelocity      = 50;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.5;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(medi_stimGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./HYPOJET.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Stim Gun";
	iconName = "./icon_hypojet";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = medi_stimGunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(medi_stimGunImage)
{
   // Basic Item properties
	shapeFile = "./HYPOJET.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 .06";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = medi_stimGunItem;
   ammo = " ";
   projectile = medi_stimGunProjectile;
   projectileType = Projectile;

	// casing = medi_gauzeGunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;
	minShotTime = 860;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = medi_gauzeGunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.15;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTimeoutValue[3]            = 0.7;
	stateTransitionOnTimeout[3]     = "Ready";
	stateSequence[4]	= "Ready";

};

datablock ShapeBaseImageData(medi_stimGunHealimage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/empty.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 6;
   offset = "0 0 -1";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.04;
	stateTransitionOnTimeout[0]      = "Heal1";
	stateScript[0]                  = "onActivate";

	stateName[1]                     = "Heal1";
	stateTransitionOnTimeout[1]      = "Done";
	stateTimeoutValue[1]             = 0.02;
	stateScript[1]                  = "onHeal";
	stateAllowImageChange[1]         = false;
	stateEmitter[1]			= healEmitter;
	stateEmitterTime[1]		= 0.02;
	stateEmitterNode[1]		= "muzzleNode";

	stateName[2]			= "Done";
	stateTransitionOnTimeout[2]      = "Activate";
	stateTimeoutValue[2]             = 0.02;
};

function medi_stimGunHealImage::onHeal(%this,%obj,%slot)
{
	%obj.medi_Healing -= %obj.medi_healingSpeed;

	if(isActivePackage(swol_downed) && %obj.isDowned)
	{
		%obj.downed_psuedoHealth += %obj.medi_healingSpeed;
		if(%obj.downed_psuedoHealth >= (%db = %obj.getDatablock()).maxDamage)
		{
			%obj.downed_psuedoHealth = %db.maxDamage;
			%obj.setDowned(0);
		}
	}
	else
		%obj.setDamageLevel(%obj.getDamageLevel() - %obj.medi_healingSpeed);

	if(%obj.medi_healing <= 0 || %obj.getDamageLevel() == 0 || %obj.getDamagePercent() >= 1.0)
	{
		%obj.unMountImage(%slot);
		%obj.medi_healing = 0;
		%obj.medi_healingSpeed = 0;
	}
}

function medi_stimGunImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
	serverPlay3D(medi_gauzeGunShot1Sound,%obj.getPosition());

	return Parent::onFire(%this,%obj,%slot);	
}

function medi_stimGunProjectile::onCollision(%this,%obj,%col,%pos,%fade)
{
	medi_Heal(%obj, %col, 5, 15, 2, true);
	Parent::onCollision(%this,%obj,%col,%pos,%fade);
}

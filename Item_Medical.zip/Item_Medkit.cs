datablock ItemData(medi_medpackItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./MEDKIT.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Medkit";
	iconName = "./Icon_Medpack";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = medi_medpackImage;
	canDrop = true;
};

datablock ShapeBaseImageData(medi_medpackImage)
{
	// Basic Item properties
	shapeFile = "./MEDKIT.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0.1";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	stimChargeTime = 4;
	stimAltChargeTime = 2.4;
	stimUseTime = 2.2;
	stimHealSelfAmount = 75;
	stimHealOtherAmount = 65;
	stimHealSelfSpeed = 3;
	stimHealOtherSpeed = 3;
	stimHelpSelfUp = true;
	stimHelpOtherUp = false;
	stimUseCount = 2;
	stimDepleteOnMain = true;
	stimDepleteOnAlt = true;
	stimName = "Medkit";
	
	altTriggerEnabled = true;

	className = "WeaponImage";
	item = medi_medpackItem;

	//raise your arm up or not
	armReady = true;

	doColorShift = false;

	// Initial start up state
	stateName[0]                     = "Ready";
	stateScript[0]								= "onReady";
	stateTransitionOnTriggerDown[0]  = "StimCharge";

	stateName[1]                     = "StimCharge";
	//stateTransitionOnTimeout[1]      = "Fire";
	stateScript[1]                   = "onChargeStart";
	stateTimeoutValue[1]		   = 60; //just in case you REALLY want to get crazy with the use time
	stateTransitionOnTriggerUp[1] = "Cancel";
	stateTransitionOnNoAmmo[1] = "Next";
	stateTransitionOnNotLoaded[1] = "Cancel";
	stateTransitionOnTimeout[1] = "Next";
	stateWaitForTimeout[1] = false;

	stateName[4] 				= "Cancel";
	stateScript[4]                   = "onChargeStop"; // this is packaged, all it serves by default is to print "Canceled healing."
	stateTransitionOnTimeout[4] = "Ready";
	stateTimeoutValue[4]				= 0.1;

	stateName[3]                     = "Next";
	stateTimeoutValue[3]		   = 0.1;
	stateTransitionOnTriggerUp[3]      = "Ready";
	stateTransitionOnNoAmmo[3] = "Fire";

	stateName[2]                     = "Fire";
	stateTransitionOnTimeout[2]      = "Ready";
	stateScript[2]                   = "onFire";
	stateTimeoutValue[2]		   = 2;
};

function medi_medpackImage::onReady(%this, %obj, %slot)
{
	%obj.setImageAmmo(0,1);
	%obj.setImageLoaded(0,1);
	%obj.playThread(1, armReadyBoth);
}

function medi_medpackImage::onChargeStart(%this, %obj, %slot)
{
	if(!%obj.stimCheck(%this)) return;

	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, shiftDown);
	%obj.stimStart(%this);
}

function medi_medpackImage::onFire(%this,%obj,%slot)
{
	if(!%obj.stimCheck(%this)) return;
	
	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, plant);
	%obj.stimUse(%this);
}

function medi_medpackImage::onAltTrigger(%this, %player, %playerDB, %triggerSlot, %val)
{
	if(%val && %triggerSlot == 4)
	{
		if(!%player.stimCheck(%this, true)) return;
		%player.playThread(2, shiftDown);
		serverPlay3D(medi_clickHealSound, %player.getPosition());
		%player.stimFire(%this, true);
	}
}
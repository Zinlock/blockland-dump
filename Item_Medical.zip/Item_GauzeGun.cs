//audio
datablock AudioProfile(medi_gauzeGunShot1Sound)
{
   filename    = "./syringe.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(medi_gauzeGunReloadSound)
{
   filename    = "./needle_reload.wav";
   description = AudioClose3d;
   preload = true;
};

//muzzle flash effects
datablock ParticleData(medi_gauzeGunFlashParticle)
{
	dragCoefficient      = 9;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 16.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 1 1 0.01";
	colors[1]     = "1 1 1 0.1";
	colors[2]     = "1 1 1 0.02";
	colors[3]     = "1 1 1 0.0";
	sizes[0]      = 0.15;
	sizes[1]      = 0.61;
	sizes[2]      = 0.25;
	sizes[3]      = 0.1;
   times[0] = 0.0;
   times[1] = 0.1;
   times[2] = 0.4;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(medi_gauzeGunFlashEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "medi_gauzeGunFlashParticle";
};

datablock ProjectileData(medi_gauzeGunProjectile)
{
   projectileShapeName = "./needle.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = gunExplosion;
   particleEmitter     = medi_gauzeGunFlashEmitter;

   muzzleVelocity      = 200;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

//////////
// item //
//////////
datablock ItemData(medi_gauzeGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./gauze_gun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Gauze Gun";
	iconName = "./gauzegun";
	doColorShift = false;
	colorShiftColor = "0.25 0.25 0.25 1.000";

	 // Dynamic properties defined by the scripts
	image = medi_gauzeGunImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(medi_gauzeGunImage)
{
   // Basic Item properties
	shapeFile = "./gauze_gun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 .06";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = medi_gauzeGunItem;
   ammo = " ";
   projectile = medi_gauzeGunProjectile;
   projectileType = Projectile;

	// casing = medi_gauzeGunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;
	minShotTime = 860;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = medi_gauzeGunItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.15;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;

	stateName[3] = "Smoke";
	stateTimeoutValue[3]            = 0.15;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTimeoutValue[3]            = 0.7;
	stateTransitionOnTimeout[3]     = "Ready";
	stateSequence[4]	= "Ready";

};

datablock ParticleData(healParticle)
{
	dragCoefficient      = 2.25;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 1400;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 0.0;
	spinRandomMin		= 0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "1 1 1 0.1";
	colors[1]     = "1 1 1 0.1";
	colors[2]     = "0.2 0.2 0.2 0.1";
	colors[3]     = "1 1 1 0.0";
	sizes[0]      = 4.35;
	sizes[1]      = 0.25;
	sizes[2]      = 0.20;
	sizes[3]      = 0.10;
	windCoefficient = 0.0;

	times[0]      = 0.0;
	times[1]      = 0.1;
	times[2]      = 0.9;
	times[3]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(healEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 4.0;
   velocityVariance = 3.0;
   ejectionOffset   = 0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 375;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "healParticle";
};

datablock ShapeBaseImageData(medi_gauzeGunHealimage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/empty.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 6;
   offset = "0 0 -1";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.04;
	stateTransitionOnTimeout[0]      = "Heal1";
	stateScript[0]                  = "onActivate";

	stateName[1]                     = "Heal1";
	stateTransitionOnTimeout[1]      = "Done";
	stateTimeoutValue[1]             = 0.02;
	stateScript[1]                  = "onHeal";
	stateAllowImageChange[1]         = false;
	stateEmitter[1]			= healEmitter;
	stateEmitterTime[1]		= 0.02;
	stateEmitterNode[1]		= "muzzleNode";

	stateName[2]			= "Done";
	stateTransitionOnTimeout[2]      = "Activate";
	stateTimeoutValue[2]             = 0.02;
};

function medi_gauzeGunHealImage::onHeal(%this,%obj,%slot)
{
	%obj.medi_Healing -= %obj.medi_healingSpeed;

	if(isActivePackage(swol_downed) && %obj.isDowned)
	{
		%obj.downed_psuedoHealth += %obj.medi_healingSpeed;
		if(%obj.downed_psuedoHealth >= (%db = %obj.getDatablock()).maxDamage)
			%obj.downed_psuedoHealth = %db.maxDamage;
	}
	else
		%obj.setDamageLevel(%obj.getDamageLevel() - %obj.medi_healingSpeed);

	if(%obj.medi_healing <= 0 || %obj.getDamageLevel() == 0 || %obj.getDamagePercent() >= 1.0)
	{
		%obj.unMountImage(%slot);
		%obj.medi_healing = 0;
		%obj.medi_healingSpeed = 0;
	}
}

function medi_gauzeGunImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2, plant);
	serverPlay3D(medi_gauzeGunShot1Sound,%obj.getPosition());

	return Parent::onFire(%this,%obj,%slot);	
}

function medi_gauzeGunProjectile::onCollision(%this,%obj,%col,%pos,%fade)
{
	medi_Heal(%obj, %col, 10, 30, 2);
	Parent::onCollision(%this,%obj,%col,%pos,%fade);
}

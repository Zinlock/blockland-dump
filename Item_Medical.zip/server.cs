function TT_defaultIfUnset(%pref, %default)
{
   if($Pref::Server::TT["::" @ %pref] $= "")
      $Pref::Server::TT["::" @ %pref] = %default;
}

TT_defaultIfUnset("MedicHealEnemy", 0);
TT_defaultIfUnset("MedicHealBots", 1);

//medigun.cs
//we need the gun add-on for this, so force it to load
if(ForceRequiredAddOn("Weapon_Gun") == $Error::AddOn_NotFound)
{
   //we don't have the gun, so we're screwed
   error("Item_Medical Error: Required Add-On Weapon_Gun not found");
   return;
}

exec("./ItemStats.cs");
exec("./Support_ImageAltTrigger.cs");
exec("./Support_StimCharge.cs");
exec("./Item_GauzeGun.cs");
exec("./Item_StimCannon.cs");
exec("./Item_Stimpack.cs");
exec("./Item_PillPack.cs");
exec("./Item_Medkit.cs");
exec("./emote_heal.cs");

datablock ProjectileData(medi_shortHealProjectile)
{
   projectileShapeName = "";
   directDamage        = 0;
   directDamageType    = $DamageType::medi_gauzeGun;
   radiusDamageType    = $DamageType::medi_gauzeGun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   // explosion           = "";
   particleEmitter     = medi_gauzeGunFlashEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 0;

   armingDelay         = 00;
   lifetime            = 100;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = true;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};

datablock AudioProfile(medi_clickHealSound)
{
   filename    = "./stimpack.wav";
   description = AudioClose3d;
   preload = true;
};

// think of this like minigameCanDamage but for healing
// make sure %client exists or is 0
function TT_canHeal(%client, %targetObject)
{
	if(isObject(%player = %client.Player) && %targetObject == %player || isObject(%targetObject.Client) && %targetObject.Client == %client)
		return 1;
	
	if(%client && (%targetObject.getType() & $TypeMasks::PlayerObjectType) && ($Pref::Server::TT::MedicHealBots || %targetObject.getClassName() $= "Player"))
	{
		if(isObject(%mini = getMinigameFromObject(%client)))
		{
			if(%mini == getMinigameFromObject(%targetObject))
			{
				if(!$Pref::Server::TT::MedicHealEnemy && %mini.isSlayerMinigame)
				{
					%team1 = %client.getTeam();
					if(isObject(%targetObject.client))
						%team2 = %targetObject.client.getTeam();
					else
						%team2 = %targetObject.getTeam();
					if(!%team1 || %team1.isAlliedTeam(%team2))
						return 1;
				}
				else
				{
					return 1;
				}
			}
		}
		else if($Server::LAN)
		{
			return 1;
		}
	}
	return 0;
}

// %col - player to heal
// %obj - source; projectile or player
// %healBurst - amount to heal before any healing over time is applied
// %overTime - (optional) amount to heal over time
	// %speed - (optional) how much health per tick to heal
//%res - (optional) if swollow's downed is enabled, help up when reaching full health
function medi_Heal(%obj, %col, %healBurst, %overTime, %speed, %res)
{
	if(%col.getClassName() !$= "Player" && %col.getClassName() !$= "AIPlayer")
		return;
	
	if(isObject(%obj.client))
		%healer = %obj.client;
	else if(isObject(%obj.sourceObject))
		%healer = %obj.sourceObject;
	
	%canHeal = 0;
	if(TT_canHeal(%healer, %col))
		%canHeal = 1;
	else if(!isObject(%healer.miniGame) && isObject(%col.spawnBrick))
	{
		if(%col.spawnBrick.getGroup().bl_id == getBL_IDFromObject(%obj) || %col.spawnBrick.getGroup().bl_id == 888888)
			%canHeal = 1;
	}

	if(%canHeal)
	{
		if(%col.getDamageLevel() >= %healBurst)
			%col.spawnExplosion(healCrossProjectile, %col.getScale());
		%col.setDamageLevel(%col.getDamageLevel() - %healBurst);
		
		if(%overTime > 0)
		{
			if(%speed > 0)
				%col.medi_healingSpeed = %speed;
			else
				%col.medi_healingSpeed = 1;
			
			%col.medi_Healing = %overTime;
			if(!%res) %col.mountImage(medi_gauzeGunHealImage, 3);
			else %col.mountImage(medi_stimGunHealImage, 3);
		}
	}
}

function Player::removeItemFromDatablock(%this, %item, %all)
{
	if(isObject(%this) && isObject(%cl = %this.client))
	{
		if(%item > 0)
		{
			for(%i = 0; %i < %this.getDatablock().maxTools; %i++)
			{
				%tool = %this.tool[%i].getID();
				if(%tool == %item.getID())
				{
					%this.tool[%i] = 0;
					messageClient(%cl, 'MsgItemPickup', '', %i, 0);
					if(%this.currTool==%i)
					{
						%this.unMountImage(0);
						%this.updateArm(0);
					}
					if(!%all)
						break;
				}
			}
		}
	}
}

function Player::removeItemFromSlot(%this, %item)
{
	if(isObject(%this) && isObject(%cl = %this.client))
	{
		if(%item >= 0)
		{
			if(isObject(%this.tool[%item]))
			{
				%this.tool[%item] = 0;
				messageClient(%cl, 'MsgItemPickup', '', %item, 0);
				if(%this.currTool == %item)
				{
					%this.unMountImage(0);
					%this.updateArm(0);
				}
			}
		}
	}
}

function isActivePackage(%pkg)
{
	for(%i = 0; %i < getNumActivePackages(); %i++)
	{
		if(getActivePackage(%i) $= %pkg)
			return true;
	}

	return false;
}

$ModularMedicalItems = true;
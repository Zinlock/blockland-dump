// Support_StimCharge.cs, bunch of functions for medical items by Zinlock (35032)
// this will most likely not work if the states are different from the syringe's

// images have a ton of fields that need to be filled for use with this system:
	// stimChargeTime = 10; // time to recharge main fire
	// stimAltChargeTime = 4.2; // time to recharge alt fire
	// stimUseTime = 2.6; // time to use on self in seconds
	// stimHealSelfAmount = 40; // total health to add
	// stimHealOtherAmount = 40;
	// stimHealSelfSpeed = 2; // health per tick
	// stimHealOtherSpeed = 3;
	// stimHelpSelfUp = false; // help players up with swollow's downed on, useless without it
	// stimHelpOtherUp = false;
	// stimUseCount = 0; // maximum uses before discarded, <= 0 is infinite
	// stimName = "Syringe"; // name to display in centerprint
	// stimDepleteOnMain = false; // deplete stim charges on main/self
	// stimDepleteOnAlt = false; // deplete charges on alt/others

// Player.stimCheck(%image, %alt) => check if Player can use the stim image
		// %alt skips the health check since alt fire is only used to heal others
// Player.stimStart(%image) => start charging the stim image
		// will automatically get canceled even if Player.stimCheck(%image) was never called
// Player.stimFire(%image, %alt, %proj) => fires the stim projectile;
		// %alt needs to be true if stimFire was called on alt-fire
		// %proj is the projectile to use; defaults to the syringe's alt fire projectile

// ==== //

function Player::medi_UseChargeLoop(%pl, %img)
{
	if(!isObject(%pl) || %pl.getDamagePercent() >= 1.0)
		return;
	cancel(%pl.spackCharge);

	if(%pl.getImageState(0) !$= "StimCharge" || !%pl.stimCheck(%img)) return;

	%pl.stimCharge++;
	
	%text = "<font:arial:13><color:44ff44>" @ mClamp(mFloor((%pl.stimCharge / (%img.stimUseTime * 10)) * 100), 0, 100) @ "%";
	if(%img.stimUseCount)
	{
		%text = %text @"<br><br><color:ff7744>You have " @ %img.stimUseCount - %pl.stimUses[%pl.currTool] @ " charge";
		%text = %text @ (%img.stimUseCount - %pl.stimUses[%pl.currTool] > 1 ? "s " : " ") @ "left on your " @ %img.stimName @ ".";
	}
	
	centerprint(%pl.client, %text, 2);

	if(%pl.stimCharge >= %img.stimUseTime * 10)
	{
		%pl.setImageAmmo(0,0);
		%pl.setImageLoaded(0,1);
		%pl.stimCharge = 0;
		return;
	}

	%pl.spackCharge = %pl.schedule(100, medi_UseChargeLoop, %img);
}

function Player::stimCheck(%pl, %img, %alt)
{
	if(getSimTime() - %pl.lastStimTime < %img.stimChargeTime * 1000)
	{
		%time = (%img.stimChargeTime * 1000) - (getSimTime() - %pl.lastStimTime);
		centerprint(%pl.client, "<font:arial:13><color:ff7744>Can't use your " @ %img.stimName @ " yet!<br><br>Give it " @ mFloatLength(%time / 1000, 1) @ "s to recharge...", 5);
		%pl.playThread(2, undo);
		%pl.setImageAmmo(0,1);
		%pl.setImageLoaded(0,0);
		return 0;
	}

	if(%pl.getDamagePercent() <= 0.01 && !%alt)
	{
		if(%img.stimUseCount)
		{
			%text = "<br><br><color:ff7744>You have " @ %img.stimUseCount - %pl.stimUses[%pl.currTool] @ " charge";
			%text = %text @ (%img.stimUseCount - %pl.stimUses[%pl.currTool] > 1 ? "s " : " ") @ "left on your " @ %img.stimName @ ".";
		}

		centerprint(%pl.client, "<font:arial:13><color:ff7744>Can't use your " @ %img.stimName @ " yet!<br><br>You are already at full health." @ %text, 5);
		%pl.playThread(2, undo);
		%pl.setImageAmmo(0,1);
		%pl.setImageLoaded(0,0);
		return 0;
	}

	if(vectorLen(%pl.getVelocity()) > 2.9 && !%img.stimCanMove && !%pl.isMounted() && !%alt)
	{
		centerprint(%pl.client, "<font:arial:13><color:ff7744>Can't use your " @ %img.stimName @ " while moving!", 5);
		%pl.playThread(2, undo);
		%pl.setImageAmmo(0,1);
		%pl.setImageLoaded(0,0);
		%pl.stimCharge = 0;
		return 0;
	}

	if(!%pl.getImageTrigger(0) && !%alt)
	{
		%pl.setImageAmmo(0,1);
		%pl.setImageLoaded(0,0);
		%pl.stimCharge = 0;
		centerprint(%pl.client, "<font:arial:13><color:44ff44>Canceled healing.", 5);
		%pl.playThread(2, undo);
		return 0;
	}

	return 1;
}

function stimRechargedNotice(%obj, %img)
{
	centerprint(%obj.client, "<font:arial:13><color:44ff44>" @ %img.stimName @ " recharged!<br><color:ffffff>You can use it again.", 5);
	serverPlay3D(medi_gauzeGunReloadSound,%obj.getPosition());
}

function Player::stimStart(%pl, %img)
{
	%pl.setImageAmmo(0,1);
	%pl.setImageLoaded(0,1);
	if(isEventPending(%pl.spackCharge))
		cancel(%pl.spackCharge);
	%pl.stimCharge = 0;
	%pl.medi_UseChargeLoop(%img);
}

function Player::stimFire(%pl, %img, %alt, %proj)
{
	if(!isObject(%proj)) %projectile = medi_shortHealProjectile;
	else %projectile = %proj;
	%vector = %pl.getMuzzleVector(0);
	%objectVelocity = %pl.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1, %vector2);
	%p = new Projectile()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %pl.getMuzzlePoint(0);
		sourceObject = %pl;
		sourceSlot = 0;
		sourceInventory = %pl.currTool;
		sourceIMage = %img;
		client = %pl.client;
		healAmount = %img.stimHealOtherAmount;
		healSpeed = %img.stimHealOtherSpeed;
		helpUp = %img.stimHelpOtherUp;
	};
	MissionCleanup.add(%p);

	if(%img.stimUseCount > 0 && %img.stimDepleteOnAlt)
	{
		%pl.stimUses[%pl.currTool]++;
		if(%pl.stimUses[%pl.currTool] >= %img.stimUseCount)
		{
			%pl.stimUses[%pl.currTool] = "";
			%pl.removeItemFromSlot(%pl.currTool);
			return;
		}
	}

	if(%alt)
	{
		%pl.lastStimTime = getSimTime() - (%img.stimChargeTime - %img.stimAltChargeTime) * 1000;
		schedule(%img.stimAltChargeTime * 1000, %pl, stimRechargedNotice, %pl, %img);
	}
	else
	{
		%pl.lastStimTime = getSimTime();
		schedule(%img.stimChargeTime * 1000, %pl, stimRechargedNotice, %pl, %img);
	}
}

function Player::stimUse(%pl, %img)
{
	%pl.stimCharge = 0;
	%pl.lastStimTime = getSimTime();
	medi_heal(%pl, %pl, 0, %img.stimHealSelfAmount, %img.stimHealSelfSpeed);
	if(%img.stimUseCount > 0 && %img.stimDepleteOnMain)
	{
		%pl.stimUses[%pl.currTool]++;
		if(%pl.stimUses[%pl.currTool] >= %img.stimUseCount)
		{
			%pl.stimUses[%pl.currTool] = "";
			%pl.removeItemFromSlot(%pl.currTool);
			return;
		}
	}
	schedule(%img.stimChargeTime * 1000, %pl, stimRechargedNotice, %pl, %img);
}

function medi_shortHealProjectile::onCollision(%this,%obj,%col,%pos,%fade)
{
	medi_heal(%obj, %col, 0, %obj.healAmount, %obj.healSpeed, %obj.helpUp);
	Parent::onCollision(%this,%obj,%col,%pos,%fade);
}

package StimImage
{
	function WeaponImage::onUnmount(%this, %obj, %slot)
	{
		%obj.stimCharge = 0;
		if(isEventPending(%obj.spackCharge))
			cancel(%obj.spackCharge);
		
		Parent::onUnmount(%this, %obj, %slot);
	}

	function WeaponImage::onChargeStop(%this, %obj, %slot)
	{
		if(!%obj.getImageTrigger(0) && %this.stimName $= "")
		{
			centerprint(%obj.client, "<font:arial:13><color:44ff44>Canceled healing.", 5);
			%obj.playThread(2, undo);
		}
	}

	function serverCmdDropTool(%cl, %slot)
	{
		if(isObject(%pl = %cl.player))
		{
			if(%pl.stimUses[%slot] && %pl.tool[%slot].image.stimUseCount > 0)
			{
				$medi_stimTemp = %pl.stimUses[%slot];
				%pl.stimUses[%slot] = "";
			}
		}

		Parent::serverCmdDropTool(%cl, %slot);
	}

	function ItemData::onAdd(%this, %obj)
	{
		Parent::onAdd(%this, %obj);
		
		if($medi_stimTemp !$= "")
		{
			%obj.medi_uses = $medi_stimTemp;
			$medi_stimTemp = "";
		}
	}

	function Armor::onCollision(%db,%pl,%item,%a,%b)
	{
		if(%item.medi_uses && %item.canPickup && %pl.getDamagePercent() < 1.0 && minigameCanUse(%pl, %item))
		{
			%ammo = %item.medi_uses;
			%empties = -1;
			for(%i = 0; %i < %pl.getDatablock().maxTools; %i++)
			{
				if(!isObject(%pl.tool[%i]))
					%empties = %empties TAB %i;
			}

			%empties = removeField(%empties, 0);

			if(isObject(%item.spawnBrick))
			{
				%item.fadeOut();
				%item.schedule(%item.spawnBrick.itemRespawnTime, fadeIn);
			}
			else
				%item.schedule(10, delete);

			%pl.pickup(%item);

			for(%i = 0; %i < getFieldCount(%empties); %i++)
			{
				%id = getField(%empties, %i);
				if(isObject(%itm = %pl.tool[%id]) && %itm.image.stimUseCount > 0)
				{
					%pl.stimUses[%id] = %ammo;
					break;
				}
			}
			return;
		}
		Parent::onCollision(%db,%pl,%item,%a,%b);
	}
};
activatePackage(StimImage);
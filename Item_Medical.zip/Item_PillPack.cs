datablock DebrisData(medi_pillcapDebris)
{
	shapeFile = "./cap.2.dts";
	lifetime = 5.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;
	gravModifier = 2;
};

datablock ItemData(medi_pillpackItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./pills.4.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Pills";
	iconName = "./icon_pills";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = medi_pillpackImage;
	canDrop = true;
	canPickupMultiple = true;
};

datablock ShapeBaseImageData(medi_pillpackImage)
{
	// Basic Item properties
	shapeFile = "./pills.4.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0.1";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	stimChargeTime = 4;
	stimAltChargeTime = 2.4;
	stimUseTime = 1.2;
	stimHealSelfAmount = 50;
	stimHealOtherAmount = 50;
	stimHealSelfSpeed = 2;
	stimHealOtherSpeed = 3;
	stimHelpSelfUp = false;
	stimHelpOtherUp = false;
	stimUseCount = 1;
	stimDepleteOnMain = true;
	stimDepleteOnAlt = true;
	stimCanMove = true;
	stimName = "Pills";
	
	altTriggerEnabled = false;

	className = "WeaponImage";
	item = medi_pillpackItem;

	//raise your arm up or not
	armReady = true;

	doColorShift = false;

	casing = medi_pillcapDebris;
	shellExitDir		= "1.0 1.0 1.0";
	shellExitOffset		= "0 0 0";
	shellExitVariance	= 5;	
	shellVelocity		= 10;

	// Initial start up state
	stateName[0]                     = "Ready";
	stateScript[0]								= "onReady";
	stateTransitionOnTriggerDown[0]  = "StimCharge";

	stateName[1]                     = "StimCharge";
	//stateTransitionOnTimeout[1]      = "Fire";
	stateScript[1]                   = "onChargeStart";
	stateTimeoutValue[1]		   = 60; //just in case you REALLY want to get crazy with the use time
	stateTransitionOnTriggerUp[1] = "Cancel";
	stateTransitionOnNoAmmo[1] = "Next";
	stateTransitionOnNotLoaded[1] = "Cancel";
	stateTransitionOnTimeout[1] = "Next";
	stateWaitForTimeout[1] = false;

	stateName[4] 				= "Cancel";
	stateScript[4]                   = "onChargeStop"; // this is packaged, all it serves by default is to print "Canceled healing."
	stateTransitionOnTimeout[4] = "Ready";
	stateTimeoutValue[4]				= 0.1;

	stateName[3]                     = "Next";
	stateTimeoutValue[3]		   = 0.1;
	stateTransitionOnTriggerUp[3]      = "Ready";
	stateTransitionOnNoAmmo[3] = "Fire";

	stateName[2]                     = "Fire";
	stateTransitionOnTimeout[2]      = "Ready";
	stateScript[2]                   = "onFire";
	stateEjectShell[2] 				= true;
	stateTimeoutValue[2]		   = 2;
};

function medi_pillpackImage::onReady(%this, %obj, %slot)
{
	%obj.setImageAmmo(0,1);
	%obj.setImageLoaded(0,1);
}

function medi_pillpackImage::onChargeStart(%this, %obj, %slot)
{
	if(!%obj.stimCheck(%this)) return;

	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, shiftDown);
	%obj.stimStart(%this);
}

function medi_pillpackImage::onFire(%this,%obj,%slot)
{
	if(!%obj.stimCheck(%this)) return;
	
	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, plant);
	%obj.stimUse(%this);
}

function medi_pillpackImage::onAltTrigger(%this, %player, %playerDB, %triggerSlot, %val)
{
	if(%val && %triggerSlot == 4)
	{
		if(!%player.stimCheck(%this, true)) return;
		%player.playThread(2, shiftDown);
		serverPlay3D(medi_clickHealSound, %player.getPosition());
		%player.stimFire(%this, true);
	}
}
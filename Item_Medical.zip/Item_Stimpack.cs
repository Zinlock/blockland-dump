datablock ItemData(medi_stimpackItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./stimpack.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Syringe";
	iconName = "./syringe";
	doColorShift = false;

	 // Dynamic properties defined by the scripts
	image = medi_stimpackImage;
	canDrop = true;
};

datablock ShapeBaseImageData(medi_stimpackImage)
{
	// Basic Item properties
	shapeFile = "./stimpack.dts";
	emap = true;

	// Specify mount point & offset for 3rd person, and eye offset
	// for first person rendering.
	mountPoint = 0;
	offset = "0 0 0.1";
	eyeOffset = 0; //"0.7 1.2 -0.5";
	rotation = eulerToMatrix( "0 0 0" );

	stimChargeTime = 6;
	stimAltChargeTime = 6;
	stimUseTime = 3.1;
	stimHealSelfAmount = 65;
	stimHealOtherAmount = 65;
	stimHealSelfSpeed = 1.6;
	stimHealOtherSpeed = 1.3;
	stimHelpSelfUp = true;
	stimHelpOtherUp = true;
	stimUseCount = 0;
	stimDepleteOnMain = true;
	stimDepleteOnAlt = true;
	stimCanMove = true;
	stimName = "Syringe";

	altTriggerEnabled = true;

	className = "WeaponImage";
	item = medi_stimpackItem;

	//raise your arm up or not
	armReady = true;

	doColorShift = false;

	// Initial start up state
	stateName[0]                     = "Ready";
	stateScript[0]								= "onReady";
	stateTransitionOnTriggerDown[0]  = "StimCharge";

	stateName[1]                     = "StimCharge";
	//stateTransitionOnTimeout[1]      = "Fire";
	stateScript[1]                   = "onChargeStart";
	stateTimeoutValue[1]		   = 60; //just in case you REALLY want to get crazy with the use time
	stateTransitionOnTriggerUp[1] = "Cancel";
	stateTransitionOnNoAmmo[1] = "Next";
	stateTransitionOnNotLoaded[1] = "Cancel";
	stateTransitionOnTimeout[1] = "Next";
	stateWaitForTimeout[1] = false;

	stateName[4] 				= "Cancel";
	stateScript[4]                   = "onChargeStop"; // this is packaged, all it serves by default is to print "Canceled healing."
	stateTransitionOnTimeout[4] = "Ready";
	stateTimeoutValue[4]				= 0.1;

	stateName[3]                     = "Next";
	stateTimeoutValue[3]		   = 0.1;
	stateTransitionOnTriggerUp[3]      = "Ready";
	stateTransitionOnNoAmmo[3] = "Fire";

	stateName[2]                     = "Fire";
	stateTransitionOnTimeout[2]      = "Ready";
	stateScript[2]                   = "onFire";
	stateTimeoutValue[2]		   = 2;
};

function medi_stimpackImage::onReady(%this, %obj, %slot)
{
	%obj.setImageAmmo(0,1);
	%obj.setImageLoaded(0,1);
}

function medi_stimpackImage::onChargeStart(%this, %obj, %slot)
{
	if(!%obj.stimCheck(%this)) return;

	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, shiftDown);
	%obj.stimStart(%this);
}

function medi_stimpackImage::onFire(%this,%obj,%slot)
{
	if(!%obj.stimCheck(%this)) return;
	
	serverPlay3D(medi_clickHealSound, %obj.getPosition());
	%obj.playThread(2, plant);
	%obj.stimUse(%this);
}

function medi_stimpackImage::onAltTrigger(%this, %player, %playerDB, %triggerSlot, %val)
{
	if(%val && %triggerSlot == 4)
	{
		if(!%player.stimCheck(%this, true)) return;
		%player.playThread(2, shiftDown);
		serverPlay3D(medi_clickHealSound, %player.getPosition());
		%player.stimFire(%this, true);
	}
}
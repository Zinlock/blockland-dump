package ImageAltTrigger
{
	function Armor::onTrigger(%db, %player, %triggerSlot, %val)
	{
		// Players can only have 4 mounted images at a time
		for(%i = 0; %i < 4; %i++)
		{
			// %image is an ID
			if(isObject(%image = %player.getMountedImage(%i)) && %image.altTriggerEnabled)
				%image.onAltTrigger(%player, %db, %triggerSlot, %val);
		}
		Parent::onTrigger(%db, %player, %triggerSlot, %val);
	}
};
activatePackage(ImageAltTrigger);

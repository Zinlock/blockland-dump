$NeverRespawnVehicles = true;

package KeepVehicles
{
	function GameConnection::onClientEnterGame(%client)
	{
		%client.isJoining = true;

		Parent::onClientEnterGame(%client);
	}

	function GameConnection::resetVehicles(%client)
	{
		if($NeverRespawnVehicles && (%client.isJoining || %client.isLeaving))
		{
			%client.isJoining = false;
			%client.isLeaving = false;
			return;
		}
		
		Parent::resetVehicles(%client);
	}

	function GameConnection::onClientLeaveGame(%client)
	{
		%client.isLeaving = true;

		parent::onClientLeaveGame(%client);
	}
};
activatePackage(KeepVehicles);
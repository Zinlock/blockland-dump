// SlayerClient.ServerPrefs.exportMinigamePreferences(%mgamepath);
// SlayerClient.TeamPrefs.exportTeamPreferences(%teamspath);

//	SlayerClient.ServerPrefs.importMinigamePreferences(%mgameFile);
//	SlayerClient.teams.clearTeams(true);
//	if(isFile(%teamsFile))
// 		SlayerClient.TeamPrefs.importTeamPreferences(%teamsFile);

$SSL::Path = "config/client/sslmg/";

if(isObject(SlayerSaveListGUI))
	SlayerSaveListGUI.delete();

exec("./SlayerSaveListGUI.gui");

//obj names (prefixed with SSL_):
// window   scrollList   content   input   saveBtn   loadBtn

// too much redundant code but idc cause at least it works

function SSL_loadMG()
{
	%name = SSL_input.getValue();
	if(trim(%name) $= "") return;

	%mini = $SSL::Path @ %name @ ".mgame.csv";
	%team = $SSL::Path @ %name @ ".teams.csv";
	if(isFile(%mini))
	{
		SlayerClient.ServerPrefs.importMinigamePreferences(%mini);
		SlayerClient.teams.clearTeams(true);
		if(isFile(%team))
 			SlayerClient.TeamPrefs.importTeamPreferences(%team);
			
		Slayer_Main.refresh();
	}

	SSL_Input.setValue("");
}

function SSL_deleteMG()
{
	$SSL::Clicks++;

	schedule(500, 0, SSL_resetClickSpeed); // dumb shit for double clicking pls don't judge

	if($SSL::Clicks < 2 || $SSL::Clicks > 2)
		return;
	
	%name = SSL_input.getValue();
	if(trim(%name) $= "") return;

	%mini = $SSL::Path @ %name @ ".mgame.csv";
	%team = $SSL::Path @ %name @ ".teams.csv";

	fileDelete(%mini);
	fileDelete(%team);

	SSL_Input.setValue("");
	schedule(300, 0, SSL_refresh);
}

function SSL_resetClickSpeed()
{
	$SSL::Clicks = 0;
}

function SSL_loadExpressMG()
{
	%name = SSL_Content.getRowTextByID(SSL_Content.getSelectedID());
	if(trim(%name) $= "") return;

	%mini = $SSL::Path @ %name @ ".mgame.csv";
	%team = $SSL::Path @ %name @ ".teams.csv";
	if(isFile(%mini))
	{
		SlayerClient.ServerPrefs.importMinigamePreferences(%mini);
		SlayerClient.teams.clearTeams(true);
		if(isFile(%team))
 			SlayerClient.TeamPrefs.importTeamPreferences(%team);
			
		Slayer_Main.refresh();
	}

	SSL_Input.setValue("");
}

function SSL_saveMG()
{
	%name = SSL_input.getValue();
	if(trim(%name) $= "") return;

	%mini = $SSL::Path @ %name @ ".mgame.csv";
	%team = $SSL::Path @ %name @ ".teams.csv";

	SlayerClient.ServerPrefs.exportMinigamePreferences(%mini);
	SlayerClient.TeamPrefs.exportTeamPreferences(%team);

	schedule(300, 0, SSL_refresh);
}

function SSL_Window::onWake(%gui)
{
	schedule(300, 0, SSL_refresh);
}

function SSL_refresh()
{
	SSL_content.clear();

	%pat = $SSL::Path @ "*.mgame.csv";

	%file = findFirstFile(%pat);
	for(%i = 0; %file !$= ""; %i++)
	{
		%txt = strReplace(%file, $SSL::Path, "");
		%txt = strReplace(%txt, ".mgame.csv", "");
		SSL_content.addRow(%i, %txt);

		%file = findNextFile(%pat);
	}
}

function SSL() { Canvas.pushDialog(SlayerSaveListGUI); schedule(300, 0, SSL_refresh); }
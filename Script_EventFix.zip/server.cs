// Script_EventFix
// Creates a dummy client that reassigns events on all bricks, fixing events like onMinigameRoundStart

function SimGroup::findNTIndex(%group, %name)
{
	for(%i = 0; %i < %group.NTNameCount; %i++)
	{
		if(%group.NTName[%i] $= %name)
			return %i;
	}

	return -1;
}

function efxFindBrick(%name)
{
	%gcts = mainBrickGroup.getCount();
	for(%g = 0; %g < %gcts; %g++)
	{
		%group = mainBrickGroup.getObject(%g);
		%cts = %group.getCount();
		for(%i = 0; %i < %cts; %i++)
		{
			%brk = %group.getObject(%i);

			if(%brk.getName() $= %name)
				return %brk;
		}
	}

	return -1;
}

function eventFix(%silent)
{
	%evts = 0;
	%brks = 0;

	%cl = new ScriptObject()
	{
		class = "efxClient";
		isAdmin = 1;
		isSuperAdmin = 1;
		isHost = 1;
		bl_id = getNumKeyID();
	};

	MissionCleanup.add(%cl);

	%lbc = $LoadingBricks_Client;

	$LoadingBricks_Client = %cl;

	%gcts = mainBrickGroup.getCount();
	for(%g = 0; %g < %gcts; %g++)
	{
		%group = mainBrickGroup.getObject(%g);
		%cts = %group.getCount();

		// efxResetNTNames(%group);

		for(%i = 0; %i < %cts; %i++)
		{
			%brk = %group.getObject(%i);

			if(isObject(%brk.item))
			{
				%brk.setItem(%brk.item.getDataBlock());

				if(isFunction(fxDtsBrick, addRandomItem_onLoadPlanted))
					%brk.schedule(1000, addRandomItem_onLoadPlanted);
			}

			if((%cs = %brk.numEvents) <= 0)
				continue;
			
			%brks++;
			
			for(%e = 0; %e < %cs; %e++)
			{
				%evts++;

				%inputEventIdx = %brk.eventInputIdx[%e];
				%targetIdx = %brk.eventTargetIdx[%e];
				%outputEventIdx = %brk.eventOutputIdx[%e];
				%enabled = %brk.eventEnabled[%e];
				%delay = %brk.eventDelay[%e];
				%nti = %brk.getGroup().findNTIndex(%brk.eventNT[%e]);
				%par1 = %brk.eventOutputParameter[%e, 1];
				%par2 = %brk.eventOutputParameter[%e, 2];
				%par3 = %brk.eventOutputParameter[%e, 3];
				%par4 = %brk.eventOutputParameter[%e, 4];

				schedule(0, %cl, efxAddEvent, %cl, %brk, %enabled, %inputEventIdx, %delay, %targetIdx, %nti, %outputEventIdx, %par1, %par2, %par3, %par4);
			}

			%brk.numEvents = 0;
		}
	}

	$LoadingBricks_Client = %lbc;

	%cl.schedule(1000, delete);

	if(!%silent)
		talk("Replaced " @ %evts @ " events across " @ %brks @ " bricks");
}

function efxAddEvent(%cl, %brk, %enabled, %inputEventIdx, %delay, %targetIdx, %nti, %outputEventIdx, %par1, %par2, %par3, %par4)
{
	%lbb = $LastLoadedBrick;
	$LastLoadedBrick = %brk;
	%cl.wrenchBrick = %brk;
	serverCmdAddEvent(%cl, %enabled, %inputEventIdx, %delay, %targetIdx, %nti, %outputEventIdx, %par1, %par2, %par3, %par4);
	$LastLoadedBrick = %lbb;
}

// function efxResetNTNames(%grp)
// {
// 	%cts = %grp.getCount();
// 	for(%i = 0; %i < %cts; %i++)
// 	{
// 		%brk = %grp.getObject(%i);

// 		%name = %brk.getName();

// 		if(%name !$= "")
// 		{
// 			%brk.clearNTObjectName();
// 			%brk.setNTObjectName(%name);
// 		}
// 	}
// }

function eventCopy(%from, %to, %silent)
{
	%evts = 0;
	%brks = 0;

	%src = efxFindBrick("_" @ %from);

	if(!isObject(%src) || %src.numEvents <= 0)
	{
		talk("Brick " @ %from @ " not found or is missing events");
		return;
	}

	%cl = new ScriptObject()
	{
		class = "efxClient";
		isAdmin = 1;
		isSuperAdmin = 1;
		isHost = 1;
		bl_id = getNumKeyID();
	};

	MissionCleanup.add(%cl);

	%lbc = $LoadingBricks_Client;

	$LoadingBricks_Client = %cl;

	%gcts = mainBrickGroup.getCount();
	for(%g = 0; %g < %gcts; %g++)
	{
		%group = mainBrickGroup.getObject(%g);
		%cts = %group.getCount();
		for(%i = 0; %i < %cts; %i++)
		{
			%brk = %group.getObject(%i);

			if(%brk.getName() !$= ("_" @ %to))
				continue;

			%cs = %src.numEvents;

			%brks++;
			
			for(%e = 0; %e < %cs; %e++)
			{
				%evts++;

				%inputEventIdx = %src.eventInputIdx[%e];
				%targetIdx = %src.eventTargetIdx[%e];
				%outputEventIdx = %src.eventOutputIdx[%e];
				%enabled = %src.eventEnabled[%e];
				%delay = %src.eventDelay[%e];
				%nti = %src.getGroup().findNTIndex(%src.eventNT[%e]);
				%par1 = %src.eventOutputParameter[%e, 1];
				%par2 = %src.eventOutputParameter[%e, 2];
				%par3 = %src.eventOutputParameter[%e, 3];
				%par4 = %src.eventOutputParameter[%e, 4];

				schedule(0, %cl, efxAddEvent, %cl, %brk, %enabled, %inputEventIdx, %delay, %targetIdx, %nti, %outputEventIdx, %par1, %par2, %par3, %par4);
			}

			%brk.numEvents = 0;
		}
	}

	$LoadingBricks_Client = %lbc;

	%cl.schedule(1000, delete);

	if(!%silent)
		talk("Copied " @ %evts @ " events across " @ %brks @ " bricks");
}

function serverCmdEventFix(%cl)
{
	if(!%cl.isSuperAdmin)
		return;

	eventFix();
}

function serverCmdEventCopy(%cl, %from, %to)
{
	if(!%cl.isSuperAdmin)
		return;
	
	if(trim(%from) $= "" || trim(%to) $= "")
	{
		messageClient(%cl, '', "\c5Usage: /eventCopy [from] [to]");
		return;
	}

	eventCopy(trim(%from), trim(%to));
}

function serverCmdClaimBricks(%cl, %target)
{
	if(!%cl.isSuperAdmin)
		return;
	
	%target = trim(%target);

	if(%target $= "" || (!isObject(%targ = findclientbyname(%target)) && !isObject(%grp = "BrickGroup_" @ %target)))
		return;

	if(isObject(%targ))
		%grp = %targ.brickGroup;

	%brks = 0;

	if(isObject(%grp))
	{
		while(%grp.getCount() > 0)
		{
			%brk = %grp.getObject(0);

			%brk.client = %cl;
			%cl.brickGroup.add(%brk);
			%brks++;
		}
	}

	talk("Claimed " @ %brks @ " bricks for " @ %cl.getBLID());
}

function serverCmdClearNamedBricks(%cl, %name)
{
	if(!%cl.isSuperAdmin)
		return;
	
	%cts = 0;

	while(isObject(%brk = efxFindBrick("_" @ %name)))
	{
		%brk.delete();
		%cts++;
	}

	talk("Cleared " @ %cts @ " bricks named " @ %name);
}
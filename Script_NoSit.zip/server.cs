forceRequiredAddon("GameMode_Slayer");

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Minigame";
	title = "Disable /sit";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.noSitting";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Minigame";
	title = "Disable crouch sitting";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.noCrouchSitting";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

package noSit
{
	function serverCmdSit(%cl)
	{
		if(isObject(%mg = %cl.minigame))
		{
			if(%mg.noSitting)
				return;
			else if(%mg.noCrouchSitting && isObject(%pl = %cl.Player))
			{
				if(%pl.mgCrouching)
					return;

				%pl.mgSitting = true;
			}
		}

		Parent::serverCmdSit(%cl);
	}

	function Armor::onTrigger(%db, %pl, %trig, %val)
	{
		if(%trig == 3)
		{
			%pl.mgCrouching = %val;

			if(%pl.mgSitting && %val)
			{
				%pl.setActionThread(root, false, false);
				%pl.mgSitting = false;
			}
		}

		Parent::onTrigger(%db, %pl, %trig, %val);
	}
};
activatePackage(noSit);
if(forceRequiredAddon("Gamemode_Slayer") == $Error::Addon_NotFound)
{
	error("Missing required addon for Server_SlayerTeamBeacons: GameMode_Slayer");
	return;
}

if(!isFunction(NetObject, setNetFlag))
{
	error("Missing required DLL for Extension_SlayerTeamBeacons: SelectiveGhosting.dll");
	return;
}

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "Beacons";
	title = "Ping Flag Spawns";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.STB_pingFlagSpawn";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
	callback = "%mini.STB_UpdateLoop();";
};

new ScriptObject(Slayer_TeamPrefSO : Slayer_DefaultTeamPrefSO)
{
	category = "Beacons";
	title = "Can see Team Beacons";
	defaultValue = true;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "STB_showTeamBeacons";
	type = "bool";
	guiTag = "advanced";
	callback = "%mini.STB_UpdateLoop();";
};

new ScriptObject(Slayer_TeamPrefSO : Slayer_DefaultTeamPrefSO)
{
	category = "Beacons";
	title = "Can see Enemy Beacons";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "STB_showEnemyBeacons";
	type = "bool";
	guiTag = "advanced";
	callback = "%mini.STB_UpdateLoop();";
};

new ScriptObject(Slayer_TeamPrefSO : Slayer_DefaultTeamPrefSO)
{
	category = "Beacons";
	title = "Can see All Beacons while spectating";
	defaultValue = true;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "STB_showAllBeaconsSpec";
	type = "bool";
	guiTag = "advanced";
	callback = "%mini.STB_UpdateLoop();";
};

new ScriptObject(Slayer_TeamPrefSO : Slayer_DefaultTeamPrefSO)
{
	category = "Beacons";
	title = "Ping Flag Holder";
	defaultValue = true;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "STB_showFlagHolder";
	type = "bool";
	guiTag = "advanced";
	callback = "%mini.STB_UpdateLoop();";
};

package TeamBeacon_pkg
{
	function Slayer_TeamSO::onMinigameRoundEnd(%team)
	{
		Parent::onMinigameRoundEnd(%team);

		for(%i = 0; %i < %team.numMembers; %i++)
		{
			%cc = %team.member[%i];
			if(isObject(%b = %cc.STB_Beacon))
				%b.delete();
		}
	}

	function Slayer_TeamSO::onMinigameRoundStart(%team)
	{
		Parent::onMinigameRoundStart(%team);
		
		%team.minigame.STB_UpdateLoop();
	}

	function Slayer_TeamSO::onAddMember(%team, %cl)
	{
		Parent::onAddMember(%team, %member);
		
		if(isObject(%mg = %team.minigame))
			%cl.STB_makeTeamBeacon();
	}

	function Slayer_TeamSO::onRemoveMember(%team, %cl)
	{
		Parent::onRemoveMember(%team, %member);

		if(isObject(%b = %cl.STB_Beacon))
			%b.delete();
	}

	function MinigameSO::removeMember(%mg, %cl)
	{
		Parent::removeMember(%mg, %cl);

		if(isObject(%b = %cl.STB_beacon))
			%b.delete();
	}

	function GameConnection::onClientLeaveGame(%cl)
	{
		if(isObject(%b = %cl.STB_Beacon))
			%b.delete();

		Parent::onClientLeaveGame(%cl);
	}

	function AIController::onRemove(%ctr)
	{
		if(isObject(%b = %ctr.STB_Beacon))
			%b.delete();

		Parent::onRemove(%ctr);
	}
	
	function Slayer_CTF::onFlagPickup(%this, %client, %team, %brick, %flag)
	{
		Parent::onFlagPickup(%this, %client, %team, %brick, %flag);

		%this.minigame.STB_FlagHolder[%team] = %client;
	}

	function fxDTSBrick::onRemove(%brk)
	{
		if(isObject(%brk.STB_flagBeacon))
			%brk.STB_flagBeacon.delete();

		if(isObject(%brk.STB_returnBeacon))
			%brk.STB_returnBeacon.delete();

		Parent::onRemove(%brk);
	}
};
activatePackage(TeamBeacon_pkg);

$STB_Opacity = 0.75;

datablock StaticShapeData(STB_BeaconShape)
{
	shapeFile = "./beacon.dts";
};

function MinigameSO::STB_UpdateLoop(%mg)
{
	if(!isObject(%mg)) return;

	cancel(%mg.STB_Loop);

	for(%i = 0; %i < %mg.numMembers; %i++)
	{
		%cc = %mg.member[%i];
		if(isObject(%cc.STB_Beacon))
			%cc.STB_updateBeacon(%cc.STB_Beacon);
		else
			%cc.STB_makeTeamBeacon();
	}

	if(%mg.STB_pingFlagSpawn && isObject(%brks = %mg.gamemode.bricks) && isObject(%flags = %mg.gamemode.flags))
	{
		%cts = %flags.getCount();
		for(%i = 0; %i < %cts; %i++)
		{
			%flag = %flags.getObject(%i);

			if(isObject(%flag.spawnBrick))
			{
				if(!isObject(%flag.STB_flagBeacon))
				{
					%stb = new StaticShape(stb)
					{
						datablock = STB_BeaconShape;
						position = vectorAdd(%flag.getPosition(), "0 0 10");
						scale = "2 2 2";
						minigame = %mg;
					};

					%flag.STB_flagBeacon = %stb;

					%team = %mg.teams.getTeamFromName(%flag.spawnBrick.getControllingTeam());

					%stb.hideNode("ALL");

					if(%flag.isStatic())
						%stb.unHideNode("shield");
					else
						%stb.unHideNode("arrows");

					%stb.playThread(0, rootSpin);

					%stb.setNodeColor("ALL", getWords(getColorIDTable(%team.color), 0, 2) SPC $STB_Opacity);
					%stb.startFade(1,0,1);
					%stb.setShapeName(%team.name SPC "Flag");
					%stb.setShapeNameColor(getColorIDTable(%team.color));

					%stb.cleanup = %stb.schedule(500, delete);
				}
				else
				{
					%flag.STB_flagBeacon.setTransform(vectorAdd(%flag.getPosition(), "0 0 10"));

					cancel(%flag.STB_flagBeacon.cleanup);
					%flag.STB_flagBeacon.cleanup = %flag.STB_flagBeacon.schedule(500, delete);
				}
			}
			else
			{
				if(isObject(%flag.STB_flagBeacon))
					%flag.STB_flagBeacon.delete();
			}
		}
		
		%ct2 = %brks.getCount();
		for(%i = 0; %i < %ct2; %i++)
		{
			%brk = %brks.getObject(%i);

			if(%brk.getDatablock() == brickSlyrCTFFlagReturnData.getId())
			{
				%teamName = %brk.getControllingTeam();
				%team = %mg.teams.getTeamFromName(%teamName);

				if(isObject(%cc = %mg.STB_FlagHolder[%team]) && isObject(%cc.player.flagSpawn) && %teamName $= %cc.slyrTeam.name)
				{
					if(!isObject(%brk.STB_returnBeacon))
					{
						%stb = new StaticShape(stb)
						{
							datablock = STB_BeaconShape;
							position = vectorAdd(%brk.getPosition(), "0 0 10");
							scale = "2 2 2";
							minigame = %mg;
						};

						%brk.STB_returnBeacon = %stb;

						%stb.hideNode("ALL");
						%stb.unHideNode("arrows");
						%stb.playThread(0, rootSpin);

						%stb.setNodeColor("ALL", getWords(getColorIDTable(%team.color), 0, 2) SPC $STB_Opacity);
						%stb.startFade(1,0,1);
						%stb.setShapeName("! Capture Here !");
						%stb.setShapeNameColor(getColorIDTable(%team.color));
					}
				}
				else
				{
					if(isObject(%brk.STB_returnBeacon))
						%brk.STB_returnBeacon.delete();
				}
			}
		}
	}

	%mg.STB_Loop = %mg.schedule(100, STB_UpdateLoop);
}

function StaticShape::STB_ScopeToTeam(%beacon, %owner)
{
	%mg = %beacon.minigame;

	if(%beacon.scopeAlways || %owner.STB_IsScopeAlways() || (%owner.slyrTeam.STB_showFlagHolder && isObject(%owner.player.flagSpawn)))
	{
		if(%beacon.getNetFlag(6))
			%beacon.setNetFlag(6, false);

		if(!ghostAlwaysSet.isMember(%beacon))
			%beacon.setScopeAlways();

		return;
	}

	if(ghostAlwaysSet.isMember(%beacon))
		%beacon.clearScopeAlways();

	if(!%beacon.getNetFlag(6))
		%beacon.setNetFlag(6, true);

	for(%i = 0; %i < %mg.numMembers; %i++)
	{
		%cc = %mg.member[%i];
		if(%cc != %owner && %cc.getClassName() $= "GameConnection")
		{
			if((%cc.slyrTeam.STB_showAllBeaconsSpec && %cc.dead()) || 
			   (%cc.slyrTeam.STB_showTeamBeacons && %cc.slyrTeam.isAlliedTeam(%owner.slyrTeam)) ||
			   (%cc.slyrTeam.STB_showEnemyBeacons && !%cc.slyrTeam.isAlliedTeam(%owner.slyrTeam)))
				%beacon.scopeToClient(%cc);
			else
				%beacon.clearScopeToClient(%cc);
		}
	}
}

function GameConnection::STB_IsScopeAlways(%cl) { return false; }

function GameConnection::STB_makeTeamBeacon(%cl)
{
	if(!isObject(%cl))
		return;
	
	if(isObject(%cl.STB_Beacon))
		%cl.STB_Beacon.delete();

	%cl.STB_Beacon = new StaticShape(stb)
	{
		datablock = STB_BeaconShape;
		position = "0 0 -4600";
		scale = "1.5 1.5 4";
		owner = %cl;
		minigame = %cl.minigame;
	};

	%cl.STB_updateBeacon(%cl, %cl.STB_Beacon);

	%cl.STB_Beacon.hideNode("ALL");
	%cl.STB_Beacon.unHideNode("beacon");
	%cl.STB_Beacon.setShapeName(%cl.name);
	%cl.STB_Beacon.setShapeNameColor(getColorIDTable(%cl.slyrTeam.color));

	%cl.STB_Beacon.setNodeColor("ALL", getWords(getColorIDTable(%cl.slyrTeam.color), 0, 2) SPC $STB_Opacity);
	%cl.STB_Beacon.startFade(1,0,1);
	%cl.STB_ScopeStep = 939999;
	%cl.STB_Beacon.STB_ScopeToTeam(%cl);
}

function AiController::STB_makeTeamBeacon(%cl)
{
	return GameConnection::STB_makeTeamBeacon(%cl);
}

function GameConnection::STB_updateBeacon(%cl, %obj)
{
	if(!isObject(%cl) || !isObject(%obj))
		return;

	if(%obj.getClassName() !$= "StaticShape")
		return;

	if(!isObject(%obj.minigame) || !isObject(%cl.slyrTeam))
	{
		%obj.delete();
		return;
	}

	if(isObject(%pl = %cl.player))
	{
		%obj.setTransform(vectorAdd(%pl.getPosition(), "0 0 70"));
		%cl.STB_ScopeStep++;
		if(%cl.STB_ScopeStep >= 25)
		{
			%cl.STB_ScopeStep = 0;
			%obj.setNodeColor("ALL", getWords(getColorIDTable(%cl.slyrTeam.color), 0, 2) SPC $STB_Opacity);
			%obj.STB_ScopeToTeam(%cl);
		}
	}
	else if(%obj.getTransform() !$= "0 0 -4600")
		%obj.setTransform("0 0 -4600");
}

function AiController::STB_updateBeacon(%cl)
{
	return GameConnection::STB_updateBeacon(%cl);
}
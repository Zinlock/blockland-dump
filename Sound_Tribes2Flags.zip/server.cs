forceRequiredAddon("GameMode_Slayer");

new ScriptObject(Slayer_PrefSO : Slayer_DefaultPrefSO)
{
	category = "CTF";
	title = "Use T2 Flag Sounds";
	defaultValue = false;
	permissionLevel = $Slayer::PermissionLevel["Owner"];
	variable = "%mini.twFlagSounds";
	type = "bool";
	notifyPlayersOnChange = true;
	requiresMiniGameReset = false;
	requiresServerRestart = false;
	guiTag = "advanced";
	priority = 1000;
};

datablock AudioProfile(T2FlagCapture)
{
	filename = "./wav/flag_capture.wav";
	description = AudioDefault3d;
	preload = true;
}; 

datablock AudioProfile(T2FlagLost)
{
	filename = "./wav/flag_lost.wav";
	description = AudioDefault3d;
	preload = true;
}; 

datablock AudioProfile(T2FlagTaken)
{
	filename = "./wav/flag_taken.wav";
	description = AudioDefault3d;
	preload = true;
}; 

datablock AudioProfile(T2FlagReturn)
{
	filename = "./wav/flag_return.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(T2FlagSnatch)
{
	filename = "./wav/flag_snatch.wav";
	description = AudioDefault3d;
	preload = true;
};

datablock AudioProfile(T2FlagDrop)
{
	filename = "./wav/flag_drop.wav";
	description = AudioDefault3d;
	preload = true;
};

package T2FlagPkg
{
	function Slayer_CTF::onFlagPickup(%this, %client, %team, %brick, %flag)
	{
		%mg = %this.minigame;
		if(%mg.twFlagSounds)
		{
			for(%i = 0; %i < %mg.numMembers; %i++)
			{
				%cc = %mg.member[%i];

				%cc.play2D(T2FlagSnatch);

				if(%cc.slyrTeam != %team)
					%cc.play2D(T2FlagTaken);
			}
		}

		Parent::onFlagPickup(%this, %client, %team, %brick, %flag);
	}
	
	function Slayer_CTF::onFlagRecovery(%this, %client, %team, %brick, %flag)
	{
		%mg = %this.minigame;
		if(%mg.twFlagSounds)
		{
			for(%i = 0; %i < %mg.numMembers; %i++)
			{
				%cc = %mg.member[%i];

				%cc.play2D(T2FlagReturn);
			}
		}
		
		Parent::onFlagRecovery(%this, %client, %team, %brick, %flag);
	}

	function Slayer_CTF::onFlagReturn(%this, %client, %team, %brick, %flag)
	{
		%mg = %this.minigame;
		if(%mg.twFlagSounds)
		{
			for(%i = 0; %i < %mg.numMembers; %i++)
			{
				%cc = %mg.member[%i];

				if(%cc.slyrTeam == %team)
					%cc.play2D(T2FlagCapture);
				else
					%cc.play2D(T2FlagLost);
			}
		}

		Parent::onFlagReturn(%this, %client, %team, %brick, %flag);
	}

	function Slayer_CTF::onFlagDrop(%this, %client, %team, %brick, %flag)
	{
		%mg = %this.minigame;
		if(%mg.twFlagSounds)
		{
			for(%i = 0; %i < %mg.numMembers; %i++)
			{
				%cc = %mg.member[%i];

				%cc.play2D(T2FlagDrop);
			}
		}

		Parent::onFlagDrop(%this, %client, %team, %brick, %flag);
	}
};
activatePackage(T2FlagPkg);
exec("./binds.cs");

$prefixDivName = "Custom: ";

$cbp = "config/client/customBinds.cs";

if(isFile($cbp))
	exec($cbp);

if(isObject(ServerConnection))
	commandToServer('SendCustomBinds');

function getBindName(%bind)
{
	%device = getField(%bind, 0);
	%action = getField(%bind, 1);

	if(%device $= "keyboard")
		return %action;
	
	if(%device $= "mouse0")
	{
		switch$(%action)
		{
			case "xaxis": return "mouse x";
			case "yaxis": return "mouse y";
			case "button0": return "left mouse";
			case "button1": return "right mouse";
			case "zaxis": return "mouse wheel";
			case "button3": return "mouse thumb";
			default: return %action;
		}
	}
}

function clientCmdCheckCustomBinds() { commandToServer('SendCustomBinds'); }

function clientCmdRegisterBindsStart()
{
	clearServerBinds();

	$NewBindCount = 0;
	$NewBinds = true;
}

function clientCmdRegisterBindsDone()
{
	if($NewBinds)
	{
		NewChatHud_AddLine("\c2This server registered " @ $NewBindCount @ " custom bind" @ ($NewBindCount == 1 ? "" : "s"));
		%fail = 0;
		%str = "Some binds failed to load:<br>";
		for(%i = 0; %i < $NewBindCount; %i++)
		{
			%bind = $NewBind[%i];
			%div = getField(%bind, 0);
			%name = getField(%bind, 1);

			if($NewBindFail[%i] != 0)
			{
				if($NewBindFail[%i] == 1)
					%err = "Previously saved combo " @ getBindName($NewBindSaved[%i]) @ " was overwritten";
				else
					%err = "Default combo " @ getBindName($NewBindDefault[%i]) @ " is taken";
				
				%str = %str @ "<br>" @ stripMLControlChars(%div @ " - " @ %name) @ "<br>" @ %err @ "<br>";

				%fail = 1;
			}
		}

		if(%fail)
			MessageBoxOK("New Server Binds", %str @ "<br>Make sure to re-bind any important actions!<br>They can be found at the bottom of the list in Options > Controls");
	}
	
	$NewBinds = false;
	$NewBindCount = 0;
}

function clientCmdRegisterServerBind(%div, %name, %cmdOn, %cmdOff, %default)
{
	%divS = stripMLControlChars(trim(%div));
	%nameS = stripMLControlChars(trim(%name));

	%divSafe = getSafeVariableName(%div);
	%nameSafe = getSafeVariableName(%name);
	%nameFunc = "ServerBind_" @ %nameSafe;
	%cmdOnSafe = getSafeVariableName(%cmdOn);
	%cmdOffSafe = getSafeVariableName(%cmdOff);

	if($CustomBindIdx[%divSafe, %nameSafe] !$= "")
	{
		warn("clientCmdRegisterServerBind() - Server sent duplicate binds, ignoring...");
		return;
	}

	eval("function " @ %nameFunc @ "(%val) { if(%val) { commandToServer('" @ %cmdOnSafe @ "', \"1\"); } else { commandToServer('" @ %cmdOffSafe @ "', \"0\"); } }");
	// ^ this should be secure as getSafeVariableName entirely strips out special characters
	// it still sucks, sure, but I can't think of a better way of doing it

	%bindLoaded = 0;
	%defaultLoaded = 0;

	if($CusBind_[%divSafe, %nameSafe] !$= "")
	{
		if($CusBind_[%divSafe, %nameSafe] != -1) // -1 was unbound manually
		{
			%device = getField($CusBind_[%divSafe, %nameSafe], 0);
			%action = getField($CusBind_[%divSafe, %nameSafe], 1);

			%cmd = moveMap.getCommand(%device,%action);

			if(%cmd !$= "" && %cmd !$= %nameFunc)
			{
				%bindLoaded = -1;

				if($NewBinds)
					$NewBindSaved[$NewBindCount] = %device TAB %action;

				%device = "";
				%action = "";
			}
			else
				%bindLoaded = 1;
		}
	}
	else
	{
		%device = getField(%default, 0);
		%action = getField(%default, 1);

		%cmd = moveMap.getCommand(%device,%action);

		if(%cmd !$= "" && %cmd !$= %nameFunc)
		{
			%defaultLoaded = -1;
			%device = "";
			%action = "";
		}
		else
			%defaultLoaded = 1;
	}

	if($NewBinds)
	{
		$NewBind[$NewBindCount] = %div TAB %name;
		$NewBindDefault[$NewBindCount] = %default;

		if(%bindLoaded == -1)
			$NewBindFail[$NewBindCount] = 1;
		else if(%defaultLoaded == -1)
			$NewBindFail[$NewBindCount] = 2;
		else
			$NewBindFail[$NewBindCount] = 0;

		$NewBindCount++;
	}

	addKeyBind($prefixDivName @ %div, %name, %nameFunc, %device, %action, false);

	if($CustomBindCount $= "")
		$CustomBindCount = 0;

	$CustomBindIdx[%divSafe, %nameSafe] = $CustomBindCount;
	$CustomBind[$CustomBindCount] = %div TAB %name TAB %nameSafe;
	$CustomBindCount++;
}

function clearServerBinds()
{
	for(%i = 0; %i < $CustomBindCount; %i++)
	{
		%bind = $CustomBind[%i];
		%div = getField(%bind, 0);
		%name = getField(%bind, 1);
		%safe = getField(%bind, 2);
		%func = "ServerBind_" @ %safe;

		%binding = moveMap.getBinding(%func);
		%device = getField(%binding,0);
		%action = getField(%binding,1);
		
		if(%device !$= "" && %action !$= "")
			$CusBind_[getSafeVariableName(%div), %safe] = %device TAB %action;
		else
			$CusBind_[getSafeVariableName(%div), %safe] = -1;

		removeKeyBind($prefixDivName @ %div, %name, %func);
	}

	deleteVariables("$CustomBind*");
	export("$CusBind_*", $cbp);
}

package CustomBindsPkg
{
	function disconnectedCleanup(%bool)
	{
		clearServerBinds();

		parent::disconnectedCleanup(%bool);
	}

	function onExit()
	{
		clearServerBinds();
		
		parent::onExit();
	}
};
activatePackage(CustomBindsPkg);
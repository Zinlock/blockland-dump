package CustomBindsServerPkg
{
	function GameConnection::autoAdminCheck(%this)
	{
		%parent = Parent::autoAdminCheck(%this);

		commandToClient(%this, 'CheckCustomBinds');
		%this.cbnr = %this.schedule(1000, CustomBindsNoReply);

		return %parent;
	}
};
activatePackage(CustomBindsServerPkg);

function GameConnection::CustomBindsNoReply(%client)
{
	if($ServerCusBindCount <= 0)
		return;

	commandToClient(%client, 'MessageBoxOK', "Custom Binds", "This server has some custom binds available.<br>Without the add-on, you may not be able to play!<br><a:rtb-293>Download here</a>");
}

function GameConnection::transmitCustomBinds(%client)
{
	commandToClient(%client, 'RegisterBindsStart');

	for(%i = 0; %i < $ServerCusBindCount; %i++)
	{
		%bind = $ServerCusBind[%i];
		%div = trim(getField(%bind, 0));
		%name = trim(getField(%bind, 1));
		%cmdOn = trim(getField(%bind, 2));
		%cmdOff = trim(getField(%bind, 3));
		
		commandToClient(%client, 'RegisterServerBind', %div, %name, %cmdOn, %cmdOff, $ServerCusBindDefault[%i]);
	}

	commandToClient(%client, 'RegisterBindsDone');
}

function serverCmdSendCustomBinds(%client)
{
	cancel(%client.cbnr);
	if($ServerCusBindCount > 0)
		%client.transmitCustomBinds();
}

// bind format: "Division Name" TAB "Action Name" TAB "pressedCommandName" TAB "releasedCommandName"
// the pressed and released commands can be the same
// the pressed value is passed to the command as an argument
// can also optionally include a default key (format: "deviceName" TAB "key")

// example use:

// if($ServerCusBindCount $= "") $ServerCusBindCount = 0;
//
// $ServerCusBind[$ServerCusBindCount] = "Test Division" TAB "Test Cmd" TAB "comTest" TAB "comTest2";
// $ServerCusBindDefault[$ServerCusBindCount] = "keyboard" TAB "shift n";
// $ServerCusBindCount++;
//
// function serverCmdComTest(%client, %val)
// {
// 	talk(%val SPC "Com A");
// }
//
// function serverCmdComTest2(%client, %val)
// {
// 	talk(%val SPC "Com B");
// }

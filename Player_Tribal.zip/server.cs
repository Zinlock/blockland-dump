// %error = ForceRequiredAddOn("Script_CustomBinds");

// if(%error == $Error::AddOn_NotFound)
// {
// 	error("Player_Tribal Error: required add-on Script_CustomBinds not found");
// 	return;
// }

if($ServerCusBindCount $= "") $ServerCusBindCount = 0;

$ServerCusBind[$ServerCusBindCount] = "Tribal Player" TAB "Toggle Ski" TAB "toggleSki" TAB "";
$ServerCusBindDefault[$ServerCusBindCount] = "keyboard" TAB "lcontrol";
$ServerCusBindCount++;

$ServerCusBind[$ServerCusBindCount] = "Tribal Player" TAB "Hold Ski" TAB "holdSki" TAB "holdSki";
$ServerCusBindDefault[$ServerCusBindCount] = "";
$ServerCusBindCount++;

datablock PlayerData(PlayerTribalLightArmor : PlayerStandardArmor)
{
	maxTools = 5;
	noInvSort = true;

	airControl = 0.3;

  showEnergyBar = true;

  minJetEnergy = 1;
  jetEnergyDrain = 1.0;
	maxEnergy = 100;

	rechargeRate = 10 / 31.25;

	maxForwardSpeed = 10;
	maxSideSpeed = 9;
	maxBackwardSpeed = 7;

	minImpactSpeed = 35;
	groundImpactMinSpeed = 25;
	speedDamageScale = 0.5;

	jumpForce = 12 * 90;

	jumpSurfaceAngle = 89;
	upMaxSpeed = 90;
	
	maxDamage = 100;

  uiName = "Tribal Light 100 HP";

	isTribal = true;
	skiArmor = PlayerTribalLightSkiArmor;
};

datablock PlayerData(PlayerTribalLightSkiArmor : PlayerTribalLightArmor)
{
	runForce = 0; // removes all friction
	uiName = "";
	
	jumpForce = 6 * 90;
	
	skiSource = PlayerTribalLightArmor;
	isSki = true;
};

datablock PlayerData(PlayerTribalMediumArmor : PlayerTribalLightArmor)
{
	maxTools = 6;
	noInvSort = true;

	airControl = 0.2;

  minJetEnergy = 1;
  jetEnergyDrain = 1.1;
	maxEnergy = 100;

	rechargeRate = 9 / 31.25;

	maxForwardSpeed = 8;
	maxSideSpeed = 7;
	maxBackwardSpeed = 5;

	jumpForce = 11 * 90;
	
	maxDamage = 150;

  uiName = "Tribal Medium 150 HP";

	skiArmor = PlayerTribalMediumSkiArmor;
};

datablock PlayerData(PlayerTribalMediumSkiArmor : PlayerTribalMediumArmor)
{
	runForce = 0; // removes all friction
	uiName = "";
	
	jumpForce = 5.5 * 90;
	
	skiSource = PlayerTribalMediumArmor;
	isSki = true;
};

datablock PlayerData(PlayerTribalHeavyArmor : PlayerTribalLightArmor)
{
	maxTools = 7;
	noInvSort = true;

	airControl = 0.1;
	
  minJetEnergy = 1;
  jetEnergyDrain = 1.2;
	maxEnergy = 100;

	rechargeRate = 8 / 31.25;

	maxForwardSpeed = 6;
	maxSideSpeed = 5;
	maxBackwardSpeed = 3;

	jumpForce = 10 * 90;

	maxDamage = 200;

  uiName = "Tribal Heavy 200 HP";

	skiArmor = PlayerTribalHeavySkiArmor;
};

datablock PlayerData(PlayerTribalHeavySkiArmor : PlayerTribalHeavyArmor)
{
	runForce = 0; // removes all friction
	uiName = "";
	
	jumpForce = 5 * 90;

	skiSource = PlayerTribalHeavyArmor;
	isSki = true;
};

function Player::tribalLoop(%pl)
{
	cancel(%pl.tloop);

	%db = %pl.getDataBlock();

	// if(!%db.isTribal || %pl.getDamagePercent() >= 1.0)
		return;
	
	// if(!%pl.jetting && !%pl.energyInUse && !isObject(%pl.repairTarget))
	// 	%pl.setEnergyLevel(%pl.getEnergyLevel() + (%pl.energyRecharge * ((getSimTime() - %pl.lastTLoop) / 1000)));

	// %pl.lastTLoop = getSimTime();
	%pl.tloop = %pl.schedule(100, tribalLoop);
}

// function Player::tribalSkiLoop(%pl)
// {
// 	cancel(%pl.tribalSki);

// 	%db = %pl.getDataBlock();

// 	if(!%db.isTribal || !%db.isSki || %pl.getDamagePercent() >= 1.0)
// 		return;

// 	%masksR = $Typemasks::StaticObjectType | $TypeMasks::fxBrickObjectType;
// 	%downRay = containerRaycast(vectorAdd(%pl.getPosition(), "0 0 0.1"), vectorAdd(%pl.getPosition(), "0 0 -2"), %masksR, %pl);

// 	if(isObject(%downRay) && !%pl.isJetting() && !%pl.isMounted())
// 	{
// 		// %vel = %pl.getVelocity();
// 		// %va = mRadToDeg(mAcos(vectorDot(vectorNormalize(%vel), vectorNormalize(%pl.lastVel))));

// 		// drawArrow(%pl.getHackPosition(), vectorNormalize(%vel), "0 0.25 1 0.5", vectorLen(%vel), 0.5).schedule(500, delete);

// 		// talk(%va);

// 		// if(vectorLen(%vel) > 10 && %va > 30 && %va < 90)
// 		// {
// 		// 	%pl.setVelocity(vectorScale(vectorNormalize(%vel), vectorLen(%pl.lastVel) * 2));
// 		// 	talk("!");
// 		// }
// 	}
	
// 	%pl.lastVel = %pl.getVelocity();

// 	%pl.tribalSki = %pl.schedule(50, tribalSkiLoop);
// }

function serverCmdToggleSki(%cl)
{
	if(!isObject(%pl = %cl.Player) || !(%db = %pl.getDataBlock()).isTribal)
		return;

	if(!%pl.skiDown && !%db.isSki)
	{
		if(isObject(%db.skiArmor))
		{
			if(!%pl.isCrouched())
				%pl.ChangeDataBlock(%db.skiArmor);
			
			%cl.centerPrint("<font:impact:18><color:4783FD>Skis enabled", 2);
			%pl.skiDown = true;
		}
	}
	else if(%pl.skiDown && %db.isSki)
	{
		if(isObject(%db.skiSource))
		{
			%pl.ChangeDataBlock(%db.skiSource);
			%cl.centerPrint("<font:impact:18><color:4783FD>Skis disabled", 2);
			%pl.skiDown = false;
		}
	}
}

function serverCmdHoldSki(%cl, %val)
{
	if(!isObject(%pl = %cl.Player) || !(%db = %pl.getDataBlock()).isTribal)
		return;
	
	if(%val && !%pl.skiDown && !%db.isSki)
	{
		if(isObject(%db.skiArmor))
		{
			if(!%pl.isCrouched())
				%pl.ChangeDataBlock(%db.skiArmor);
			
			%cl.centerPrint("<font:impact:18><color:4783FD>Skis enabled", 2);
			%pl.skiDown = true;
		}
	}
	else if(!%val && %pl.skiDown && %db.isSki)
	{
		if(isObject(%db.skiSource))
		{
			%pl.ChangeDataBlock(%db.skiSource);
			%cl.centerPrint("<font:impact:18><color:4783FD>Skis disabled", 2);
			%pl.skiDown = false;
		}
	}
}

package TribalPlayerPackage
{
	function Armor::onAdd(%db, %obj)
	{
		Parent::onAdd(%db, %obj);

		%obj.energyRecharge = %db.energyRate;

		if(%db.isTribal && !isEventPending(%obj.tloop))
			%obj.tribalLoop();
	}

	function Armor::onNewDataBlock(%db, %obj)
	{
		Parent::onNewDataBlock(%db, %obj);

		%obj.energyRecharge = %db.energyRate;

		if(%db.isTribal && !isEventPending(%obj.tloop))
		{
			if(isObject(%obj.usingStation))
				%obj.skiDown = false;

			%obj.tribalLoop();
		}
	}

	function Armor::onTrigger(%db, %obj, %trig, %val)
	{
		if(%db.isTribal && %trig == 3 && %obj.getDamagePercent() < 1.0)
		{
			if(!%val && %obj.skiDown && isObject(%db.skiArmor) && !%db.isSki)
			{
				%obj.ChangeDataBlock(%db.skiArmor);
				%obj.client.centerPrint("<font:impact:18><color:4783FD>Skis restored", 2);
			}
			else if(%val && %obj.skiDown && isObject(%db.skiSource) && %db.isSki)
			{
				%obj.ChangeDataBlock(%db.skiSource);
				%obj.client.centerPrint("<font:impact:18><color:4783FD>Skis blocked", 2);
			}
		}

		if(%trig == 4)
			%obj.jetting = %val;

		Parent::onTrigger(%db, %obj, %trig, %val);
	}

	function serverCmdSit(%cl)
	{
		if(isObject(%pl = %cl.player) && %pl.getDataBlock().isTribal)
		{
			serverCmdToggleSki(%cl);
			return;
		}

		Parent::serverCmdSit(%cl);
	}

	// function Armor::onTrigger(%db, %pl, %trig, %val)
	// {
	// 	if(%trig == 4)
	// 		%pl.jetDown = %val;

	// 	return Parent::onTrigger(%db, %pl, %trig, %val);
	// }
};
activatePackage(TribalPlayerPackage);

// function Player::isJetting(%pl)
// {
// 	return (%pl.jetDown && %pl.getEnergyLevel() > %pl.getDataBlock().minJetEnergy);
// }